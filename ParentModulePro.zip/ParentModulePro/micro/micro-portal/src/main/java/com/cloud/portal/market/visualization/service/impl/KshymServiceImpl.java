package com.cloud.portal.market.visualization.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.visualization.entity.Kshym;
import com.cloud.portal.market.visualization.mapper.KshymMapper;
import com.cloud.portal.market.visualization.service.KshymService;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/4/13 11:04
 * @description:
 * @modified By:maojia
 */
@Service
public class KshymServiceImpl extends ServiceImpl<KshymMapper, Kshym> implements KshymService {
    @Override
    public IPage<List<Kshym>> findListPage(IPage<Kshym> page, Kshym kshym) {
        return baseMapper.findListPage(page,kshym);
    }

    @Override
    public List<Kshym> findListById(String id) {
        return baseMapper.findListById(id);
    }


    @Override
    @Cacheable(value = MarketConstants.KSHYM_CACHE_NAME, key = "#all")
    public List<Kshym> findList(String all) {
        return baseMapper.findList(new Kshym() );
    }
}
