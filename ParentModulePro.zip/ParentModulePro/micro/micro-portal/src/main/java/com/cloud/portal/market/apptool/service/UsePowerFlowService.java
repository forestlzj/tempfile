package com.cloud.portal.market.apptool.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.apptool.model.UsePowerFlow;

import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/10 16:54
 * @description: 应用工具申请访问流程service接口
 * @modified By: huangyingx
 */
public interface UsePowerFlowService extends IService<UsePowerFlow> {

    /**
     * 获取分页列表
     * @param page
     * @param usePowerFlow
     * @return
     */
    IPage<List<UsePowerFlow>> findPage(IPage<UsePowerFlow> page,UsePowerFlow usePowerFlow);

    /**
     * 获取分页列表
     * @param usePowerFlow
     * @return
     */
    List<UsePowerFlow> findPage(UsePowerFlow usePowerFlow);

    /**
     * 根据权限获取列表信息
     * @param page
     * @param usePowerFlow
     * @return
     */
    IPage<List<UsePowerFlow>> findListByAuthorize(IPage<UsePowerFlow> page,UsePowerFlow usePowerFlow);

    /**
     * 根据权限获取列表信息
     * @param usePowerFlow
     * @return
     */
    List<UsePowerFlow> findListByApplicant(UsePowerFlow usePowerFlow);

    /**
     * 新增申请记录
     * @param usePowerFlow
     * @return
     */
    boolean addApply(UsePowerFlow usePowerFlow);

    /**
     * 更新申请记录
     * @param usePowerFlow
     * @return
     */
    boolean updateApply(UsePowerFlow usePowerFlow);

    /**
     * 删除申请记录
     * @param id
     * @return
     */
    boolean deleteApply(String id);

    /**
     * 提交审批
     * @param usePowerFlow
     * @return
     */
    boolean approve(UsePowerFlow usePowerFlow);

}
