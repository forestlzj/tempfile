package com.cloud.portal.data.model;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;

import java.io.Serializable;

/**
 * @author yuhaob
 * @date Created in 2020/4/16 11:16
 * @description:
 * @modified By:yuhaob
 */
@Data
@TableName("T_TARGET_RESOURCE_DAY_COUNT")
public class DataResourceCount extends Model<DataResourceCount> {
   private String id;
   private String owner;
   private String tableId;
   private String tableName;
   private String count;
   private String systemCode;
   private String areaCode;
   private String createDate;
   private String createBy;
   private String updateDate;
   private String updateBy;
   private String delFlag;
   private String countSql;
   private String exceptionDesc;
   private String type;
   private String increCount;
   private String lastCount;
   private String sTableId;
   private String sTableName;
   private String exception;

}
