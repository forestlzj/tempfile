package com.cloud.portal.judged.warn.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.data.util.DataScopeUtil;
import com.cloud.portal.judged.warn.mapper.WarnInfoMapper;
import com.cloud.portal.judged.warn.model.WarnInfo;
import com.cloud.portal.judged.warn.service.WarnInfoService;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

/**
 * @author wengshij
 * @date Created in 2019/6/25 9:52
 * @description: 异常警告信息
 * @modified By:wengshij
 */
@Service
public class WarnInfoServiceImpl extends ServiceImpl<WarnInfoMapper, WarnInfo> implements WarnInfoService {
    @Override
    public IPage<WarnInfo> findPage(IPage<WarnInfo> page, WarnInfo warnInfo) {

        return this.baseMapper.findPage(page, initSearch(warnInfo));
    }

    /**
     * 初始化 查询条件信息
     *
     * @param warnInfo
     * @return
     */
    private WarnInfo initSearch(WarnInfo warnInfo) {
        String symbol = ",";
        if (null == warnInfo) {
            warnInfo = new WarnInfo();
        }
        String searchTime = StringUtils.isBlank(warnInfo.getSearchTime()) ? null : warnInfo.getSearchTime().trim();
        if (StringUtils.isNotBlank(searchTime) && warnInfo.getSearchTime().contains(symbol)) {
            String[] searchDate = StringUtils.split(warnInfo.getSearchTime(), symbol);
            if (ArrayUtils.isNotEmpty(searchDate) && searchDate.length == 2) {
                warnInfo.setStartTime(searchDate[0]);
                warnInfo.setEndTime(searchDate[1]);
            }
        }
        warnInfo.setDataScope(DataScopeUtil.getDataScopeSql("W.DEPT_CODE", ""));
        return warnInfo;
    }

    /**
     * 更新下发状态
     * @param id
     */
    @Override
    public boolean updateSendById(String id) {
        return this.baseMapper.updateSendById(id);
    }

    /**
     * 根据id获取警告信息
     * @param id
     * @return
     */
    public WarnInfo findOne(String id) {
        return this.baseMapper.findOne(id);
    }

    /**
     * 更新是否自动预警状态
     * @param id
     * @param isAutoSend
     */
    @Override
    public boolean updateIsAutoSend(String id, String isAutoSend) {
        return this.baseMapper.updateIsAutoSend(id,isAutoSend);
    }
}
