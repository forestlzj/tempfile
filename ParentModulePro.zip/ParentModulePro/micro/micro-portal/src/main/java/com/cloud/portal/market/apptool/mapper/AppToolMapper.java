package com.cloud.portal.market.apptool.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.apptool.model.AppTool;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * @author wengshij
 * @date Created in 2020/3/11 10:06
 * @description: 应用工具数据操作层
 * @modified By:wengshij
 */
public interface AppToolMapper extends BaseMapper<AppTool> {

    /**
     * 获取应用工具列表信息（分）
     *
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> getListPage(IPage<AppTool> page, @Param("query") AppTool appTool);

    /**
     * 获取应用工具信息
     *
     * @param appId
     * @return
     */
    AppTool getAll(String appId);

    /**
     * 获取应用工具列表信息（不分页）
     *
     * @param appTool
     * @return
     */
    List<AppTool> getListPage(@Param("query") AppTool appTool);

    /**
     * 获取没有使用权限的信息列表
     *
     * @param appTool
     * @return
     */
    List<AppTool> getNoAuthorizeList(@Param("query") AppTool appTool);

    /**
     * 获取所有 工具信息、门户使用到
     *
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> findAllToolPage(IPage<AppTool> page, @Param("query") AppTool appTool);

    /**
     * 获取工具排名前十列表
     *
     * @param appTool
     * @return
     */
    List<AppTool> findTopToolList(@Param("query") AppTool appTool);

    /**
     * 预览次数累加
     *
     * @param appToolId
     * @return
     */
    int countUpViewNum(@Param("appToolId")String appToolId);

    /**
     * 获取所有 应用信息、门户使用到
     *
     * @param appTool
     * @return
     */
    IPage<AppTool> findAllAppPage(IPage<AppTool> page, @Param("query") AppTool appTool);

    /**
     * 统计可申请应用
     * @param appTool
     * @return
     */
    int totalIsApplyApp(@Param("query")AppTool appTool);

    /**
     * 获取应用工具分类信息（门户前端使用）
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> findAppToolKind(IPage<AppTool> page, @Param("query") AppTool appTool);

    /**
     * 应用工具统计
     * @return
     */
    List<Map> getAppToolCount();

    /**
     * 个人工作台 获取当前用户所有应用、工具
     * @param appTool
     * @return
     */
    List<AppTool> getUserAppToolList(@Param("query") AppTool appTool);

    /**
     * 获取有权限并存在操作手册的应用工具列表
     * @param name
     * @param bussType
     * @param userId
     * @return
     */
    List<AppTool> findHasOptManualAuthorizeList(@Param("name") String name,@Param("bussType") String bussType,@Param("userId") String userId);
}
