package com.cloud.portal.market.tag.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.tag.entity.Tag;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/11 16:50
 * @description:
 * @modified By:maojia
 */
public interface TagService extends IService<Tag> {

    /**
     * 查询列表（分页）
     * @param page
     * @param tag
     * @return
     */
    IPage<List<Tag>> findListPage(IPage<Tag> page, @Param("tag") Tag tag);

    /**
     * 根据类型获取列表
     * @param type
     * @return
     */
    List<Tag> findListByType(String type);

    /**
     * 新增
     * @param tag
     * @return
     */
    int saveTag(Tag tag);

    /**
     * 修改
     * @param tag
     * @return
     */
    int updateTag(Tag tag);


    /**
     * 查看是否重复
     * @param tag
     * @return
     */
    boolean hasExistTag(Tag tag);
}
