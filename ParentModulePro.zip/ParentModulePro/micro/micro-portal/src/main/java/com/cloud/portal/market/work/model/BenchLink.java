package com.cloud.portal.market.work.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.Max;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:41
 * @description:个人工作台关联信息
 * @modified By:liuwei
 */
@Data
@TableName("T_PORTAL_WORK_BENCH_LINK")
@EqualsAndHashCode(callSuper = true)
public class BenchLink extends Model<BenchLink> {
    /**
     * 组件id
     */
    private String componentId;
    /**
     * 工作台id
     */
    private String workBenchId;
    /**
     * 排序
     */
    private Integer sorts;
    /**
     * 显示方式（1:左边,2:右边）
     */
    private String showStyle;
    /**
     * 组件信息
     */
    @TableField(exist = false)
    private BenchComponent benchComponent;
}
