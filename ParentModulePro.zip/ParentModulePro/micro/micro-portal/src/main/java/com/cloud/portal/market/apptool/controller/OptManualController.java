package com.cloud.portal.market.apptool.controller;

import cn.hutool.core.io.IoUtil;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.apptool.model.AppToolFlow;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.apptool.service.AppToolFlowService;
import com.cloud.portal.market.apptool.service.OptManualService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.List;

/**
 * @author wengshij
 * @date Created in 2020/3/13 10:21
 * @description:
 * @modified By:wengshij
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/app/tool/opt/manual/")
public class OptManualController {
    /**
     * 操作手册接口信息
     */
    private final OptManualService optManualService;

    private final AppToolFlowService appToolFlowService;

    /**
     * 操作手册上传
     *
     * @param manual
     * @return
     */
    @RequestMapping(value = "uploadManual")
    @ResponseBody
    public R uploadManual(@RequestParam("manual") MultipartFile manual) throws Exception {
        return optManualService.uploadManual(manual);
    }

    /**
     * 清空操作手册信息
     *
     * @param optManual
     * @return
     */
    @DeleteMapping("deleteManual")
    public R deleteManual(OptManual optManual) {
        return optManualService.deleteManual(optManual);
    }

    @GetMapping("list")
    public R getManualList(OptManual optManual) {
        List<OptManual> optManualList = this.optManualService.findList(optManual);
        return R.ok(optManualList);
    }

    @RequestMapping(value = "/downloadManual/{id}")
    @SysLog(value = "操作手册下载")
    @ResponseBody
    public void getManual(@PathVariable("id") String id, HttpServletResponse response) {
        try {
            OptManual optManual = this.optManualService.getById(id);
            response.addHeader("Content-Length", "" + optManual.getFileLen());
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(optManual.getFileName(), "UTF-8"));
            IoUtil.copy(optManualService.downLoadManual(optManual), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }


    @GetMapping(value = "/download/{id}/{flowId}")
    @SysLog(value = "操作手册下载")
    public void downLoadManual(@PathVariable("id") String id, @PathVariable("flowId") String flowId, HttpServletResponse response) {
        try {
            OptManual optManual = new OptManual();
            try {
                AppToolFlow appToolFlow = appToolFlowService.getById(flowId);
                appToolFlow.getAppTool().getOptManualList().stream().forEach(obj -> {
                    if (obj.getId().equals(id)) {
                        optManual.setFiles(obj.getFiles());
                        optManual.setFileName(obj.getFileName());
                        optManual.setFileLen(obj.getFileLen());
                    }
                });
            } catch (Exception e) {
                log.error(e.getMessage());
            }
            if (StringUtils.isBlank(optManual.getFiles())) {
                IoUtil.copy(new ByteArrayInputStream("槽糕、文件已丢失...".getBytes("GBK")), response.getOutputStream());
            } else {
                response.addHeader("Content-Length", "" + optManual.getFileLen());
                response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(optManual.getFileName(), "UTF-8"));
                IoUtil.copy(optManualService.downLoadManual(optManual), response.getOutputStream());
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }


}
