package com.cloud.portal.market.tag.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.judged.instruction.model.Instruction;
import com.cloud.portal.market.tag.entity.Tag;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/11 16:18
 * @description:
 * @modified By:maojia
 */
@Mapper
public interface TagMapper extends BaseMapper<Tag> {

    /**
     * 查询列表（分页）
     * @param page
     * @param tag
     * @return
     */
    IPage<List<Tag>> findListPage(IPage<Tag> page, @Param("tag") Tag tag);

    /**
     * 根据类型查询列表
     * @param type
     * @return
     */
    List<Tag> findListByType(@Param("type") String type);

    /**
     * 新增
     * @param tag
     * @return
     */
    int saveTag(Tag tag);

    /**
     * 修改
     * @param tag
     * @return
     */
    int updateTag(Tag tag);

    /**
     * 查看是否重复
     * @param tag
     * @return
     */
    int existTag(Tag tag);







}
