package com.cloud.portal.market.services.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.services.entity.ServiceFile;

import java.io.InputStream;
import java.util.List;

/**
 * @author chenchunl
 * @date Created in 2020/4/9 14:31
 * @description:
 * @modified By:chenchunl
 */
public interface ServiceFileService extends IService<ServiceFile> {

    /**
     * 通过服务id查询相关附件信息
     * @param id
     * @return
     */
    List<ServiceFile> findServiceFileByServiceId(String id);

    /**
     * 通过服务id删除附件信息
     * @param serviceId
     * @return boolean
     */
    boolean delFileByServiceId (String serviceId);

    /**
     * 下载文件
     * @param serviceFile
     * @return
     */
    InputStream downLoadServiceFile(ServiceFile serviceFile);
}
