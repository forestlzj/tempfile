package com.cloud.portal.market.apptool.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.apptool.model.UsePowerFlow;
import com.cloud.portal.market.apptool.service.UsePowerFlowService;
import com.cloud.portal.market.common.constant.MarketConstants;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/18 13:19
 * @description: 应用工具申请访问流程控制层
 * @modified By: huangyingx
 */
@RestController
@AllArgsConstructor
@RequestMapping("/market/app_tool/use_power_flow")
public class UsePowerFlowController {

    @Autowired
    private UsePowerFlowService usePowerFlowService;

    @GetMapping("/page")
    @SysLog(value = "获取列表信息")
    @ApiOperation(httpMethod = "GET", value = "获取列表信息")
    public R findList(Page page,UsePowerFlow usePowerFlow){
        return new R<>(usePowerFlowService.findPage(page,usePowerFlow));
    }

    @GetMapping("/get/{id}")
    @SysLog(value = "根据id获取信息")
    public R getOne(@PathVariable("id") String id){
        return new R<>(usePowerFlowService.getById(id));
    }

    @GetMapping("/authorize/page")
    @SysLog(value="按权限获取查询列表信息")
    public R findListByAuthorize(Page page,UsePowerFlow usePowerFlow){
        return new R<>(usePowerFlowService.findListByAuthorize(page,usePowerFlow));
    }

    @GetMapping("/authorize/list")
    @SysLog(value="获取申请人提交的列表信息")
    public R findListByAuthorize(UsePowerFlow usePowerFlow){
        return new R<>(usePowerFlowService.findListByApplicant(usePowerFlow));
    }

    @PostMapping("/add")
    @SysLog(value = "新增记录",type = CommonConstants.LOG_ADD)
    @PreAuthorize("@pms.hasPermission('app_tool_submit_use')")
    public R saveApply(@RequestBody UsePowerFlow usePowerFlow){
        //校验是否重复提交
        if(UsePowerFlow.STATUS_EXAMINATION.equals(usePowerFlow.getStatus())){
            UsePowerFlow search = new UsePowerFlow();
            search.setAppToolIds(usePowerFlow.getAppToolIds());
            search.setBussType(usePowerFlow.getBussType());
            search.setStatus(UsePowerFlow.STATUS_EXAMINATION);
            List<UsePowerFlow> list = usePowerFlowService.findListByApplicant(search);
            if(list!=null && list.size()>0){
                String name = MarketConstants.TOOL_TYPE.equals(usePowerFlow.getBussType())?"工具":"应用";
                return R.failed(list,"有"+list.size()+"个"+name+"重复提交使用申请");
            }
        }
        return new R<>(usePowerFlowService.addApply(usePowerFlow));
    }

    @PostMapping("/update")
    @SysLog(value = "更新记录",type = CommonConstants.LOG_EDIT)
    @PreAuthorize("@pms.hasPermission('app_tool_submit_use')")
    public R updateApply(@RequestBody UsePowerFlow usePowerFlow){
        //校验是否重复提交
        if(UsePowerFlow.STATUS_EXAMINATION.equals(usePowerFlow.getStatus())){
            UsePowerFlow search = new UsePowerFlow();
            search.setAppToolIds(usePowerFlow.getAppToolIds());
            search.setBussType(usePowerFlow.getBussType());
            search.setStatus(UsePowerFlow.STATUS_EXAMINATION);
            List<UsePowerFlow> list = usePowerFlowService.findListByApplicant(search);
            if(list!=null && list.size()>0){
                String name = MarketConstants.TOOL_TYPE.equals(usePowerFlow.getBussType())?"工具":"应用";
                return R.failed(list,"有"+list.size()+"个"+name+"重复提交使用申请");
            }
        }
        return new R<>(usePowerFlowService.updateApply(usePowerFlow));
    }

    @GetMapping("delete/{id}")
    @SysLog(value="删除记录",type = CommonConstants.LOG_DELELE)
    @PreAuthorize("@pms.hasPermission('app_tool_submit_use')")
    public R deleteApply(@PathVariable String id){
        return new R<>(usePowerFlowService.deleteApply(id));
    }

    @PostMapping("approve")
    @SysLog(value="提交审批",type = CommonConstants.LOG_EDIT)
    @PreAuthorize("@pms.hasPermission('app_tool_approve_use')")
    public R approve(@RequestBody UsePowerFlow usePowerFlow){
        return new R<>(usePowerFlowService.approve(usePowerFlow));
    }

}
