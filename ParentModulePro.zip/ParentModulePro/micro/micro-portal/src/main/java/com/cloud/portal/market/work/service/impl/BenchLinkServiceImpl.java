package com.cloud.portal.market.work.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.portal.market.work.mapper.BenchLinkMapper;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchLink;
import com.cloud.portal.market.work.service.BenchLinkService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 * @author liuwei
 * @date Created in 2020/4/9 16:50
 * @description:个人工作台关联信息
 * @modified By:liuwei
 */
@Service
@AllArgsConstructor
public class BenchLinkServiceImpl extends ServiceImpl<BenchLinkMapper, BenchLink> implements BenchLinkService {
     @Override
     public  List<BenchLink> findBenchLink(Bench bench){
      return this.baseMapper.findBenchLink(bench);
     }

    @Override
    public  List<BenchLink> findLeftBenchLink(Bench bench){
        return this.baseMapper.findLeftBenchLink(bench);
    }

    @Override
    public  List<BenchLink> findRightBenchLink(Bench bench){
        return this.baseMapper.findRightBenchLink(bench);
    }

    @Override
   public boolean deleteByBenchId(String workBenchId){
         return this.baseMapper.deleteByBenchId(workBenchId);
   }

    @Override
    public  List<BenchLink> findLinkById(Bench bench){
        return this.baseMapper.findLinkById(bench);
    }

}
