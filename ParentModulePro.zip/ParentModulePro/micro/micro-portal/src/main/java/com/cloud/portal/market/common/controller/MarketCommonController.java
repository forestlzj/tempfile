package com.cloud.portal.market.common.controller;

import com.cloud.common.core.util.R;
import com.cloud.portal.market.common.service.MarketCommonService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wengshij
 * @date Created in 2020/4/1 13:37
 * @description:超市公共管理路由层
 * @modified By:wengshij
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/market/common/")
public class MarketCommonController {

    private final MarketCommonService marketCommonService;

    @GetMapping("get/{tagType}/{catalogType}/{choose}")
    public R getTagCatalog(@PathVariable("tagType") String tagType, @PathVariable("catalogType") String catalogType, @PathVariable("choose") String choose) {
        return marketCommonService.getTagCatalog(tagType, catalogType, choose);
    }


}
