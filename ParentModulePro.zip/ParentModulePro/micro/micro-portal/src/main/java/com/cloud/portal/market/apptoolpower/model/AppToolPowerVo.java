package com.cloud.portal.market.apptoolpower.model;

import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.entity.SysUser;
import lombok.Data;


/**
 * @author liuwei
 * @date Created in 2020/4/7 10:08
 * @description:
 * @modified By:liuwei
 */
@Data
public class AppToolPowerVo extends SysUser{

    /**
     * 工具数
     */
    private String toolNum;
    /**
     * 应用数
     */
    private String appNum;
}






