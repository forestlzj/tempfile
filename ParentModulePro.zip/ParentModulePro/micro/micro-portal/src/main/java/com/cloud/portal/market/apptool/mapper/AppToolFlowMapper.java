package com.cloud.portal.market.apptool.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.apptool.model.AppToolFlow;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wengshij
 * @date Created in 2020/3/25 10:21
 * @description:
 * @modified By:wengshij
 */
public interface AppToolFlowMapper extends BaseMapper<AppToolFlow> {

    /**
     * 获取应用工具流程信息
     *
     * @param page
     * @param appToolFlow
     * @return
     */
    IPage<AppToolFlow> getAppToolFlowPage(IPage<AppToolFlow> page, @Param("query") AppToolFlow appToolFlow);

    /**
     * 审批（更新）
     *
     * @param appToolFlow
     * @return
     */
    int approval(AppToolFlow appToolFlow);

    /**
     * 获取流程流转信息
     *
     * @param appToolFlow
     * @return
     */
    List<AppToolFlow> findStepList(@Param("query") AppToolFlow appToolFlow);

    /**
     * 统计是否该应用存在流程
     *
     * @param appToolId 应用工具ID
     * @param userId    用户ID
     * @return
     */
    int getExitByAppToolId(@Param("appToolId") String appToolId, @Param("userId") String userId);

}
