package com.cloud.portal.market.tag.controller;


import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.admin.api.vo.TreeUtil;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;

import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.tag.entity.Tag;
import com.cloud.portal.market.tag.entity.TagLink;
import com.cloud.portal.market.tag.service.TagLinkService;
import com.cloud.portal.market.tag.service.TagService;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/11 16:51
 * @description:
 * @modified By:maojia
 */
@RestController
@RequestMapping("/market/tag")
public class TagController {
    @Autowired
    private TagService tagService;

    @Autowired
    private TagLinkService tagLinkService;


    @GetMapping("/page")
    @SysLog("查询列表（分页）")
    public R findListPage(Page page,Tag tag){
        return new R<>(tagService.findListPage(page,tag));
    }


/*
    @GetMapping("list")
    @SysLog("查询列表")
    public List<Tag> findList(Tag tag){
        return tagService.list(Wrappers.query());
    }
*/

    @GetMapping("/list/{type}")
    @SysLog(value = "根据类型获取列表信息")
    @ApiOperation(httpMethod = "GET", value = "根据类型获取列表信息")
    public R findListByType(@PathVariable("type") String type){
        return new R<>(tagService.findListByType(type),"0");
    }


    @GetMapping("/get/{id}")
    @SysLog("根据id查询")
    public R getById(@PathVariable String id) {
        return R.ok(tagService.getById(id));
    }


    @SysLog(value = "新增",type = CommonConstants.LOG_ADD)
    @PostMapping("/save")
    public R save(@RequestBody Tag tag){
        if(tagService.hasExistTag(tag)){
            return R.failed("该名称已存在,请重新输入");
        }else {
            return new R<>(tagService.saveTag(tag));
        }
    }

    @SysLog(value = "修改",type = CommonConstants.LOG_EDIT)
    @PutMapping("/update")
    public R updateById(@RequestBody Tag tag){
        if(tagService.hasExistTag(tag)){
            return R.failed("该名称已存在,请重新输入");
        }else {
            return new R<>(tagService.updateTag(tag));
        }
    }

    @SysLog(value = "根据id删除",type = CommonConstants.LOG_DELELE)
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.TAG_CACHE_NAME, allEntries = true)
    @DeleteMapping("/del/{id}")
    public R removeById(@PathVariable String id){
        List<TagLink> list=tagLinkService.findListByLabelId(id);
       if (list!=null && list.size()>0){
           return R.failed("该目录已被引用，不能删除");
       }else {
           return new R<>(tagService.removeById(id));
       }

    }


    @GetMapping("/link/{appToolId}")
    @SysLog(value = "根据appToolId获取列表信息")
    @ApiOperation(httpMethod = "GET", value = "根据appToolId获取列表信息")
    public R findLinkByAppToolId(@PathVariable("appToolId") String appToolId){
        return new R<>(tagLinkService.findListByAppToolId(appToolId),"0");
    }
}
