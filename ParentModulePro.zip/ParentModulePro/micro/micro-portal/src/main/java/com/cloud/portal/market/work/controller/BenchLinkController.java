package com.cloud.portal.market.work.controller;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:40
 * @description:个人工作台关联信息
 * @modified By:liuwei
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/work/link/")
public class BenchLinkController {
}
