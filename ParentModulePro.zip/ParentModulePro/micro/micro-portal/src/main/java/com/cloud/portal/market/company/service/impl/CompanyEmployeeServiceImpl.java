package com.cloud.portal.market.company.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.company.mapper.CompanyEmployeeMapper;
import com.cloud.portal.market.company.model.CompanyEmployee;
import com.cloud.portal.market.company.service.CompanyEmployeeService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author liuwei
 * @date Created in 2020/3/12 15:22
 * @description:
 * @modified By:liuwei
 */
@Service
@AllArgsConstructor
public class CompanyEmployeeServiceImpl extends ServiceImpl<CompanyEmployeeMapper, CompanyEmployee> implements CompanyEmployeeService{
    /**
     * minio 接口服务信息
     */
    @Autowired
    private MinioTemplate minioTemplate;

    /**
     * 查询开发人员列表（分页）
     * @param page
     * @param companyEmployee
     * @return
     */
   @Override
     public IPage<List<CompanyEmployee>> page(IPage<CompanyEmployee> page, CompanyEmployee companyEmployee){
        return this.baseMapper.findListPage(page,companyEmployee);
    }
    @Override
    public R deleteAvatar(String base64Id) {
        try {
            minioTemplate.removeObject(PortalConstants.MINIO_EMPLOYEE_AVATAR, Base64.decodeStr(base64Id));
        } catch (Exception e) {
            e.printStackTrace();
            return R.failed();
        }
        return R.ok();
    }

    @Override
    public R uploadAvatar(MultipartFile file) throws Exception {
        StringBuffer nameBuffer = new StringBuffer();
        Map<String, String> result = new HashMap<>(2);
        minioTemplate.createBucket(PortalConstants.MINIO_EMPLOYEE_AVATAR);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String fileName = file.getOriginalFilename();
        result.put("name", fileName);
        String newFileName = IdUtil.randomUUID() + fileName.substring(fileName.lastIndexOf("."));
        nameBuffer.append("avatar").append("/")
                .append(SecurityUtils.getUser().getId()).append("/")
                .append(sdf.format(System.currentTimeMillis())).append("/")
                .append(newFileName);
        minioTemplate.putObject(PortalConstants.MINIO_EMPLOYEE_AVATAR, nameBuffer.toString(), file.getInputStream());
        String baseId = Base64.encode(nameBuffer.toString());
        result.put("baseId", baseId);
        result.put("url", "portal/comp/employee/getAvatar/" + baseId);
        return R.ok(result);
    }

    @Override
    public InputStream downLoadAvatar(String base64Id) {
        String fileName = Base64.decodeStr(base64Id);
        InputStream inputStream = minioTemplate.getObject(PortalConstants.MINIO_EMPLOYEE_AVATAR, fileName);
        return inputStream;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean saveEmployee(CompanyEmployee employee) {
        employee = employeeInit(employee);
        return SqlHelper.delBool(this.baseMapper.insert(employee));
    }

    private CompanyEmployee employeeInit(CompanyEmployee employee) {
        MicroUser user = SecurityUtils.getUser();
        employee.setId(IdUtil.randomUUID());
        employee.setCreateTime(new Date(System.currentTimeMillis()));
        employee.setCreateBy(user.getId());
        employee.setUpdateBy(user.getId());
        employee.setDelFlag(CommonConstants.STATUS_NORMAL);
        employee.setUpdateTime(employee.getCreateTime());
        return employee;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateEmployee(CompanyEmployee companyEmployee) {
        companyEmployee = initEmployee(companyEmployee);
        return SqlHelper.delBool(this.baseMapper.updateById(companyEmployee));
    }

    private CompanyEmployee initEmployee(CompanyEmployee companyEmployee) {
         //更新前数据
        CompanyEmployee firstEmployee = this.getById(companyEmployee.getId());
        //判断两个图标是否相同
        if(firstEmployee.getAvatar()!=null) {
            if (!firstEmployee.getAvatar().equals(companyEmployee.getAvatar())) {
                this.deleteAvatar(firstEmployee.getAvatar());
            }
        }

        MicroUser microUser = SecurityUtils.getUser();
        companyEmployee.setUpdateTime(new Date(System.currentTimeMillis()));
        companyEmployee.setUpdateBy(microUser.getId());
        companyEmployee.setDelFlag(CommonConstants.STATUS_NORMAL);
        return companyEmployee;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateDelById(List<String> list){
        return  this.baseMapper.updateDelById(list);
    }
}
