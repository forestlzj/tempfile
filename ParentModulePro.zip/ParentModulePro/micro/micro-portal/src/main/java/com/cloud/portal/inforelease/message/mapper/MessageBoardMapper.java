package com.cloud.portal.inforelease.message.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.inforelease.message.model.MessageBoard;
import com.cloud.portal.inforelease.message.model.MessageBoardPraise;
import org.apache.ibatis.annotations.Param;

/**
 * @author rush
 * @Date Created in 2020/3/12 15:26
 * Description:
 * Modified By:
 */
public interface MessageBoardMapper extends BaseMapper<MessageBoard> {
    /**
     * 获取留言板列表信息
     *
     * @param page
     * @param messageBoard
     * @return
     */
    IPage<MessageBoard> getListPage(IPage<MessageBoard> page, @Param("query") MessageBoard messageBoard);

    /**
     * 根据ID查询留言并关联用户信息
     *
     * @param id
     * @return MessageBoard
     */
    MessageBoard getMessageBoardById(@Param("id") String id,@Param("userId") String userId);

    /**
     * 修改点赞数量
     * @param boardId 留言板id
     * @param num
     * @return
     */
    boolean updateLickCount(@Param("boardId") String boardId, @Param("num") int num);

    /**
     * 删除留言
     * @param id 留言板id
     * @return
     */
    boolean deleteMessageBoard(@Param("id") String id);

    /**
     * 留言板点赞
     * @param  messageBoardPraise
     * @return
     */
    boolean savePraise(MessageBoardPraise messageBoardPraise);

    /**
     * 取消留言板点赞
     * @param boardId 留言板id
     * @param userId  用户id
     * @return
     */
    boolean deletePraise(@Param("boardId") String boardId, @Param("userId") String userId);
}
