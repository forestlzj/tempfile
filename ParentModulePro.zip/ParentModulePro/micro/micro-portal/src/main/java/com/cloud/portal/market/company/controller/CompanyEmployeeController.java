package com.cloud.portal.market.company.controller;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.IoUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.company.model.Company;
import com.cloud.portal.market.company.model.CompanyEmployee;
import com.cloud.portal.market.company.service.CompanyEmployeeService;
import com.cloud.portal.market.company.service.CompanyService;
import com.google.common.base.Splitter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * @author  liuwei
 * @date Created in 2020/3/12 14:52
 * @description:软件公司管理员工控制层
 * @modified By:liuwei
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/comp/employee/")
public class CompanyEmployeeController {
    /**
     * 公司员工接口层
     */
    @Autowired
    private CompanyEmployeeService companyEmployeeService;

    /**
     * 分页查询 公司员工信息
     *
     * @param page    分页对象
     * @param companyEmployee 开发公司实体类
     * @return
     */
    @GetMapping("page")
    @SysLog(value = "公司员工查询")
    public R getPersonConcernPage(Page page, CompanyEmployee companyEmployee ) {
        return R.ok(companyEmployeeService.page(page, Wrappers.query(companyEmployee)));
    }

    /**
     * 分页查询 开发员工信息
     *
     * @param page    分页对象
     * @param companyEmployee 开发公司实体类
     * @return
     */
    @GetMapping("developPage")
    @SysLog(value = "公司员工查询")
    public R getDevelopPage(Page page, CompanyEmployee companyEmployee ) {
        return R.ok(companyEmployeeService.page(page, companyEmployee));
    }

    @DeleteMapping("deleteAvatar/{base64Id}")
    public R deleteAvatar(@PathVariable String base64Id) {
        return companyEmployeeService.deleteAvatar(base64Id);
    }

    @RequestMapping(value = "uploadAvatar")
    @ResponseBody
    public R upload(MultipartFile file) throws Exception {
        return companyEmployeeService.uploadAvatar(file);
    }

    @RequestMapping(value = "getAvatar/{base64Id}")
    @ResponseBody
    public void getAvatar(@PathVariable("base64Id") String base64Id, HttpServletResponse response) {
        try {
            String avatarName = Base64.decodeStr(base64Id);
            avatarName = avatarName.substring(avatarName.lastIndexOf("/") + 1);
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(avatarName, "UTF-8"));
            IoUtil.copy(companyEmployeeService.downLoadAvatar(base64Id), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /**
     * 新增 开发人员
     *
     * @param employee
     * @return R
     */
    @SysLog(value = "开发人员新增", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    public R save(@RequestBody CompanyEmployee employee) {
        return R.ok(companyEmployeeService.saveEmployee(employee));
    }

    /**
     * 通过id查询 员工
     *
     * @param employeeId employeeId
     * @return R
     */
    @GetMapping("get/{employeeId}")
    public R getById(@PathVariable("employeeId") String employeeId) {
        return R.ok(companyEmployeeService.getById(employeeId));
    }

    /**
     * 修改 员工信息
     *
     * @param companyEmployee
     * @return R
     */
    @SysLog(value = "员工信息修改", type = CommonConstants.LOG_EDIT)
    @PostMapping("update")
    public R updateById(@RequestBody CompanyEmployee companyEmployee) {

        return R.ok(companyEmployeeService.updateEmployee(companyEmployee));
    }

    /**
     * 通过id删除 员工信息
     *
     * @param ids 主键ID
     * @return R
     */
    @SysLog(value = "员工信息删除", type = CommonConstants.LOG_DELELE)
    @DeleteMapping("delete/{ids}")
    public R removeById(@PathVariable String ids) {
        List<String> idList = Splitter.on(",").trimResults().splitToList(ids);
        if(idList.size()>1) {
            List<String> lists = new ArrayList<>();
            for (int i = 0; i < idList.size() - 1; i++) {
                lists.add(idList.get(i));
            }
            idList=lists;
        }
        return R.ok(companyEmployeeService.updateDelById(idList));
    }

}
