package com.cloud.portal.market.company.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.judged.instruction.model.Instruction;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.company.model.Company;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/11 17:17
 * @description: 开发公司数据操作层
 * @modified By:liuwei
 */

public interface CompanyMapper extends BaseMapper<Company> {
    /**
     * 获取开发公司列表信息
     * @param page
     * @param company
     * @return
     */
    IPage<List<Company>> findListPage(IPage<Company> page, @Param("company") Company company);
    /**
     * 更新删除标识
     * @param list
     * @return
     */
    boolean updateDel(List<String> list);

    /**
     * 根据id获取公司信息（包括开发人员）
     * @param id
     * @return
     */
    Company getAllById(@Param("id") String id);
}
