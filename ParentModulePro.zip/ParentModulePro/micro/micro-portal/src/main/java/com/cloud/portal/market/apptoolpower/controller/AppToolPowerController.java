package com.cloud.portal.market.apptoolpower.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.apptoolpower.model.AppToolPowerVo;
import com.cloud.portal.market.apptoolpower.service.AppToolPowerService;
import lombok.AllArgsConstructor;
import com.cloud.portal.market.apptoolpower.model.AppToolPower;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/31 10:18
 * @description:应用工具权限分配
 * @modified By:liuwei
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/appTool/power/")
public class AppToolPowerController {
    /**
     * 应用工具权限接口层
     */
    @Autowired
    private AppToolPowerService appToolPowerService;

    /**
     * 获得用户的应用工具id信息
     * @param appToolPower
     * @return
     */
    @GetMapping("list")
    @SysLog(value = "获取列表信息(不分页)")
    public List<String> findList(AppToolPower appToolPower) {
        List<AppToolPower> appToolPowerList=appToolPowerService.getList(appToolPower);
        List<String> strings=new ArrayList<>();
        for (int i=0;i<appToolPowerList.size();i++){
            strings.add(appToolPowerList.get(i).getAppToolId());
        }
        return strings;
    }
    /**
     * 新增 应用权限
     *
     * @param appToolPower
     * @return R
     */
    @SysLog(value = "新增应用权限", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    public R save(@RequestBody AppToolPower appToolPower) {
        return R.ok(appToolPowerService.saveAppToolPower(appToolPower));
    }


    /**
     * 通过用户id删除 用户应用工具权限
     *
     * @param userId 用户id
     * @return R
     */
    @SysLog(value = "用户应用工具权限删除", type = CommonConstants.LOG_DELELE)
    @DeleteMapping("delete/{userId}")
    public R removeByUserId(@PathVariable String userId) {
        return R.ok(appToolPowerService.removeById(userId));
    }

    /**
     * 更新用户应用工具权限
     *
     * @param appToolPower
     * @return R
     */
    @SysLog(value = "更新用户工具权限",type = CommonConstants.LOG_EDIT)
    @PutMapping("userAppToolUpdate")
    public R updateUserAppTool(@RequestBody AppToolPower appToolPower) {
        return new R<>(appToolPowerService.updateAppToolPower(appToolPower));
    }

    /**
     * 分页查询 用户应用工具数
     *
     * @param page    分页对象
     * @param appToolPowerVo 用户实体类
     * @return
     */
    @GetMapping("page")
    public R getAppToolPage(Page page, AppToolPowerVo appToolPowerVo) {
        return R.ok(appToolPowerService.toolAppNum(page, appToolPowerVo));

    }

    /**
     * 校验应用工具集合当前用户是否有授权
     * @param ids
     * @return
     */
    @GetMapping("exists")
    public R existsPower(@RequestParam(value = "ids",required = true)  String ids,
                         @RequestParam(value = "status",required = false)String status){
        return R.ok(appToolPowerService.exists(ids,status));
    }


    /**
     * 更新用户应用工具信息（显隐、排序）
     *
     * @param appToolPower
     * @return R
     */
    @SysLog(value = "更新用户应用工具信息",type = CommonConstants.LOG_EDIT)
    @PutMapping("updateUserAppToolById")
    public R updateUserAppToolById(@RequestBody AppToolPower appToolPower) {
        return new R<>(appToolPowerService.updateUserAppToolById(appToolPower));
    }

}
