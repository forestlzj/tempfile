package com.cloud.portal.market.work.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.work.mapper.BenchMapper;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchLink;
import com.cloud.portal.market.work.service.BenchLinkService;
import com.cloud.portal.market.work.service.BenchService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:33
 * @description:个人工作台信息
 * @modified By:liuwei
 */
@Service
@AllArgsConstructor
public class BenchServiceImpl extends ServiceImpl<BenchMapper, Bench> implements BenchService {
    @Autowired
    private BenchLinkService benchLinkService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveBench(Bench bench) {
        List<BenchLink> benchLinks=new ArrayList<>();
        Bench ownBench=new Bench();
        Bench bench2;
        String defaultShareType="0";
        if(StringUtils.isNotBlank(bench.getShareType()) && defaultShareType.equals(bench.getShareType())){
            bench2=this.baseMapper.defaultBench();
        }else{
            MicroUser microUser = SecurityUtils.getUser();
            ownBench.setUserId(microUser.getId());
            bench2=this.baseMapper.findOwnBench(ownBench);
        }
        try{
            if(bench2!=null) {
                this.benchLinkService.deleteByBenchId(bench2.getId());
                this.baseMapper.deleteById(bench2.getId());
            }
            Bench bench1 = initBench(bench);
            this.baseMapper.insert(bench1);
            if(bench.getBenchLinks()!=null){
                for (int i = 0; i < bench.getBenchLinks().size(); i++) {
                    BenchLink benchLink=new BenchLink();
                    BeanUtils.copyProperties(bench.getBenchLinks().get(i),benchLink);
                    benchLink.setWorkBenchId(bench1.getId());
                    benchLinks.add(benchLink);
                }
            }
            if(bench.getBenchLeftLinks()!=null){
                for (int i = 0; i < bench.getBenchLeftLinks().size(); i++) {
                    BenchLink benchLink=new BenchLink();
                    BeanUtils.copyProperties(bench.getBenchLeftLinks().get(i),benchLink);
                    benchLink.setWorkBenchId(bench1.getId());
                    benchLinks.add(benchLink);
                }
            }
            if(bench.getBenchRightLinks()!=null){
                for (int i = 0; i < bench.getBenchRightLinks().size(); i++) {
                    BenchLink benchLink=new BenchLink();
                    BeanUtils.copyProperties(bench.getBenchRightLinks().get(i),benchLink);
                    benchLink.setWorkBenchId(bench1.getId());
                    benchLinks.add(benchLink);
                }
            }
            if(benchLinks!=null){
                this.benchLinkService.saveBatch(benchLinks);
            }
        }catch(Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }


    private Bench initBench(Bench bench){
        MicroUser microUser = SecurityUtils.getUser();
        bench.setUserId(microUser.getId());
        if(StringUtils.isBlank(bench.getShareType())){
            bench.setShareType("1");
        }else{
            bench.setShareType(bench.getShareType());
        }
        bench.setCreateBy(microUser.getId());
        bench.setCreateTime(new Date(System.currentTimeMillis()));
        bench.setUpdateTime(bench.getCreateTime());
        return bench;
    }

    @Override
    public Bench findBench(Bench bench){
        Bench bench1=this.baseMapper.defaultBench();
        MicroUser microUser = SecurityUtils.getUser();
        bench.setUserId(microUser.getId());
        Bench ownBench;
        String style1 = "1";
        String style2 = "2";
        if(StringUtils.isNotBlank(bench.getShareType())) {
                if(StringUtils.isBlank(bench.getStyleType())){
                    ownBench = bench1;
                }else{
                    if(bench.getStyleType().equals(bench1.getStyleType())){
                        ownBench = bench1;
                    }else {
                        ownBench = null;
                    }
                }
        }else {
            ownBench = this.baseMapper.findOwnBench(bench);
            if (StringUtils.isBlank(bench.getStyleType())) {
                if (ownBench == null) {
                    ownBench = bench1;
                }else{
                    List<BenchLink> benchLinks=this.benchLinkService.findLinkById(ownBench);
                    if(benchLinks.size()<1){
                        ownBench = bench1;
                    }
                }
            } else {
                if (ownBench == null) {
                    if (bench1.getStyleType().equals(bench.getStyleType())) {
                        ownBench = bench1;
                    }
                }else{
                    List<BenchLink> benchLinks=this.benchLinkService.findLinkById(ownBench);
                    if(bench1.getStyleType().equals(bench.getStyleType())&&benchLinks.size()<1){
                        ownBench = bench1;
                    }
                }
            }
        }
       if(ownBench!=null) {
           if(style1.equals(ownBench.getStyleType())){
                   ownBench.setBenchLeftLinks(this.benchLinkService.findLeftBenchLink(ownBench));
                   ownBench.setBenchRightLinks(this.benchLinkService.findRightBenchLink(ownBench));
           }
           else if(style2.equals(ownBench.getStyleType())){
               ownBench.setBenchLinks(this.benchLinkService.findBenchLink(ownBench));
           }
       }
        return ownBench;
    }

    @Override
    public Bench findOwnBench(Bench bench) {
        return this.baseMapper.findOwnBench(bench);
    }

    @Override
    public Bench defaultBench() {
        return this.baseMapper.defaultBench();
    }


    @Override
    public IPage<Bench> findBenchPage(IPage<Bench> page) {
        return this.baseMapper.getBenchPage(page);
    }
}
