package com.cloud.portal.data.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.data.model.DataResourceCount;

import java.util.List;
import java.util.Map;

/**
 * @author yuhaob
 * @date Created in 2020/4/16 11:17
 * @description:
 * @modified By:yuhaob
 */
public interface DataResourceCountService extends IService<DataResourceCount> {
    List<Map<String, Object>> getNewMap();

    List<Map<String, Object>> getNewSys();

    List<Map<String, Object>> getNewCity();
}
