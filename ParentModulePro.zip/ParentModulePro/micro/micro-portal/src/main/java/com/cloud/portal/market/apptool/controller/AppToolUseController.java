package com.cloud.portal.market.apptool.controller;

import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.apptool.model.AppToolUse;
import com.cloud.portal.market.apptool.service.AppToolUseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author maojia
 * @date Created in 2020/3/24 9:19
 * @description:
 * @modified By:maojia
 */
@RestController
@RequestMapping("/app/tool/use")
public class AppToolUseController {

    @Autowired
    private AppToolUseService appToolUseService;

    @GetMapping("/findList")
    @SysLog("最近使用")
    public R findList(AppToolUse appToolUse) {
        appToolUse.setUserId(SecurityUtils.getUser().getId());
        return R.ok(appToolUseService.getUseList(appToolUse));
    }

}
