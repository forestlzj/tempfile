

package com.cloud.portal.judged.model.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.cloud.admin.api.dto.TreeNode;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * @author ryt
 * @date Created in 2019/6/22 11:17
 * @description: 研判模型tree
 * @modified By:
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ModelMenuTree extends TreeNode {
    /**链接地址*/
    private String links;
    /**模型名称*/
    private String name;
    /**模型打开方式 */
    private String openType;
    /**父级ID*/
    private String parentIds;
    /**权限标识*/
    private String permission;
    /**预案库ID集合*/
    private String planLibId;
    /**简要信息*/
    private String remark;
    /**显示或隐藏 字典是否*/
    private String showHide;
    /**排序*/
    private Integer sort;
    /**评价星级（5星）*/
    private Integer stars;
    /**类型（标题、目录 、模型）*/
    private String type;
    /**模型唯一标识符（可作为字典）*/
    private String udId;
    /**推荐使用 字典是否*/
    private String useBest;
    /**浏览次数*/
    private Integer viewTimes;

    /**创建时间 研判模型展示用*/
    @TableField(exist = false)
    private String createDate;
    /**是否收藏*/
    private String isCollect;
    /**模型状态（0启用、1建设中）仅用于模型跳转控制*/
    private String state;
    /**获取目录下的app数量*/
    @TableField(exist = false)
    private Integer appNums;

    /**警告详情链接*/
    private String detailLink;
    /**模型分类（0研判模型、1预警模型）*/
    private String modelType;
    /**预警级别（一般（IV级）、较重（Ⅲ级）、严重（Ⅱ级）、特别严重（Ⅰ级））用于模型分类为预警模型时*/
    private String warnLevel;

}
