package com.cloud.portal.market.services.controller;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.IoUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.services.entity.ServiceFile;
import com.cloud.portal.market.services.entity.ServiceInterface;
import com.cloud.portal.market.services.service.ServiceFileService;
import com.cloud.portal.market.services.service.ServiceInterfaceService;
import com.google.common.base.Strings;
import io.swagger.annotations.Api;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author wuxx
 * @date Created in 2020/3/10 16:50
 * @description: 服务管理
 * @modified By:
 **/
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/service/interface")
@Api(value = "service/interface", description = "服务接口管理模块")
public class ServiceInterfaceController {

    @Autowired
    private ServiceInterfaceService serviceInterfaceService;

    @Autowired
    private ServiceFileService serviceFile;


    /**
     * 简单分页查询
     *
     * @param page             分页对象
     * @param serviceInterface 服务接口
     * @return
     */
    @SysLog(value = "查询服务接口", type = CommonConstants.LOG_QUERY)
    @RequestMapping("/page")
    public R getLogPage(Page page, ServiceInterface serviceInterface) {
        return new R<>(serviceInterfaceService.findPage(page, serviceInterface));
    }

    /**
     * 跟据用户id查询服务
     * @param page
     * @param serviceInterface
     * @return
     */
    @SysLog(value = "查询我的服务接口", type = CommonConstants.LOG_QUERY)
    @RequestMapping("/findServicePage")
    public R findMyService(Page page, ServiceInterface serviceInterface) {

        return new R<>(serviceInterfaceService.findMyServicePage(page, serviceInterface));
    }

    @SysLog(value = "查询可申请的服务接口", type = CommonConstants.LOG_QUERY)
    @RequestMapping("/findApplyService")
    public R findApplyService(Page page, ServiceInterface serviceInterface) {
        return new R<>(serviceInterfaceService.findApplyService(page, serviceInterface));
    }

    @SysLog(value = "查询可申请的服务接口 (不分页)", type = CommonConstants.LOG_QUERY)
    @RequestMapping("/findApplyServiceList")
    public R findApplyServiceList(Page page, ServiceInterface serviceInterface) {
        return new R<>(serviceInterfaceService.findApplyServiceList(serviceInterface));
    }


    @SysLog(value = "查询服务接口（不分页）", type = CommonConstants.LOG_QUERY)
    @GetMapping("/list")
    public R getLogList(ServiceInterface serviceInterface) {
        return new R<>(serviceInterfaceService.findList(serviceInterface));
    }

    @GetMapping("/list/ids/{ids}")
    @SysLog(value = "根据id集合获取信息", type = CommonConstants.LOG_ADD)
    public R findListByIds(@PathVariable String ids) {
        List<ServiceInterface> result = new ArrayList<ServiceInterface>();
        String[] arr = ids.split(",");
        for (int i = 0; i < arr.length; i++) {
            result.add(serviceInterfaceService.getById(arr[i]));
        }
        return new R<>(result);
    }

    /**
     * 添加服务接口
     *
     * @param serviceInterface 服务接口
     * @return success/false
     */
    @SysLog(value = "新增服务接口", type = CommonConstants.LOG_ADD)
/*    @PreAuthorize("@pms.hasPermission('service_interface_add')")*/
    @PostMapping
    public R save(@Valid @RequestBody ServiceInterface serviceInterface) {
        return new R<>(serviceInterfaceService.saveServiceInterface(serviceInterface));
    }


    /**
     * 更新服务接口
     *
     * @param serviceInterface 服务接口
     * @return success/false
     */
    @SysLog(value = "更新服务接口", type = CommonConstants.LOG_EDIT)
 /*   @PreAuthorize("@pms.hasPermission('service_interface_edit')")*/
    @PutMapping
    public R update(@Valid @RequestBody ServiceInterface serviceInterface ) {
        return new R<>(serviceInterfaceService.saveServiceInterface(serviceInterface));
    }


    /**
     * 删除服务接口
     *
     * @param id ID 服务接口id
     * @return success/false
     */
    @SysLog(value = "删除服务接口", type = CommonConstants.LOG_DELELE)
  /*  @PreAuthorize("@pms.hasPermission('service_interface_del')")*/
    @DeleteMapping("/{id}")
    public R removeById(@PathVariable String id) {
        return new R<>(serviceInterfaceService.removeById(id));
    }

    /**
     * 上传图标
     *
     * @param file
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "uploadIcon")
    @ResponseBody
    public R upload(MultipartFile file) throws Exception {
        return serviceInterfaceService.uploadIcon(file);
    }


    /**
     * 获取图标
     *
     * @param base64Id
     * @param response
     */
    @RequestMapping(value = "/getIcon/{base64Id}")
    @ResponseBody
    public void getIcon(@PathVariable("base64Id") String base64Id, HttpServletResponse response) {
        try {
            String fileName = Base64.decodeStr(base64Id);
            fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            IoUtil.copy(serviceInterfaceService.downLoadIcon(base64Id), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }


    /**
     * 删除图标
     *
     * @param base64Id
     * @return
     */
    @DeleteMapping("deleteIcon/{base64Id}")
    public R deleteIcon(@PathVariable String base64Id) {
        return serviceInterfaceService.deleteIcon(base64Id);
    }


    /**
     * 更新服务接口
     *
     * @param serviceInterface 服务接口
     * @return success/false
     */
    @SysLog(value = "更新服务接口", type = CommonConstants.LOG_EDIT)
    @PreAuthorize("@pms.hasPermission('service_interface_edit')")
    @PutMapping(value = "/{id}")
    public R updateStatus(@PathVariable String id, @RequestBody ServiceInterface serviceInterface) {
        String currentUid = SecurityUtils.getUser().getId();
        serviceInterface.setId(id);
        serviceInterface.setUpdateTime(new Date());
        serviceInterface.setUpdateBy(currentUid);
        return new R<>(this.serviceInterfaceService.updateStatus(serviceInterface));
    }

    @SysLog(value = "根据服务id获取相关附件信息", type = CommonConstants.LOG_QUERY)
    @GetMapping("/serviceFile/{id}")
    public R findServiceFileByServiceId(@PathVariable String id) {
        return new R<>(this.serviceFile.findServiceFileByServiceId(id));
    }

    @SysLog(value = "获取热门（调用次数多）服务", type = CommonConstants.LOG_QUERY)
    @GetMapping("/hotService")
    public R findHotService() {
        ServiceInterface serviceInterface = new ServiceInterface();
        return new R<>(this.serviceInterfaceService.findHotService(serviceInterface));
    }


    @RequestMapping(value = "/download/{id}")
    @SysLog(value = "通过附件id下载附件")
    @ResponseBody
    public void downLoadManual(@PathVariable("id") String id,HttpServletResponse response) {
        try {
            ServiceFile serviceFiles = this.serviceFile.getById(id);
            response.addHeader("Content-Length", "" + serviceFiles.getFileLen());
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(serviceFiles.getFileName(), "UTF-8"));
            IoUtil.copy(serviceFile.downLoadServiceFile(serviceFiles), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }


}