package com.cloud.portal.market.apptool.model;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.tag.entity.TagLink;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @author wengshij
 * @date Created in 2020/3/11 10:04
 * @description:应用工具实体类
 * @modified By:wengshij
 */
@Data
@TableName("T_PORTAL_APP_TOOL")
@EqualsAndHashCode(callSuper = true)
public class AppTool extends Model<AppTool> {

    /**
     * 主键ID
     */
    @TableId(type = IdType.UUID)
    @LogField(title = "主键")
    private String id;
    /**
     * 名称
     */
    @LogField(title = "名称")
    private String name;
    /**
     * 链接地址
     */
    @LogField(title = "跳转地址")
    private String links;
    /**
     * 公司ID
     */
    @LogField(title = "公司主键")
    private String companyId;
    /**
     * 业务类型(app-应用 tool-工具)
     */
    private String bussType;
    /**
     * 权限标识
     */
    private String permission;
    /**
     * 简介
     */
    private String remark;
    /**
     * 打开方式（0-打开新页面,1-弹出框）
     */
    @LogField(title = "打开方式")
    private String openType;
    /**
     * 状态（0-上架,1-下架,2-其他）
     */
    @LogField(title = "状态")
    private String status;
    /**
     * 排序
     */
    private int sort;
    /**
     * 图标(存储在MINIO中)
     */
    private String icon;
    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * 是否对接单点登录（0 是 1否）
     */
    @LogField(title = "对接单点登录")
    private String isSso;
    /**
     * 删除标识
     */
    @TableLogic
    private String delFlag;
    /**
     * 浏览次数
     */
    @LogField(title = "浏览次数")
    private int viewNum;
    /**
     * 上架时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @LogField(title = "上架时间")
    private Date upTime;
    /**
     * 操作文档信息
     */
    @TableField(exist = false)
    private List<OptManual> optManualList;
    /**
     * 编目ID
     */
    @TableField(exist = false)
    private String catalogId;
    /**
     * 编目名称
     */
    @TableField(exist = false)
    private String catalogName;

    /**
     * 标签ID
     */
    @TableField(exist = false)
    private List<String> labelId;

    /**
     * 编目ID集合
     */
    @TableField(exist = false)
    private List<String> catalogIdList;


    /**
     * 编目关联信息
     */
    @TableField(exist = false)
    private List<CatalogLink> catalogLinkList;

    /**
     * 标签信息
     */
    @TableField(exist = false)
    private List<TagLink> tagLinkList;
    /**
     * 应用工具操作类型（走流程时候使用到）
     * 0 -上架
     * 1-下架
     * 2-更新
     */
    @TableField(exist = false)
    private String optType;

    /**
     * 应用工具流程处理状态
     * 0 -草稿
     * 1-流转中
     * 2驳回
     * 3 审批通过
     */
    @TableField(exist = false)
    private String flowStatus;

    /**
     * 申请说明
     */
    @TableField(exist = false)
    private String applyExplain;
    /**
     * 应用工具流程主键ID
     */
    @TableField(exist = false)
    private String appToolFlowId;

    /**
     * 使用人id
     */
    @TableField(exist = false)
    private String userId;
    /**
     * 前十排序
     */
    @TableField(exist = false)
    private String topOrder;
    /**
     * 分页排序
     */
    @TableField(exist = false)
    private String pageOrder;

    /**
     * 是否拥有权限
     * 是 true
     * 否 false
     */
    @TableField(exist = false)
    private boolean hasPower;
    /**
     * 星级 （1-5星级）
     */
    private String grade;
    /**
     * 是否推荐使用
     * 0是 1否
     */
    private String recommend;

    /**
     * 可申请标志，用于查询，值为1查询可申请记录
     */
    @TableField(exist = false)
    private String isApply;
    /**
     * 所属分类、治安类 za、省厅类 st
     */
    private String kind;

    /**
     * 使用状态 0-草稿，1-审批中，2-驳回，3-通过
     */
    @TableField(exist = false)
    private String useStatus;

    /**
     * 0显示 1隐藏
     */
    @TableField(exist = false)
    private String showHide;
    /**
     * 标签名称
     */
    @TableField(exist = false)
    private String labelName;

}
