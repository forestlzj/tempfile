package com.cloud.portal.market.services.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.services.entity.ServiceInterface;
import com.cloud.portal.market.services.entity.ServiceOptFlow;
import com.cloud.portal.market.services.service.ServiceOptFlowService;
import io.swagger.annotations.Api;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author chenchunl
 * @date Created in 2020/4/13 9:40
 * @description: 服务上下架操作申请
 * @modified By:chenchunl
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/service/optflow")
@Api(value = "service/optflow", tags = "服务接口上下架操作申请")
public class ServiceOptFlowController {

    @Autowired
    private ServiceOptFlowService serviceOptFlowService;

    /**
     * 简单分页查询
     *
     * @param page             分页对象
     * @param serviceOptFlow 服务上架/操作申请
     * @return
     */
    @SysLog(value = "查询服务接口申请历史记录列表", type = CommonConstants.LOG_QUERY)
    @RequestMapping("/page")
    public R getLogPage(Page page, ServiceOptFlow serviceOptFlow) {
        return new R<>(serviceOptFlowService.findPage(page, serviceOptFlow));
    }

    /**
     * 添加服务接口申请
     *
     * @param serviceOptFlow 服务接口申请
     * @return success/false
     */
    @SysLog(value = "新增服务接口", type = CommonConstants.LOG_ADD)
    @PostMapping
    public R save(@Valid @RequestBody ServiceOptFlow serviceOptFlow) {
        return new R<>(serviceOptFlowService.saveServiceOptFlow(serviceOptFlow));
    }


    /**
     * 更新服务接口申请
     *
     * @param serviceOptFlow 服务接口申请
     * @return success/false
     */
    @SysLog(value = "更新服务接口", type = CommonConstants.LOG_EDIT)
    @PutMapping
    public R update(@Valid @RequestBody ServiceOptFlow serviceOptFlow ) {
        return new R<>(serviceOptFlowService.updateServiceOptFlow(serviceOptFlow));
    }

    /**
     * 提交服务接口申请
     *
     * @param serviceOptFlow 服务接口申请
     * @return success/false
     */
    @SysLog(value = "提交服务接口", type = CommonConstants.LOG_EDIT)
    @PostMapping("/submit")
    public R submit(@Valid @RequestBody ServiceOptFlow serviceOptFlow ) {
        return new R<>(serviceOptFlowService.submitServiceOptFlow(serviceOptFlow));
    }


    /**
     * 删除服务接口申请
     *
     * @param id ID 服务接口id
     * @return success/false
     */
    @SysLog(value = "删除服务接口", type = CommonConstants.LOG_DELELE)
    @DeleteMapping("/{id}")
    public R removeById(@PathVariable String id) {
        return new R<>(serviceOptFlowService.removeById(id));
    }

    /**
     * 服务接口申请审批
     *
     * @param serviceOptFlow
     * @return success/false
     */
    @SysLog(value = "审批申请", type = CommonConstants.LOG_EDIT)
    @PostMapping("/adiut")
    public R adiut(@Valid @RequestBody ServiceOptFlow serviceOptFlow ) {
        return new R<>(serviceOptFlowService.auditServiceOptFlow(serviceOptFlow));
    }



}
