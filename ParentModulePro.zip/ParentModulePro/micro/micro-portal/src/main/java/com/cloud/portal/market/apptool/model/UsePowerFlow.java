package com.cloud.portal.market.apptool.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.apache.commons.lang.StringUtils;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/17 15:09
 * @description: 应用工具申请访问流程实体
 * @modified By: huangyingx
 */
@Data
@TableName("t_portal_use_power_flow")
public class UsePowerFlow extends Model<UsePowerFlow>{

    private static final long serialVersionUID = 1L;

    public static final String STATUS_DRAFT = "0";  //草稿状态
    public static final String STATUS_EXAMINATION = "1";  //审批状态
    public static final String STATUS_FAIL = "2";  //驳回状态
    public static final String STATUS_SUCCESS = "3";  //通过状态

    /** 主键id */
    @LogField(title = "主键id")
    @TableId(type= IdType.INPUT)
    private String id;
    /** 应用工具ID集合（逗号隔开）*/
    @LogField(title = "应用工具ID集合（逗号隔开）")
    private String appToolIds;
    /** 应用工具名称集合（逗号隔开） */
    private String appToolNames;
    /** 申请人 */
    @LogField(title = "申请人")
    private String applicant;
    /** 申请时间 */
    @LogField(title = "申请时间")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date applyTime;
    /** 审批人 */
    @LogField(title = "审批人")
    private String approver;
    /** 审批时间 */
    @LogField(title = "审批时间")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date approvalTime;
    /** 状态（0-草稿,1-驳回,2-审批中,3-通过,） */
    @LogField(title = "状态（0-草稿,1-驳回,2-审批中,3-通过,）")
    private String status;
    /** 审批意见 */
    @LogField(title = "审批意见")
    private String opinion;
    /** 创建时间 */
    @LogField(title = "创建时间")
    private Date createTime;
    /** 更新时间 */
    @LogField(title = "更新时间")
    private Date updateTime;
    /** 创建人 */
    @LogField(title = "创建人")
    private String createBy;
    /** 更新人 */
    @LogField(title = "更新人")
    private String updateBy;
    /** 删除标志 */
    @LogField(title = "删除标志")
    private String delFlag;
    /** 应用工具 */
    @TableField(exist = false)
    private AppTool appTool;
    /** 业务类型(app-应用 tool-工具) */
    private String bussType;
    /** 申请数量 */
    private int count;
    @TableField(exist = false)
    private String applicantName;
    @TableField(exist = false)
    private String approverName;
    /** 申请说明 */
    private String applyExplain;

    @TableField(exist = false)
    private List<OptManual> optManualList;
    /**查询时间范围*/
    @TableField(exist = false)
    private String starTime;
    @TableField(exist = false)
    private String endTime;
    @TableField(exist = false)
    private List<String> appToolIdsList;

    public List<String> getAppToolIdsList() {
        String ids = this.appToolIds;
        if(StringUtils.isNotBlank(ids)){
            return Arrays.asList(ids.split(","));
        }
        return appToolIdsList;
    }

    /**
     * 用于查询过滤，是否有审批权限
     */
    @TableField(exist = false)
    private boolean isApprove;
    /**
     * 用于查询过滤，是否管理员
     */
    @TableField(exist = false)
    private boolean isAdmin;
}
