package com.cloud.portal.inforelease.message.model;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author rush
 * @Date Created in 2020/3/12 14:40
 * Description: 留言板实体
 * Modified By:
 */
@Data
@TableName("T_PORTAL_MESSAGE_BOARD")
@EqualsAndHashCode(callSuper = true)
public class MessageBoard extends Model<MessageBoard> {
    /**
     * id
     */
    @TableId(type = IdType.UUID)
    private String id;
    /**
     * 父ID
     */
    private String parentId;
    /**
     * 标题
     */
    private String title;
    /**
     * 版块类型
     */
    private String type;
    /**
     * 姓名
     */
    private String personName;
    /**
     * 留言内容
     */
    private String content;
    /**
     * 联系电话
     */
    private String phone;
    /**
     * 回复内容
     */
    @TableField(exist = false)
    private int replyNum;
    /**
     * 留言详细内容
     */
    @TableField(exist = false)
    private List<MessageReplay> replies = new ArrayList<MessageReplay>();
    /**
     * 查询时间
     */
    @TableField(exist = false)
    private String searchTime;

    /**
     * 是否!0官方
     */
    private int isOfficial;
    /**
     * 是否!0置顶
     */
    private int isTop;
    /**
     * 是否!0精品
     */
    private int isCream;
    /**
     * 公共标签
     */
    @TableField(exist = false)
    private String publicTags;
    /**
     * 只看楼主
     */
    private boolean onLandlord;
    /**
     * 是否自己
     */
    @TableField(exist = false)
    private boolean isSelf;
    /**
     * 用户图片
     */
    @TableField(exist = false)
    private String userPhoto;
    /**
     * 用户昵称
     */
    @TableField(exist = false)
    private String userNickName;
    /**
     * 是否管理员提交
     */
    private boolean postByAdmin;
    /**
     * 是否投票
     */
    @TableField(exist = false)
    private String isVoted;
    /**
     * 点赞数量
     */
    private int lickCount;
    /**
     * 查看数量
     */
    private int viewCount;
    /**
     * 回复数量
     */
    private int commentCount;
    /**
     * 排序字段
     */
    @TableField(exist = false)
    private String order;
    /**
     * 是否超管
     */
    @TableField(exist = false)
    private Boolean isAdmin;
    /**
     * 用户等级
     */
    @TableField(exist = false)
    private String authLevel;
    /**
     * 是否FAQ
     */
    @TableField(exist = false)
    private boolean isFaq;
    /**
     * 是否设置FAQ
     */
    @TableField(exist = false)
    private boolean isFaqSetup;
    /**
     * 是否删除
     */
    @TableField(exist = false)
    private boolean deletePrivate;
    /**
     * 楼层
     */
    private int position;
    /**
     * 备注
     */
    private String remark;
    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建人
     */
    private String createBy;
    /**
     * 更新人
     */
    private String updateBy;
    /**
     * 删除状态
     */
    @TableLogic
    private String delFlag;

    /**点赞人id*/
    @TableField(exist = false)
    private String userId;
}
