package com.cloud.portal.inforelease.message.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.inforelease.message.model.MessageReplay;
import org.apache.ibatis.annotations.Param;

/**
 * @author rush
 * @Date Created in 2020/3/12 15:23
 * Description:
 * Modified By:
 */
public interface MessageReplayMapper extends BaseMapper<MessageReplay> {
    /**
     * 获取留言回复列表信息
     *
     * @param page
     * @param messageReplay
     * @return
     */
    IPage<MessageReplay> getListPage(IPage<MessageReplay> page, @Param("query") MessageReplay messageReplay);

    /**
     * 根据留言板id 删除留言回复信息
     *
     * @param boardId 留言板id
     * @return
     */
   boolean deleteMessageReplay(@Param("boardId")String boardId);

}
