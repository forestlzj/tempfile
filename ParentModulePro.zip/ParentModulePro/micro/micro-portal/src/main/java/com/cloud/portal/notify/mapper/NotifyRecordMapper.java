package com.cloud.portal.notify.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.portal.notify.model.NotifyRecord;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author yuhaob
 * @date Created in 2020/3/18 9:52
 * @description:
 * @modified By:yuhaob
 */
@Mapper
public interface NotifyRecordMapper extends BaseMapper<NotifyRecord> {

    IPage findPage(Page page, NotifyRecord notifyRecord);

    void insertAllByUnit(NotifyRecord notifyReocrdList);

    List<NotifyRecord> findView(NotifyRecord notifyRecord);

    int updateByNotifyId(NotifyRecord notifyRecord);
}
