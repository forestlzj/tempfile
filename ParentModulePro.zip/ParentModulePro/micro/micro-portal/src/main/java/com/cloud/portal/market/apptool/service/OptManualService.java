package com.cloud.portal.market.apptool.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.apptool.model.OptManual;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;

/**
 * @author wengshij
 * @date Created in 2020/3/13 10:11
 * @description:应用工具操作手册接口层
 * @modified By:wengshij
 */
public interface OptManualService extends IService<OptManual> {

    /**
     * 上传操作手册文件
     *
     * @param file
     * @return
     * @throws Exception
     */
    R uploadManual(MultipartFile file) throws Exception;

    /**
     * 清空操作手册信息（包含删除minio中的文件信息）
     *
     * @param optManual
     * @return
     */
    R deleteManual(OptManual optManual);

    /**
     * 下载文件
     *
     * @param optManual
     * @return
     */
    InputStream downLoadManual(OptManual optManual);

    /**
     * 获取操作手册列表信息
     * @param optManual
     * @return
     */
    List<OptManual> findList(OptManual optManual);
}
