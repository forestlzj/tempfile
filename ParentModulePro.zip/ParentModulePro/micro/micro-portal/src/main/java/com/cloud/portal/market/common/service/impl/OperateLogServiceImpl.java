package com.cloud.portal.market.common.service.impl;

import cn.hutool.extra.servlet.ServletUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.security.component.PermissionService;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.common.mapper.OperateLogMapper;
import com.cloud.portal.market.common.model.OperateLog;
import com.cloud.portal.market.common.model.UseMonitor;
import com.cloud.portal.market.common.service.OperateLogService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.util.Date;
import java.util.Objects;

/**
 * @author wengshij
 * @date Created in 2020/4/21 11:21
 * @description:操作日志详细记录方法
 * @modified By:ryt
 * @modifieDescription: 数据、服务操作监控统计
 */
@Service
public class OperateLogServiceImpl extends ServiceImpl<OperateLogMapper, OperateLog> implements OperateLogService {
    /**
     * 权限控制接口
     */
    @Autowired
    private PermissionService pms;

    @Override
    public boolean saveLog(OperateLog operateLog) {
        if (null == operateLog) {
            return false;
        }
        HttpServletRequest request = ((ServletRequestAttributes) Objects
                .requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();
        operateLog.setOperateTime(new Date(System.currentTimeMillis()));
        operateLog.setBrowser(request.getHeader("user-agent"));
        operateLog.setRemoteAdd(ServletUtil.getClientIP(request));
        if (StringUtils.isBlank(operateLog.getUserId())) {
            MicroUser microUser = SecurityUtils.getUser();
            if (null != microUser && null != microUser.getSysUser()) {
                operateLog.setUserId(microUser.getSysUser().getIdcard());
                operateLog.setUserName(microUser.getSysUser().getName());
            }
            if (null != microUser && null != microUser.getSysDept()) {
                operateLog.setOrgCode(microUser.getSysDept().getCode());
                operateLog.setOrgName(microUser.getSysDept().getName());
            }
        }
        operateLog.setOperateResult(StringUtils.isBlank(operateLog.getOperateResult()) ? MarketConstants.LOG_SUCCESS : operateLog.getOperateResult());
        operateLog.setRegId(StringUtils.isBlank(operateLog.getRegId()) ? MarketConstants.LOG_REG_ID : operateLog.getRegId());
        operateLog.setRequestMethod(StringUtils.isBlank(operateLog.getRequestMethod()) ? MarketConstants.LOG_REQUEST_METHOD_GET : operateLog.getRequestMethod());
        return SqlHelper.delBool(baseMapper.insert(operateLog));
    }

    @Override
    public IPage<OperateLog> getListPage(IPage<OperateLog> page, OperateLog operateLog) {
        MicroUser microUser = SecurityUtils.getUser();
        boolean hasPower = pms.hasPermission(MarketConstants.LOG_OPERATE_LIST_POWER);
        if (!microUser.isAdmin() && !hasPower) {
            //如果当前用户是空的、返回空值
            if (null == microUser.getSysUser() || StringUtils.isBlank(microUser.getSysUser().getIdcard())) {
                return new Page<>();
            } else {
                operateLog.setUserId(microUser.getSysUser().getIdcard());
            }

        }

        return baseMapper.getListPage(page, operateLog);

    }


    /**
     * 数据、服务操作监控统计
     *
     * @param page
     * @param useMonitor
     * @return
     */
    @Override
    public IPage<UseMonitor> getUseMonitorList(IPage<UseMonitor> page, UseMonitor useMonitor) {
        return baseMapper.getUseMonitorList(page,useMonitor);
    }

    /**
     * 数据、服务操作监控统计--获取操作失败、异常日志信息
     *
     * @param page
     * @param operateLog
     * @return
     */
    @Override
    public IPage<OperateLog> getFailLogList(IPage<OperateLog> page, OperateLog operateLog) {
        return baseMapper.getFailLogList(page,operateLog);
    }

}
