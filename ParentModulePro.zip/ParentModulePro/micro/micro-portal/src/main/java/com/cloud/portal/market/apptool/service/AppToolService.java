package com.cloud.portal.market.apptool.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolTree;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;
import java.util.Map;

/**
 * @author wengshij
 * @date Created in 2020/3/11 10:06
 * @description:应用工具接口层
 * @modified By:wengshij
 */
public interface AppToolService extends IService<AppTool> {
    /**
     * 添加应用工具信息
     *
     * @param appTool
     * @return
     */
    boolean saveAppTool(AppTool appTool);

    /**
     * 更新应用工具信息
     *
     * @param appTool
     * @return
     */
    boolean updateAppTool(AppTool appTool);

    /**
     * 根据主键 删除应用工具信息
     *
     * @param id
     * @return
     */
    R deleteAppTool(String id);

    /**
     * 上传图标信息
     *
     * @param file
     * @return
     * @throws Exception
     */
    R uploadIcon(MultipartFile file) throws Exception;

    /**
     * 删除图标
     *
     * @param base64Id
     * @return
     */
    R deleteIcon(String base64Id);

    /**
     * 下载图标
     *
     * @param base64Id
     * @return
     */
    InputStream downLoadIcon(String base64Id);

    /**
     * 获取应用工具列表信息（管理员权限）
     *
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> getListPage(IPage<AppTool> page, AppTool appTool);

    /**
     * 应用工具门户信息列表（权限控制）
     *
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> findAppToolPage(IPage<AppTool> page, AppTool appTool);


    /**
     * 获取应用工具信息 根据主键ID
     * 并且关联出编目、和标签信息
     *
     * @param appId
     * @return
     */
    AppTool getAll(String appId);

    /**
     * 获取应用工具列表信息（不分页）
     *
     * @param appTool
     * @return
     */
    List<AppTool> getListPage(AppTool appTool);

    /**
     * 获取没有使用权限的信息列表
     *
     * @param appTool
     * @return
     */
    List<AppTool> getNoAuthorizeList(AppTool appTool);

    /**
     * 申请保存应用工具信息
     *
     * @param appTool
     * @return
     */
    R approvalSave(AppTool appTool);

    /**
     * 获取应用工具树形列表信息
     *
     * @param appTool
     * @return
     */
    List<AppToolTree> getAppToolTree(AppTool appTool);

    /**
     * 获取所有 工具信息、门户使用到
     *
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> findAllToolPage(IPage<AppTool> page, AppTool appTool);

    /**
     * 获取工具排名前十列表
     *
     * @param appTool
     * @return
     */
    List<AppTool> findTopToolList(AppTool appTool);

    /**
     * 预览次数累加
     *
     * @param appToolId
     * @return
     */
    boolean countUpViewNum(String appToolId,String type);

    /**
     * 获取所有 应用信息、门户使用到
     *
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> findAllAppPage(IPage<AppTool> page, AppTool appTool);

    /**
     * 统计可申请应用
     *
     * @param appTool
     * @return
     */
    int totalIsApplyApp(AppTool appTool);

    /**
     * 获取应用工具分类后的信息（门户首页使用、获取前十条）
     *
     * @param page
     * @param appTool
     * @return
     */
    IPage<AppTool> findAppToolKind(IPage<AppTool> page, AppTool appTool);

    /**
     * 应用工具统计
     * @return
     */
    Map getAppToolCount();

    /**
     * 个人工作台 获取当前用户所有应用、工具
     * @param appTool
     * @return
     */
    List<AppTool> getUserAppToolList(AppTool appTool);

    /**
     * 获取有权限并存在操作手册的应用工具列表
     * @param name
     * @param bussType
     * @return
     */
    List<AppTool> findHasOptManualAuthorizeList(String name,String bussType);

}
