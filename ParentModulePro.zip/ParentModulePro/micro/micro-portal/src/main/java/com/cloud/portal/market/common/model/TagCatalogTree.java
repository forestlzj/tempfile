package com.cloud.portal.market.common.model;

import com.cloud.admin.api.dto.TreeNode;
import lombok.Data;

/**
 * @author wengshij
 * @date Created in 2020/4/1 13:54
 * @description:
 * @modified By:wengshij
 */
@Data
public class TagCatalogTree extends TreeNode {
    /**
     * 标识是标签还是目录
     */
    private String key;
    /**
     * 标识是标签还是目录
     */
    private String type;
    /**
     * 是否隐藏
     */
    private boolean isHide;
    /**
     * 名称
     */
    private String name;
    /**
     * 是否选中
     */
    private boolean checked;
    /**
     * 是否多选
     */
    private boolean multiple;
}
