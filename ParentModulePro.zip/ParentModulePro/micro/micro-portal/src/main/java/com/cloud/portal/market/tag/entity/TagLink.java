package com.cloud.portal.market.tag.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import lombok.Data;

/**
 * @author maojia
 * @date Created in 2020/3/18 14:57
 * @description:
 * @modified By:maojia
 */
@Data
@TableName("T_PORTAL_APP_TOOL_LABEL_LINK")
public class TagLink extends Model<TagLink> {

    @LogField(title = "应用工具ID")
    private String  appToolId;
    @LogField(title = "标签ID")
    private String labelId;
    @LogField(title = "标签名称")
    private String label;
}
