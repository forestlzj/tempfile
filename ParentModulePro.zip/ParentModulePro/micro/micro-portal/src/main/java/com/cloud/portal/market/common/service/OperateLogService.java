package com.cloud.portal.market.common.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.common.model.OperateLog;
import com.cloud.portal.market.common.model.UseMonitor;

/**
 * @author wengshij
 * @date Created in 2020/4/21 11:21
 * @description:
 * @modified By:ryt
 * @modifieDescription: 数据、服务操作监控统计
 */
public interface OperateLogService extends IService<OperateLog> {

    /**
     * 添加访问日志
     *
     * @param operateLog
     * @return
     */
    boolean saveLog(OperateLog operateLog);

    /**
     * 获取操作日志分页信息
     *
     * @param page
     * @param operateLog
     * @return
     */
    IPage<OperateLog> getListPage(IPage<OperateLog> page, OperateLog operateLog);

    /**
     * 数据、服务操作监控统计
     *
     * @param page
     * @param useMonitor
     * @return
     */
    IPage<UseMonitor> getUseMonitorList(IPage<UseMonitor> page, UseMonitor useMonitor);


    /**
     * 数据、服务操作监控统计--获取操作失败、异常日志信息
     *
     * @param page
     * @param operateLog
     * @return
     */
    IPage<OperateLog> getFailLogList(IPage<OperateLog> page, OperateLog operateLog);

}
