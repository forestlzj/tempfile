package com.cloud.portal.inforelease.message.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.inforelease.message.mapper.MessageReplayMapper;
import com.cloud.portal.inforelease.message.model.MessageReplay;
import com.cloud.portal.inforelease.message.service.MessageReplayService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

/**
 * @author rush
 * @Date Created in 2020/3/12 15:22
 * Description:
 * Modified By:
 */
@Service
@AllArgsConstructor
public class MessageReplayServiceImpl extends ServiceImpl<MessageReplayMapper, MessageReplay> implements MessageReplayService {

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveMessageReplay(MessageReplay messageReplay) {
        messageReplay = initParams(messageReplay);
        return SqlHelper.delBool(this.baseMapper.insert(messageReplay));
    }

    /**
     * 根据留言板id 删除留言回复信息
     *
     * @param boardId 留言板id
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteMessageReplay(String boardId){
        return baseMapper.deleteMessageReplay(boardId);
    }

    @Override
    public IPage<MessageReplay> getListPage(IPage<MessageReplay> page, MessageReplay messageReplay) {
        IPage<MessageReplay> iPage = this.baseMapper.getListPage(page, messageReplay);
        return iPage;
    }

    private MessageReplay initParams(MessageReplay messageReplay) {
        MicroUser microUser = SecurityUtils.getUser();
        messageReplay.setDelFlag(CommonConstants.STATUS_NORMAL);
        messageReplay.setCreateBy(microUser.getId());
        messageReplay.setUpdateBy(microUser.getId());
        messageReplay.setCommentUserId(microUser.getSysUser().getUserId());
        if (StringUtils.isEmpty(messageReplay.getToUserId())) {
            messageReplay.setToUserId(microUser.getSysUser().getUserId());
        }
        ;
        messageReplay.setUserNickName(microUser.getSysUser().getName());
        messageReplay.setCreateTime(new Date(System.currentTimeMillis()));
        messageReplay.setUpdateTime(messageReplay.getCreateTime());
        return messageReplay;
    }
}
