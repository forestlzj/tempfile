package com.cloud.portal.market.tag.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.tag.entity.Tag;
import com.cloud.portal.market.tag.mapper.TagMapper;
import com.cloud.portal.market.tag.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.cache.RedisCache;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/11 17:39
 * @description:
 * @modified By:maojia
 */
@Service
public class TagServiceImpl extends ServiceImpl<TagMapper, Tag> implements TagService {

    private RedisTemplate redisTemplate;
    /**
     * 查询列表(分页)
     * @param page
     * @param tag
     * @return
     */
    @Override
    public IPage<List<Tag>> findListPage(IPage<Tag> page, Tag tag) {
        return this.baseMapper.findListPage(page,tag);
    }

    @Override
    @Cacheable(value = MarketConstants.TAG_CACHE_NAME, key = "#type")
    public List<Tag> findListByType(String type) {
        List<Tag> tagList = baseMapper.findListByType(type);
        return tagList;
    }

    @Override
    public boolean hasExistTag(Tag tag) {
        return this.baseMapper.existTag(tag)>0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.TAG_CACHE_NAME, allEntries = true)
    public int updateTag(Tag tag) {
        tag.setUpdateTime(LocalDateTime.now());
        return this.baseMapper.updateTag(tag);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.TAG_CACHE_NAME, allEntries = true)
    public int saveTag(Tag tag) {
        tag.setCreateTime(LocalDateTime.now());
        tag.setUpdateTime(LocalDateTime.now());
        //redisTemplate.setHashKeySerializer();
        return this.baseMapper.saveTag(tag);
    }
}
