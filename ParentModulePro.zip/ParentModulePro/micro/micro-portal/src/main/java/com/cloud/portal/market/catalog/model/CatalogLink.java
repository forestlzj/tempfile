package com.cloud.portal.market.catalog.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;

import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/10 15:09
 * @description: 目录编排管理关联实体
 * @modified By: huangyingx
 */
@Data
@TableName("t_portal_catalog_link")
public class CatalogLink extends Model<CatalogLink>{

    private static final long serialVersionUID = 1L;

    /** 目录id*/
    @TableField(value = "catalog_id")
    private String catalogId;
    /** 数据/服务/应用/工具id */
    @TableField(value = "other_id")
    private String otherId;
    /** 目录名称 */
    @TableField(exist = false)
    private String name;
}
