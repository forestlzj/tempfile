package com.cloud.portal.market.common.service;

import com.cloud.common.core.util.R;

/**
 * @author wengshij
 * @date Created in 2020/4/1 13:39
 * @description:
 * @modified By:wengshij
 */
public interface MarketCommonService {
    /**
     * 获取标签信息和编目信息
     * @param tagType 标签类型
     * @param catalogType 编目类型
     * @param choose 选择（标签-tag或者编目-catalog或者全部 both）
     * @return
     */
   R getTagCatalog(String tagType, String catalogType, String choose);
}
