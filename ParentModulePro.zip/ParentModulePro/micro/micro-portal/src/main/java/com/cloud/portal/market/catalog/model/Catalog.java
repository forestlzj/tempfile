package com.cloud.portal.market.catalog.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.cloud.admin.api.annotation.LogField;
import com.cloud.admin.api.dto.TreeNode;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author huangyingx
 * @date Created in 2020/3/10 15:09
 * @description: 目录编排实体
 * @modified By: huangyingx
 */
@Data
@TableName("t_portal_catalog")
public class Catalog extends TreeNode implements Serializable {

    private static final long serialVersionUID = 1L;
    /**主键ID*/
    @TableId(value = "id", type = IdType.UUID)
    @LogField(title = "主键")
    private String id;
    /** 名称 */
    @LogField(title = "名称")
    private String name;
    /** 层级父Id 使用,分割*/
    @LogField(title = "层级父Id 使用,分割")
    private String parentIds;
    /** 创建时间 */
    @LogField(title = "创建时间")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private LocalDateTime createTime;
    /** 修改时间 */
    @LogField(title = "修改时间")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private LocalDateTime updateTime;
    /** 创建人 */
    @LogField(title = "创建人")
    private String createBy;
    /** 修改人 */
    @LogField(title = "修改人")
    private String updateBy;
    /** 删除标志 */
    @LogField(title = "删除标志")
    private String delFlag;
    /** 编目类型 */
    @LogField(title = "编目类型")
    private String type;

    public static final String ROOTID = "0";
}
