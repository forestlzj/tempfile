package com.cloud.portal.market.company.controller;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.IoUtil;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.company.model.Company;
import com.cloud.portal.market.company.service.CompanyService;
import com.google.common.base.Splitter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/11 17:09
 * @description:开发公司控制层
 * @modified By:liuwei
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/comp/company/")
public class CompanyController {
    /**
     * 开发公司接口层
     */
    private final CompanyService companyService;

    /**
     * 分页查询 开发公司信息
     *
     * @param page    分页对象
     * @param company 开发公司实体类
     * @return
     */
    @GetMapping("page")
    @SysLog(value = "开发公司分页查询")
    public R getPersonConcernPage(Page page, Company company) {
        return R.ok(companyService.page(page, company));
    }

    /**
     * 查询列表
     * @return
     */
    @GetMapping("list")
    @SysLog(value = "开发公司列表查询")
    public List<Company> findList(){
        return companyService.findList("all");
    }

    @DeleteMapping("deleteIcon/{base64Id}")
    public R deleteIcon(@PathVariable String base64Id) {
        return companyService.deleteIcon(base64Id);
    }

    @RequestMapping(value = "uploadIcon")
    @ResponseBody
    public R upload(MultipartFile file) throws Exception {
        return companyService.uploadIcon(file);
    }

    @RequestMapping(value = "getIcon/{base64Id}")
    @ResponseBody
    public void getIcon(@PathVariable("base64Id") String base64Id, HttpServletResponse response) {
        try {
            String fileName = Base64.decodeStr(base64Id);
            fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            IoUtil.copy(companyService.downLoadIcon(base64Id), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /**
     * 新增 开发公司
     *
     * @param company
     * @return R
     */
    @SysLog(value = "开发公司新增", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    public R save(@RequestBody Company company) {
        return R.ok(companyService.saveCompany(company));
    }

    /**
     * 通过id查询 开发公司
     *
     * @param id id
     * @return R
     */
    @GetMapping("get/{id}")
    public R getById(@PathVariable("id") String id) {
        return R.ok(companyService.getById(id));
    }

    /**
     * 修改 开发公司
     *
     * @param company
     * @return R
     */
    @SysLog(value = "开发公司修改", type = CommonConstants.LOG_EDIT)
    @PostMapping("update")
    public R updateById(@RequestBody Company company) {

        return R.ok(companyService.updateCompany(company));
    }


    /**
     * 通过id删除 开发公司
     *
     * @param ids 主键ID
     * @return R
     */
    @SysLog(value = "开发公司删除", type = CommonConstants.LOG_DELELE)
    @DeleteMapping("delete/{ids}")
    public R removeById(@PathVariable String ids) {
        List<String> idList = Splitter.on(",").trimResults().splitToList(ids);
        if(idList.size()>1) {
            List<String> lists = new ArrayList<>();
            for (int i = 0; i < idList.size() - 1; i++) {
                lists.add(idList.get(i));
            }
            idList=lists;
        }
        return R.ok(companyService.updateDel(idList));
    }

    /**
     * 根据用户名查询用户信息
     *
     * @param companyName 用户名
     * @return
     */
    @GetMapping("findByName/{companyName}")
    @SysLog(value = "查询是否重名",type = CommonConstants.LOG_LOGIN)
    public R user(@PathVariable String companyName) {
        Company company = new Company();
        company.setName(companyName);
        return new R<>(companyService.getOne(new QueryWrapper<>(company)));
    }

    /**
     * 根据id获取公司信息（包括开发人员）
     * @param id
     * @return
     */
    @GetMapping("getAll/{id}")
    public R getAllById(@PathVariable String id){
        return R.ok(companyService.getAllById(id));
    }
}
