package com.cloud.portal.market.apptoolpower.service;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.apptoolpower.model.AppToolPower;
import com.cloud.portal.market.apptoolpower.model.AppToolPowerVo;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/31 10:03
 * @description:应用工具权限分配
 * @modified By:liuwei
 */
public interface AppToolPowerService  extends IService<AppToolPower> {

    /**
     * 添加用户工具信息
     *
     * @param appToolPower
     * @return
     */
    boolean saveAppToolPower(AppToolPower appToolPower);

    /**
     * 获取应用工具列表信息（不分页）
     *
     * @param appToolPower
     * @return
     */
    List<AppToolPower> getList(AppToolPower appToolPower);

    /**
     * 更新用户工具信息
     *
     * @param appToolPower
     * @return
     */
     boolean updateAppToolPower(AppToolPower appToolPower);

    /**
     * 查询用户应用工具数分页）
     * @param page
     * @param appToolPowerVo
     * @return
     */
    IPage<List<AppToolPowerVo>> toolAppNum(IPage<AppToolPowerVo> page, AppToolPowerVo appToolPowerVo);

    /**
     * 校验应用工具集合当前用户是否有授权
     * @param ids
     * @param status
     * @return
     */
    List<String> exists(String ids,String status);

    /**
     * 通过申请流程批量保存权限记录
     * @param appToolPowerList
     * @return
     */
    boolean saveByFlow(List<AppToolPower> appToolPowerList);

    /**
     * 更新用户应用工具信息（显隐、排序）
     *
     * @param appToolPower
     * @return
     */
    R updateUserAppToolById(AppToolPower appToolPower);
}
