package com.cloud.portal.market.catalog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.catalog.model.CatalogLink;

import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/10 16:54
 * @description: 目录编排管理关联service接口
 * @modified By: huangyingx
 */
public interface CatalogLinkService extends IService<CatalogLink> {

    /**
     * 批量插入记录
     * @param catalogList
     * @param otherId
     * @return
     */
    boolean insertBatchByOtherId(List<String> catalogList,String otherId);

    /**
     * 根据otherId删除关联记录
     * @param otherId
     * @return
     */
    boolean deleteByOtherId(String otherId);

    /**
     * 根据otherId获取列表信息(不含名称)
     * @param otherId
     * @return
     */
    List<CatalogLink> findByOtherId(String otherId);

    /**
     * 根据otherId获取列表信息(含名称)
     * @param otherId
     * @return
     */
    List<CatalogLink> findObjByOtherId(String otherId);

    /**
     * 根据父级id获取关联列表
     * @param parentId
     * @return
     */
    List<CatalogLink> findByParentId(String parentId);

}
