package com.cloud.portal.data.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.data.model.DataResourceCount;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

/**
 * @author yuhaob
 * @date Created in 2020/4/16 11:17
 * @description:
 * @modified By:yuhaob
 */
@Mapper
public interface DataResourceCountMapper extends BaseMapper<DataResourceCount> {
    List<Map<String, Object>> getNewMap();

    List<Map<String, Object>> getNewSys();

    List<Map<String, Object>> getNewCity();
}
