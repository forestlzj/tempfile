package com.cloud.portal.market.work.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchComponent;
import com.cloud.portal.market.work.service.BenchComponentService;
import com.google.common.base.Splitter;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/8 14:53
 * @description:个人工作台组件信息
 * @modified By:liuwei
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/work/component/")
public class BenchComponentController {
    /**
     * 组件信息接口层
     */
    private final BenchComponentService benchComponentService;

    /**
     * 分页查询 组件信息
     *
     * @param page    分页对象
     * @param benchComponent 组件信息实体类
     * @return
     */
    @GetMapping("page")
    @SysLog(value = "组件信息分页查询")
    public R getComponentPage(Page page, BenchComponent benchComponent) {
        return R.ok(benchComponentService.findQueryPage(page, benchComponent));
    }

    /**
     * 通过id删除 组件信息
     *
     * @param ids 主键ID
     * @return R
     */
    @SysLog(value = "组件信息删除", type = CommonConstants.LOG_DELELE)
    @DeleteMapping("delete/{ids}")
    public R removeById(@PathVariable String ids) {
        List<String> idList = Splitter.on(",").trimResults().splitToList(ids);
        if(idList.size()>1) {
            List<String> lists = new ArrayList<>();
            for (int i = 0; i < idList.size() - 1; i++) {
                lists.add(idList.get(i));
            }
            idList=lists;
        }
        return R.ok(benchComponentService.updateDel(idList));
    }

    /**
     * 新增 组件信息
     *
     * @param benchComponent
     * @return R
     */
    @SysLog(value = "组件信息新增", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    public R save(@RequestBody BenchComponent benchComponent) {
        BenchComponent benchComponent1=new BenchComponent();
        benchComponent1.setKeyValue(benchComponent.getKeyValue());
        if(benchComponentService.findByValue(benchComponent1)!=null){
            return R.failed("该组件key已存在,请重新输入");
        }else {
            return R.ok(benchComponentService.saveComponent(benchComponent));
        }
    }

    /**
     * 修改 组件信息
     *
     * @param benchComponent
     * @return R
     */
    @SysLog(value = "组件信息修改", type = CommonConstants.LOG_EDIT)
    @PutMapping("update")
    public R updateById(@RequestBody BenchComponent benchComponent) {
        BenchComponent benchComponent1 = new BenchComponent();
        benchComponent1.setKeyValue(benchComponent.getKeyValue());
        BenchComponent benchComponent2=benchComponentService.findByValue(benchComponent1);
        if (benchComponent2!= null) {
            if(!benchComponent2.getId().equals(benchComponent.getId())) {
                return R.failed("该组件key已存在,请重新输入");
            }
        }
            return R.ok(benchComponentService.updateComponent(benchComponent));
    }

    /**
     * 查询工作台可以添加的组件信息
     *
     * @param bench 工作台信息
     * @return
     */
    @GetMapping("findByBenchId")
    @SysLog(value = "查询工作台可以添加的组件信息")
    public R findByBenchId(Bench bench) {
        return R.ok(benchComponentService.findByBenchId(bench));
    }


   /* @GetMapping("findByKey/{keyValue}")
    @SysLog(value = "查询组件key是否重名",type = CommonConstants.LOG_LOGIN)
    public R findByKey(@PathVariable String keyValue) {
        BenchComponent benchComponent = new BenchComponent();
        benchComponent.setKeyValue(keyValue);
        return new R<>(benchComponentService.getOne(new QueryWrapper<>(benchComponent)));
    }*/



}
