package com.cloud.portal.market.catalog.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.admin.api.dto.TreeNode;
import com.cloud.admin.api.entity.SysUser;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.catalog.mapper.CatalogMapper;
import com.cloud.portal.market.catalog.model.Catalog;
import com.cloud.portal.market.catalog.service.CatalogService;
import com.cloud.portal.market.common.constant.MarketConstants;
import lombok.AllArgsConstructor;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author huangyingx
 * @date Created in 2019/8/5 11:21
 * @description: 目录编排service实现类
 * @modified By: huangyingx
 */
@Service
@AllArgsConstructor
public class CatalogServiceImpl extends ServiceImpl<CatalogMapper, Catalog> implements CatalogService {

    @Override
    @Cacheable(value = MarketConstants.CATALOG_CACHE_NAME,key = "#type")
    public List<Catalog> findListByType(String type) {
        return this.baseMapper.findListByType(type);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.CATALOG_CACHE_NAME, allEntries = true)
    public int saveCatalog(Catalog entity) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        entity.setCreateBy(sysUser.getUserId());
        entity.setCreateTime(LocalDateTime.now());
        entity.setUpdateBy(sysUser.getUserId());
        entity.setUpdateTime(LocalDateTime.now());
        entity.setDelFlag(CommonConstants.STATUS_NORMAL);
        if(Catalog.ROOTID.equals(entity.getParentId())){
            entity.setParentIds(Catalog.ROOTID);
        }else{
            entity.setParentIds(Catalog.ROOTID+","+entity.getParentId());
        }
        return this.baseMapper.insertCatalog(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.CATALOG_CACHE_NAME, allEntries = true)
    public int updateCatalog(Catalog entity) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        entity.setUpdateBy(sysUser.getUserId());
        entity.setUpdateTime(LocalDateTime.now());
        return this.baseMapper.updateCatalog(entity);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.CATALOG_CACHE_NAME, allEntries = true)
    public int deleteById(String id) {
        //检查是否父节点
        Catalog ca = findById(id);
        if(Catalog.ROOTID.equals(ca.getParentId())){
            Map<String,Object> params = new HashMap<>();
            params.put("parent_id",id);
            super.removeByMap(params);
        }
        //删除父节点
        return this.baseMapper.deleteCatalogById(id);
    }

    @Override
    public Catalog findById(String id) {
        return this.baseMapper.findById(id);
    }

    @Override
    public boolean hasExistCatalog(Catalog catalog) {
        List<Catalog> list = this.baseMapper.existCatalog(catalog);
        return list!=null && list.size()>0;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.CATALOG_CACHE_NAME, allEntries = true)
    public int saveSort(List<Catalog> list) {
        int size = 0;
        if (list!=null && list.size()>0){
            for (Catalog parent : list){
                List<TreeNode> children = parent.getChildren();
                if(children!=null && children.size()>0){
                    size += children.size();
                    this.baseMapper.updateSortByList(children);
                }
            }
        }
        return size;
    }
}
