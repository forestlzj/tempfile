package com.cloud.portal.market.common.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.common.model.OperateLog;
import com.cloud.portal.market.common.model.UseMonitor;
import com.cloud.portal.market.common.service.OperateLogService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

/**
 * @author wengshij
 * @date Created in 2020/4/21 14:17
 * @description:操作日志控制层
 * @modified By:ryt
 * @modifieDescription: 数据、服务操作监控统计
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/operate/log/")
public class OperateLogController {


    private final OperateLogService operateLogService;


    @PostMapping("record")
    public R recordLog(@RequestBody OperateLog operateLog) {
        return R.ok(operateLogService.saveLog(operateLog));
    }

    @GetMapping("page")
    @SysLog("个人使用轨迹查询")
    public R findPage(Page page, OperateLog operateLog) {
        return R.ok(operateLogService.getListPage(page, operateLog));
    }

    @GetMapping("statistics/useMonitor")
    @SysLog("数据、服务操作监控统计")
    public R getUseMonitorList(Page page, UseMonitor useMonitor) {
        return R.ok(operateLogService.getUseMonitorList(page, useMonitor));
    }

    @GetMapping("statistics/useMonitor/detail")
    @SysLog("数据、服务操作监控统计--获取操作失败、异常日志信息")
    public R getFailLogList(Page page, OperateLog operateLog) {
        return R.ok(operateLogService.getFailLogList(page,operateLog));
    }

}
