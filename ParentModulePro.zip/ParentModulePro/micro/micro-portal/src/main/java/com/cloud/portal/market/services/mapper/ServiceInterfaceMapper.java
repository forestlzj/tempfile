package com.cloud.portal.market.services.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.portal.market.services.entity.ServiceInterface;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wuxx
 * @date 2020/3/10 16:54
 * @description: 服务接口Mapper
 * @modified By:
 **/
public interface ServiceInterfaceMapper extends BaseMapper<ServiceInterface> {

    /**
     * 服务接口列表
     * @param page
     * @param serviceInterface
     * @return
     */
    IPage<ServiceInterface> findPage(Page<ServiceInterface> page, @Param("queryCondition")ServiceInterface serviceInterface,  @Param("userId") String userId);


    /**
     * 管理员  查询服务接口列表  申请状态默认为已通过  已申请
     * @param page
     * @param serviceInterface
     * @return
     */
    IPage<ServiceInterface> findAdminPage(Page<ServiceInterface> page, @Param("queryCondition")ServiceInterface serviceInterface);

    /**
     * 查询可申请的服务
      * @param page
     * @param serviceInterface
     * @return
     */
    IPage<ServiceInterface> findApplyServicePage (Page<ServiceInterface> page, @Param("queryCondition")ServiceInterface serviceInterface, @Param("userId") String userId);

    /**
     * 查询可申请的服务 (不分页)
     * @param serviceInterface
     * @param userId
     * @return
     */
    List<ServiceInterface> findApplyServiceList(@Param("queryCondition")ServiceInterface serviceInterface, @Param("userId") String userId);
    /**
     * 更新服务接口
     * @param serviceInterface
     * @return
     */
    Boolean update(ServiceInterface serviceInterface);

    /**
     * 根据id 更新状态
     * @param serviceInterface 服务接口
     * @return
     */
    int updateStatus(ServiceInterface serviceInterface);

    List<ServiceInterface> findList(@Param("queryCondition")ServiceInterface serviceInterface);

    /**
     * 批量插入标签信息
     * @param labelId
     * @param AppToolId
     * @return
     */
    boolean addBatchByAppToolId(@Param("list") List<String> labelId, @Param("appToolId") String AppToolId );

    /**
     * 查询热门服务
     * @param serviceInterface
     * @return
     */
    List<ServiceInterface>  findHotService(@Param("queryCondition")ServiceInterface serviceInterface);

    /**
     * 查询我的服务 （分页）
     * @param page
     * @param serviceInterface
     * @return
     */
    IPage<ServiceInterface> findMyServicePage (Page<ServiceInterface> page, @Param("queryCondition")ServiceInterface serviceInterface);


}
