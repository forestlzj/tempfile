package com.cloud.portal.market.visualization.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.visualization.entity.Kshym;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/4/13 10:58
 * @description:
 * @modified By:maojia
 */
@Mapper
public interface KshymMapper extends BaseMapper<Kshym> {
    /**
     * 查询列表（分页）
     * @param page
     * @param kshym
     * @return
     */
    IPage<List<Kshym>> findListPage(IPage<Kshym> page, @Param("kshym") Kshym kshym);

    /**
     * 查询列表
     * @param kshym
     * @return
     */
    List<Kshym> findList(@Param("kshym") Kshym kshym);

    /**
     * 根据id查询
     * @param id
     * @return
     */
    List<Kshym> findListById(@Param("id") String id);

}
