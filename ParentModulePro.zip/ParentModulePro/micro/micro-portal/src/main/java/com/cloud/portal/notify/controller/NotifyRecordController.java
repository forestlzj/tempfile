package com.cloud.portal.notify.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.notify.model.Notify;
import com.cloud.portal.notify.model.NotifyRecord;
import com.cloud.portal.notify.service.NotifyReocrdService;
import com.netflix.discovery.converters.Auto;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * @author yuhaob
 * @date Created in 2020/3/18 9:56
 * @description:
 * @modified By:yuhaob
 */
@RestController
@AllArgsConstructor
@RequestMapping("/notifyRecord")
public class NotifyRecordController {
    @Auto
    private NotifyReocrdService notifyReocrdService;

    @GetMapping("/pageRecord")
    @SysLog(value = "查询通知列表",type = CommonConstants.LOG_QUERY)
    @ApiOperation("查询通知列表")
    public R pageRecord(Page page,NotifyRecord notifyRecord){
        R result = new R<>(notifyReocrdService.findPage(page,notifyRecord));
        return result;
    }

    @PostMapping("/update")
    @SysLog(value = "修改通知公告",type = CommonConstants.LOG_EDIT)
    @ApiOperation("修改通知")
    public R update(@RequestBody NotifyRecord notifyRecord){
        R result = new R<>(notifyReocrdService.updateByNotifyId(notifyRecord));
        return result;
    }
}
