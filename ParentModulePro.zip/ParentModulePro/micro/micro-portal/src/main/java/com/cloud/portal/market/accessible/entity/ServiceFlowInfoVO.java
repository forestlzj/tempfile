package com.cloud.portal.market.accessible.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

/**
 * @author chenchunl
 * @date Created in 2020/3/30 16:16
 * @description:
 * @modified By:chenchunl
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ServiceFlowInfoVO {

    @LogField(title = "主键")
    private String id;

    @LogField(title = "服务编号")
    private String serviceIds;


    @LogField(title = "申请人")
    private String applicant;


    @LogField(title = "申请时间")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date applyTime;

    @LogField(title = "审批人")
    private String approver;

    @LogField(title = "审批时间")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date approvalTime;


    @LogField(title = "状态（0-草稿,1-驳回,2-审批中,3-通过,）")
    private String status;


    @LogField(title = "审批意见")
    private String opinion;

    @LogField(title = "创建时间")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;


    @LogField(title = "更新时间")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;


    @LogField(title = "创建者")
    private String createBy;


    @LogField(title = "更新者")
    private String updateBy;


    @LogField(title = "删除标识")
    private String delFlag;

    @LogField(title = "申请说明）")
    private String applyInstructions;

    @LogField(title = "申请资料  （附件）")
    private String applyFiles;

    @LogField(title = "服务名称）")
    private String name;

    private String applicantName;

    private String approverName;

    private String statusValue;

    private String starTime;

    private String endTime;



}

