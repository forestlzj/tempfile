package com.cloud.portal.judged.instruction.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.judged.instruction.model.Instruction;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;


/**
 * @author Molly
 * @date Created in 2019/6/24
 * @description: 智能预警-指令mapper接口
 * @modified By: Molly
 */
public interface InstructionMapper extends BaseMapper<Instruction> {

    IPage<List<Instruction>> findListPage(IPage<Instruction> page,@Param("instruction") Instruction instruction);

    IPage<List<Instruction>> findOvertimeListPage(IPage<Instruction> page,@Param("instruction") Instruction instruction);

    int updateStatus(@Param("instruction") Instruction instruction);

    /**
     * 统计当天预警数
     * @param instruction
     * @return
     */
    List<Map<String,Object>> totalByToday(@Param("instruction") Instruction instruction);

    /**
     * 更新社区警务返回id
     * @param id
     * @param sqjwId
     * @return
     */
    boolean updateSqjwId(@Param("id") String id,@Param("sqjwId") String sqjwId);

}
