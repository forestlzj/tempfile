package com.cloud.portal.inforelease.message.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.inforelease.message.model.MessageReplay;

/**
 * @author rush
 * @Date Created in 2020/3/12 15:21
 * Description:
 * Modified By:
 */
public interface MessageReplayService extends IService<MessageReplay> {
    /**
     * 添加留言回复信息
     *
     * @param messageReplay
     * @return
     */
    boolean saveMessageReplay(MessageReplay messageReplay);

    /**
     * 根据留言板id 删除留言回复信息
     *
     * @param boardId 留言板id
     * @return
     */
    boolean deleteMessageReplay(String boardId);

    /**
     * 获取留言回复列表信息
     *
     * @param page
     * @param messageReplay
     * @return
     */
    IPage<MessageReplay> getListPage(IPage<MessageReplay> page, MessageReplay messageReplay);

}
