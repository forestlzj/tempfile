package com.cloud.portal.market.services.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.services.entity.ServiceFile;
import com.cloud.portal.market.services.entity.ServiceInterface;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;

/**
 * @author wuxx
 * @date 2020/3/10 16:51
 * @description: TODO
 * @modified By:
 **/
@RestController
public interface ServiceInterfaceService extends IService<ServiceInterface> {

    /**
     * 保存服务接口
     *
     * @param serviceInterface 服务接口
     * @return
     */
    Boolean saveServiceInterface(ServiceInterface serviceInterface);

    /**
     * 分页获取查询服务接口信息
     *
     * @param page 分页信息
     * @param serviceInterface 服务接口
     * @return
     */
    IPage findPage(Page page, ServiceInterface serviceInterface);

    /**
     * 查询我的服务接口（分页）
     * @param page
     * @param serviceInterface
     * @return
     */
    IPage findMyServicePage(Page page, ServiceInterface serviceInterface);

    /**
     * 查询可申请的服务接口   过滤掉已申请的服务接口
     * @param page
     * @param serviceInterface
     * @return
     */
    IPage findApplyService(Page page, ServiceInterface serviceInterface);

    /**
     * 查询可申请的服务接口   过滤掉已申请的服务接口
     * @param serviceInterface
     * @return
     */
    List<ServiceInterface> findApplyServiceList(ServiceInterface serviceInterface);

    /**
     * 上传图标信息
     *
     * @param file
     * @return
     * @throws Exception
     */
    R uploadIcon(MultipartFile file) throws Exception;

    /**
     * 下载图标
     *
     * @param base64Id
     * @return
     */
    InputStream downLoadIcon(String base64Id);

    /**
     * 删除图标
     *
     * @param base64Id
     * @return
     */
    R deleteIcon(String base64Id);

    /**
     * 更新服务状态
     * @param serviceInterface 服务接口
     * @return
     */
    boolean updateStatus(ServiceInterface serviceInterface);

    List<ServiceInterface> findList(ServiceInterface serviceInterface);

    /**
     * 查询热门服务
     * @param serviceInterface
     * @return
     */
    List<ServiceInterface> findHotService(ServiceInterface serviceInterface);

}
