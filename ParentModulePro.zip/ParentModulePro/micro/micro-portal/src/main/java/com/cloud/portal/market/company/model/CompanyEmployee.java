package com.cloud.portal.market.company.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author 姓名
 * @date Created in 2020/3/12 14:56
 * @description:
 * @modified By:姓名
 */
@Data
@TableName("T_PORTAL_COMPANY_EMPLOYEE")
@EqualsAndHashCode(callSuper = true)
public class CompanyEmployee extends Model<CompanyEmployee>{
    /**
     * 主键ID
     */
    @TableId
    private String id;
    /**
     * 姓名
     */
    private String name;
    /**
     * 身份证
     */
    private String idCard;
    /**
     * 电话号码
     */
    private String phone;
    /**
     * 公司主键id
     */
    private String companyId;
    /**
     * 性别
     */
    private String sex;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 人员简介
     */
    private String peopleProfile;
    /**
     * 住址
     */
     private String  address;
    /**
     * 职务（负责人，开发人员，运维人员，其他）
     */
    private String  dutyType;
    /**
     * 头像
     */
    private String avatar;
    /**
     * 创建时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * 删除标识
     */
    @TableLogic
    private String delFlag;
}
