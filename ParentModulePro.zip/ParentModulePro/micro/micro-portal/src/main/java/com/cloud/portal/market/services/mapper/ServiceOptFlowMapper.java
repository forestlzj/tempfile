package com.cloud.portal.market.services.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.services.entity.ServiceOptFlow;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;

/**
 * @author chenchunl
 * @date Created in 2020/4/13 9:37
 * @description: 服务上下架申请mapper
 * @modified By:chenchunl
 */
public interface ServiceOptFlowMapper extends BaseMapper<ServiceOptFlow> {

    /**
     * 服务上下架申请列表
     * @param page
     * @param serviceOptFlow
     * @return
     */
    IPage<ServiceOptFlow> findPage(Page<ServiceOptFlow> page, @Param("queryCondition")ServiceOptFlow serviceOptFlow);

    /**
     * 新增服务接口上下架申请
     * @param serviceOptFlow
     * @return
     */
    @Override
    int insert(ServiceOptFlow serviceOptFlow);


    /**
     * 提交服务接口申请
     * @param serviceOptFlow
     * @return
     */
    boolean submitServiceOptFlow (ServiceOptFlow serviceOptFlow);

    /**
     * 审批服务接口申请
     * @param serviceOptFlow
     * @return
     */
    boolean auditServiceOptFlow(ServiceOptFlow serviceOptFlow);
}
