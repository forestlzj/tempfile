package com.cloud.portal.market.catalog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.market.catalog.model.CatalogLink;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/10 16:19
 * @description: 目录编排管理关联mapper接口
 * @modified By: huangyingx
 */
@Mapper
public interface CatalogLinkMapper extends BaseMapper<CatalogLink> {

    boolean insertBatchByOtherId(@Param("catalogList") List<String> catalogList,@Param("otherId") String otherId);

    boolean deleteByOtherId(@Param("otherId")String otherId);

    List<CatalogLink> findObjByOtherId(@Param("otherId")String otherId);

    List<CatalogLink> findListByParentId(@Param("parentId")String parentId);

}
