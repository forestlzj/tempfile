package com.cloud.portal.market.company.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.company.model.Company;
import com.cloud.portal.market.company.model.CompanyEmployee;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;

/**
 * @author 姓名
 * @date Created in 2020/3/12 15:19
 * @description:
 * @modified By:姓名
 */
public interface CompanyEmployeeService extends IService<CompanyEmployee>{
    /**
     * 查询开发人员列表（分页）
     * @param page
     * @param companyEmployee
     * @return
     */
  IPage<List<CompanyEmployee>> page(IPage<CompanyEmployee> page, CompanyEmployee companyEmployee);
    /**
     * 删除图标
     *y
     * @param base64Id
     * @return
     */
    R deleteAvatar(String base64Id);
    /**
     * 上传图标信息
     *
     * @param file
     * @return
     * @throws Exception
     */
    R uploadAvatar(MultipartFile file) throws Exception;
    /**
     * 下载图标
     *
     * @param base64Id
     * @return
     */
    InputStream downLoadAvatar(String base64Id);
    /**
     * 新增开发人员
     *
     * @param employee
     * @return
     */
    Boolean saveEmployee(CompanyEmployee employee);

    /**
     * 更新员工信息
     * @param companyEmployee
     * @return
     */
    boolean updateEmployee(CompanyEmployee companyEmployee);

    /**
     * 更新删除标识
     * @param list
     * @return
     */
    boolean updateDelById(List<String> list);
}
