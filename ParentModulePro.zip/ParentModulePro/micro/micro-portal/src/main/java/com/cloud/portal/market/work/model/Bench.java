package com.cloud.portal.market.work.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:21
 * @description:个人工作台信息
 * @modified By:liuwei
 */
@Data
@TableName("T_PORTAL_WORK_BENCH")
@EqualsAndHashCode(callSuper = true)
public class Bench extends Model<Bench> {
    /**
     * 主键ID
     */
    @TableId
    private String id;
    /**
     * 用户id
     */
    private String userId;
    /**
     * 类型（0默认，1私有）
     */
    private String shareType;
    /**
     * 样式类型（样式1，样式2，样式3）
     */
    private String styleType;
    /**
     * 创建时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;

    /**
     * 组件关联信息
     */
    @TableField(exist = false)
    private List<BenchLink> benchLinks;

    /**
     * 组件关联信息
     */
    @TableField(exist = false)
    private List<BenchLink> benchLeftLinks;

    /**
     * 组件关联信息
     */
    @TableField(exist = false)
    private List<BenchLink> benchRightLinks;
}
