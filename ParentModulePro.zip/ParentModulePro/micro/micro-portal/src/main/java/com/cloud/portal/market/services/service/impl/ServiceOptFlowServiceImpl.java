package com.cloud.portal.market.services.service.impl;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.services.entity.ServiceInterface;
import com.cloud.portal.market.services.entity.ServiceOptFlow;
import com.cloud.portal.market.services.mapper.ServiceInterfaceMapper;
import com.cloud.portal.market.services.mapper.ServiceOptFlowMapper;
import com.cloud.portal.market.services.service.ServiceOptFlowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
 * @author chenchunl
 * @date Created in 2020/4/13 9:42
 * @description:
 * @modified By:chenchunl
 */
@Service
public class ServiceOptFlowServiceImpl extends ServiceImpl<ServiceOptFlowMapper, ServiceOptFlow> implements ServiceOptFlowService {

    @Autowired
    private ServiceInterfaceMapper serviceInterfaceMapper;

    @Override
    public IPage findPage(Page page, ServiceOptFlow serviceOptFlow) {

        //判断是否是管理员  不是管理员只能查自己的申请记录
        if(!SecurityUtils.getUser().isAdmin()){
            serviceOptFlow.setApplicant(SecurityUtils.getUser().getId());
        }

        return this.baseMapper.findPage(page, serviceOptFlow);
    }

    @Override
    public boolean saveServiceOptFlow(ServiceOptFlow serviceOptFlow) {

        Date now = new Date();
        String userId = SecurityUtils.getUser().getId();
        serviceOptFlow.setId(IdUtil.randomUUID());

        serviceOptFlow.setDelFlag(CommonConstants.STATUS_NORMAL);
        serviceOptFlow.setStatus("0");
        serviceOptFlow.setCreateBy(userId);
        serviceOptFlow.setUpdateBy(userId);
        serviceOptFlow.setCreateTime(now);
        serviceOptFlow.setUpdateTime(now);

        return this.baseMapper.insert(serviceOptFlow) == 1;
    }

    @Override
    public boolean updateServiceOptFlow(ServiceOptFlow serviceOptFlow) {

        serviceOptFlow.setUpdateBy(SecurityUtils.getUser().getId());
        serviceOptFlow.setUpdateTime(new Date());
        return this.baseMapper.updateById(serviceOptFlow) == 1;
    }

    @Override
    public boolean submitServiceOptFlow(ServiceOptFlow serviceOptFlow) {
        Date now = new Date();
        String userId = SecurityUtils.getUser().getId();
        serviceOptFlow.setStatus("2");
        serviceOptFlow.setApplicant(userId);
        serviceOptFlow.setUpdateBy(userId);
        serviceOptFlow.setApplyTime(now);
        serviceOptFlow.setUpdateTime(now);
        return this.baseMapper.submitServiceOptFlow(serviceOptFlow);
    }

    @Override
    public R removeById(String id) {

        ServiceOptFlow serviceOptFlow = new ServiceOptFlow();

        serviceOptFlow.setId(id);
        serviceOptFlow.setDelFlag(CommonConstants.STATUS_DEL);
        serviceOptFlow.setUpdateTime(new Date());
        serviceOptFlow.setUpdateBy(SecurityUtils.getUser().getId());
        return new R<> ( this.baseMapper.updateById(serviceOptFlow));

    }

    @Override
    public boolean auditServiceOptFlow(ServiceOptFlow serviceOptFlow) {
        Date now = new Date();
        String userId = SecurityUtils.getUser().getId();
        serviceOptFlow.setApprover(userId);
        serviceOptFlow.setUpdateBy(userId);
        serviceOptFlow.setApprovalTime(now);
        serviceOptFlow.setUpdateTime(now);
        //申请通过对服务接口信息操作
        if ("3".equals(serviceOptFlow.getStatus())){
            ServiceOptFlow serviceFlow = this.baseMapper.selectById(serviceOptFlow.getId());
            //判断申请的操作
            //申请操作为上下架时修改服务接口信息状态
            if("0".equals(serviceFlow.getOptType()) || "1".equals(serviceFlow.getOptType())){
                ServiceInterface serviceInterface = new ServiceInterface();
                serviceInterface.setId(serviceFlow.getServiceId());
                serviceInterface.setStatus(serviceFlow.getStatus());
                serviceInterface.setUpdateBy(userId);
                serviceInterface.setUpdateTime(now);
                serviceInterfaceMapper.updateStatus(serviceInterface);
            }
        }
        return this.baseMapper.auditServiceOptFlow(serviceOptFlow);
    }
}
