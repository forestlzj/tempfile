package com.cloud.portal.market.apptool.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.apptool.model.UsePowerFlow;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/17 16:19
 * @description: 应用工具申请访问流程mapper接口
 * @modified By: huangyingx
 */
@Mapper
public interface UsePowerFlowMapper extends BaseMapper<UsePowerFlow> {

    IPage<List<UsePowerFlow>> findPage(IPage<UsePowerFlow> page,@Param("usePowerFlow") UsePowerFlow usePowerFlow);

    List<UsePowerFlow> findPage(@Param("usePowerFlow") UsePowerFlow usePowerFlow);


}
