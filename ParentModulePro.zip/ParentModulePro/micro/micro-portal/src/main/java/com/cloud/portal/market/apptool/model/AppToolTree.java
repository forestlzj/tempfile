package com.cloud.portal.market.apptool.model;

import com.cloud.admin.api.dto.TreeNode;
import lombok.Data;

import java.io.Serializable;

/**
 * @author wengshij
 * @date Created in 2020/3/26 15:50
 * @description:应用工具树
 * @modified By:wengshij
 */
@Data
public class AppToolTree extends TreeNode implements Serializable {
    /**
     * 名称
     */
    private String label;
    /**
     * 显示值
     */
    private String value;
    /**
     * 类型 应用 app 或者 工具
     */
    private String type;


}
