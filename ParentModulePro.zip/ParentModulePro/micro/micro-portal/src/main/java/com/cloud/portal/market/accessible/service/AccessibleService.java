package com.cloud.portal.market.accessible.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.accessible.entity.ServiceFlowInfo;

import java.util.List;

/**
 * @author chenchunl
 * @date Created in 2020/3/23 14:55
 * @description:
 * @modified By:chenchunl
 */
public interface AccessibleService extends IService<ServiceFlowInfo> {

    /**
     * 服务申请列表
     * @param page
     * @param serviceFlowInfo
     * @return
     */
    IPage  page(Page page,ServiceFlowInfo serviceFlowInfo);

    /**
     * 服务审核列表
     * @param page
     * @param serviceFlowInfo
     * @return
     */
    IPage  auditPage(Page page,ServiceFlowInfo serviceFlowInfo);

    /**
     * 删除服务申请
     * @param id
     * @return
     */
     R removeApply(String id);

    /**
     * 新增服务申请
     * @param serviceFlowInfo
     * @return
     */
     R applyInfoSave(ServiceFlowInfo serviceFlowInfo);

    /**
     * 修改服务申请
     * @param serviceFlowInfo
     * @return
     */
     R updateApplyInfo(ServiceFlowInfo serviceFlowInfo);

    /**
     * 提交服务申请
     * @param id
     * @return
     */
     R submitApplyInfo(String id);

    /**
     * 审核服务申请
     * @param serviceFlowInfo
     * @return
     */
     R auditApplyInfo(ServiceFlowInfo serviceFlowInfo);

    /**
     * 根据申请id获取申请的服务接口信息
     * @param id
     * @return
     */
     R getServiceInterfaceById(String id);

    /**
     * 提交服务申请
     * @param serviceFlowInfo
     * @return
     */
     R again(ServiceFlowInfo serviceFlowInfo);

    /**
     * 查看是否有重复申请的服务
     * @return
     */
    List<ServiceFlowInfo> findListByService(ServiceFlowInfo serviceFlowInfo);

}
