package com.cloud.portal.inforelease.message.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.common.util.DateUtil;
import com.cloud.portal.inforelease.message.mapper.MessageBoardMapper;
import com.cloud.portal.inforelease.message.model.MessageBoard;
import com.cloud.portal.inforelease.message.model.MessageBoardPraise;
import com.cloud.portal.inforelease.message.service.MessageBoardService;
import com.cloud.portal.inforelease.message.service.MessageReplayService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author rush
 * @Date Created in 2020/3/12 15:28
 * Description:
 * Modified By:
 */
@Service
@AllArgsConstructor
public class MessageBoardServiceImpl extends ServiceImpl<MessageBoardMapper, MessageBoard> implements MessageBoardService {

    private static final int SEARCH_DATE_LENGTH = 2;
    /**
     * minio 接口服务信息
     */
    @Autowired
    private MinioTemplate minioTemplate;
    @Autowired
    private MessageReplayService messageReplayService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveMessageBoard(MessageBoard messageBoard) {
        messageBoard = initParams(messageBoard);
        MessageBoard mb = null;
        if (StringUtils.isNotEmpty(messageBoard.getParentId())) {
            mb = this.baseMapper.selectById(messageBoard.getParentId());
            mb.setCommentCount(mb.getCommentCount() + 1);
            mb.setPosition(mb.getPosition() + 1);
            this.baseMapper.updateById(mb);
        }
        if (mb != null) {
            messageBoard.setPosition(mb.getPosition());
            if (SecurityUtils.getUser().getId().equals(mb.getCreateBy())) {
                messageBoard.setOnLandlord(true);
            }
        }
        return SqlHelper.delBool(this.baseMapper.insert(messageBoard));
    }

    @Override
    public IPage<MessageBoard> getListPage(IPage<MessageBoard> page, MessageBoard messageBoard) {
        IPage<MessageBoard> iPage = this.baseMapper.getListPage(page, initSearch(messageBoard));
        for (MessageBoard msb :
                iPage.getRecords()) {
            msb.setReplyNum(msb.getReplies().size());
        }
        return iPage;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean removeById(String id) {
        MessageBoard messageBoard = this.baseMapper.selectById(id);
        try {
            //删除该条留言的点赞
            this.baseMapper.deletePraise(id,"");
            //删除该留言及评论
            this.baseMapper.deleteMessageBoard(id);
            //删除该留言评论下所有回复
            messageReplayService.deleteMessageReplay(id);
            MessageBoard mb;
            if (StringUtils.isNotEmpty(messageBoard.getParentId())) {
                mb = this.baseMapper.selectById(messageBoard.getParentId());
                mb.setCommentCount(this.baseMapper.selectList(new LambdaQueryWrapper<MessageBoard>().eq(MessageBoard::getParentId, messageBoard.getParentId())).size());
                this.baseMapper.updateById(mb);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    public MessageBoard getMessageBoardById(String id) {
        return this.baseMapper.getMessageBoardById(id,SecurityUtils.getUser().getId());
    }

    @Override
    public R uploadPic(MultipartFile file) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Map<String, String> result = new HashMap<>(2);
        StringBuffer nameBuffer = new StringBuffer();
        String fileName = file.getOriginalFilename();
        String newFileName = IdUtil.randomUUID() + fileName.substring(fileName.lastIndexOf("."));
        nameBuffer.append("pic").append("/")
                .append(SecurityUtils.getUser().getId()).append("/")
                .append(sdf.format(System.currentTimeMillis())).append("/")
                .append(newFileName);
        minioTemplate.createBucket(PortalConstants.MINIO_MESSAGE_BOARD);
        minioTemplate.putObject(PortalConstants.MINIO_MESSAGE_BOARD, nameBuffer.toString(), file.getInputStream());
        String baseId = Base64.encode(nameBuffer.toString());
        result.put("name", fileName);
        result.put("baseId", baseId);
        result.put("url", "portal/message/board/getPic/" + baseId);
        return R.ok(result);
    }

    @Override
    public InputStream downLoadPic(String base64Id) {
        String fileName = Base64.decodeStr(base64Id);
        InputStream inputStream = minioTemplate.getObject(PortalConstants.MINIO_MESSAGE_BOARD, fileName);
        return inputStream;
    }

    private MessageBoard initParams(MessageBoard messageBoard) {
        MicroUser microUser = SecurityUtils.getUser();
        messageBoard.setUserNickName(microUser.getSysUser().getName());
        messageBoard.setDelFlag(CommonConstants.STATUS_NORMAL);
        messageBoard.setCreateBy(microUser.getId());
        messageBoard.setUpdateBy(microUser.getId());
        messageBoard.setCreateTime(new Date(System.currentTimeMillis()));
        messageBoard.setUpdateTime(messageBoard.getCreateTime());
        messageBoard.setPostByAdmin(microUser.isAdmin());
        return messageBoard;
    }

    /**
     * 初始化 查询条件信息
     *
     * @param messageBoard
     * @return
     */
    private MessageBoard initSearch(MessageBoard messageBoard) {
        String symbol = ",";
        if (null == messageBoard) {
            messageBoard = new MessageBoard();
        }
        messageBoard.setUserId(SecurityUtils.getUser().getId());
        String searchTime = StringUtils.isBlank(messageBoard.getSearchTime()) ? null : messageBoard.getSearchTime().trim();
        if (StringUtils.isNotBlank(searchTime) && messageBoard.getSearchTime().contains(symbol)) {
            String[] searchDate = StringUtils.split(messageBoard.getSearchTime(), symbol);
            if (ArrayUtils.isNotEmpty(searchDate) && searchDate.length == SEARCH_DATE_LENGTH) {
                messageBoard.setCreateTime(DateUtil.parseDate(searchDate[0]));
                messageBoard.setUpdateTime(DateUtil.parseDate(searchDate[1]));
            }
        }
        return messageBoard;
    }

    /**
     * 留言板点赞
     * @param  messageBoardPraise
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean savePraise(MessageBoardPraise messageBoardPraise) {
        baseMapper.updateLickCount(messageBoardPraise.getBoardId(),1);
        messageBoardPraise.setUserId(SecurityUtils.getUser().getId());
        return baseMapper.savePraise(messageBoardPraise);
    }

    /**
     * 取消留言板点赞
     * @param boardId 留言板id
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deletePraise(String boardId) {
        baseMapper.updateLickCount(boardId,-1);
        String userId = SecurityUtils.getUser().getId();
        return baseMapper.deletePraise(boardId,userId);
    }

}
