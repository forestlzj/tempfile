package com.cloud.portal.notify.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.portal.notify.model.Notify;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author yuhaob
 * @date Created in 2020/3/17 9:11
 * @description:
 * @modified By:yuhaob
 */
@Mapper
public interface NotifyMapper extends BaseMapper<Notify> {
    /**
     * 分页查询数据表字段
     * @param iPage    参数集
     * @param notify 查询参数列表
     * @return Notify 数据表集合
     */
    IPage<Notify> findPage(IPage<Notify> iPage,  @Param("query")Notify notify);

    Notify findView(Notify notify);
    /**
     * 我的通知
     * @param iPage    参数集
     * @param notify 查询参数列表
     * @return Notify 数据表集合
     */
    IPage<Notify> findPageHome(IPage<Notify> iPage,  @Param("query")Notify notify);

    /**
     * 查询该部门有多少存在的用户
     * @param deptId 部门ID
     * @return Integer 有多少用户
     */
    Integer selectUserByDept(@Param("deptId") String deptId);
}
