package com.cloud.portal.market.company.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;


/**
 * @author liuwei
 * @date Created in 2020/3/11 17:19
 * @description:开发公司实体类
 * @modified By:liuwei
 */
@Data
@TableName("T_PORTAL_COMPANY")
@EqualsAndHashCode(callSuper = true)
public class Company extends Model<Company> {
    /**
     * 主键ID
     */
    @TableId
    private String id;
    /**
     * 公司名称
     */
    private String name;
    /**
     * 注册地址
     */
    private String address;
    /**
     * 成立日期
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date buildTime;
    /**
     * 公司简介
     */
    private String companyProfile;
    /**
     * 公司icon
     */
    private String icon;
    /**
     * 创建时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * 删除标识
     */
    private String delFlag;

    /*private List<CompanyEmployee> companyEmployees;*/

    /**
     * 开发人员集合
     */
    @TableField(exist = false)
    private List<CompanyEmployee> employeeList;
}
