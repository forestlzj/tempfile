package com.cloud.portal.market.apptool.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolUse;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/23 16:42
 * @description:
 * @modified By:wengshij
 * @modified desc:添加应用工具使用更新插入操作
 */
@Mapper
public interface AppToolUseMapper extends BaseMapper<AppToolUse> {



    /**
     * 应用工具插入更新操作
     * @param appToolUse
     * @return
     */
    int mergeAppToolUse(AppToolUse appToolUse);

    /**
     * 获取最近使用应用工具
     * @param appToolUse
     * @return
     */
    List<AppTool> getUseList(AppToolUse appToolUse);
}
