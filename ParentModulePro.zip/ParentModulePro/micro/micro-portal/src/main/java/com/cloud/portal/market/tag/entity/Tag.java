package com.cloud.portal.market.tag.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author maojia
 * @date Created in 2020/3/11 16:09
 * @description:应用工具标签信息实体类
 * @modified By:maojia
 */
@Data
@TableName("T_PORTAL_APP_TOOL_LABEL")
public class Tag extends Model<Tag> {

    @LogField(title = "主键ID")
    private String id;

    @LogField(title = "标签名称")
    private String label;

    @LogField(title = "标签类型（0 -应用 1-工具）")
    private String type;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private LocalDateTime createTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private LocalDateTime updateTime;

    @LogField(title = "排序")
    private String sort;

}
