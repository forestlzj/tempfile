package com.cloud.portal.metadata.standardfields.constant;

/**
 * @author vlong
 * @date Created in 2017/12/26 15:29
 * Description:
 * Modified By:
 */
public enum TableKindEnum {

    Table,View,Synonym,Mv;
}
