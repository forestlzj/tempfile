package com.cloud.portal.market.common.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import lombok.Data;
import lombok.EqualsAndHashCode;


/**
 * @author wengshij
 * @date Created in 2020/4/21 11:14
 * @description: 数据、服务操作监控统计报表
 * @modified By:wengshij
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UseMonitor extends Model<UseMonitor> {

    @LogField(title = "业务表编号")
    private String bussId;

    @LogField(title = "日志访问类型")
    private String operateType;

    @LogField(title = "模块名称")
    private String title;

    @LogField(title = "访问总数")
    private String total;

    @LogField(title = "访问成功数")
    private String successTotal;

    @LogField(title = "访问失败数")
    private String errorTotal;

    @LogField(title = "访问成功率")
    private String successUsage;

    @LogField(title = "访问失败率")
    private String errorUsage;

    @LogField(title = "访问成功率-小数")
    private String successUsageDecimal;

    @LogField(title = "访问失败率-小数")
    private String errorUsageDecimal;

    /**查询参数-时间范围*/
    @TableField(exist = false)
    private String beginTime;
    @TableField(exist = false)
    private String endTime;
    /**查询参数-操作符 gt大于等于 lt小于等于*/
    @TableField(exist = false)
    private String operator;

}
