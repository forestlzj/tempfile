package com.cloud.portal.metadata.datasource.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.cloud.admin.api.annotation.LogField;
import com.cloud.portal.metadata.datasource.constant.DataSourceEnum;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

/**
 * @author vlong
 * @date Created in 2017/12/19 17:11
 * description: 关系型数据库基类
 * modified By:
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RdbSource extends DataSource {

    private static final long serialVersionUID = 1L;
    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;
    /**库名称*/
    @LogField(title = "库名称")
    private String name;
    /**类型*/
    @LogField(title = "类型")
    private DataSourceEnum type;
    /**IP地址*/
    @LogField(title = "ip")
    private String ip;
    /**账号*/
    @LogField(title = "账号")
    private String account;
    /**密码*/
    private String pwd;
    /**端口*/
    @LogField(title = "端口")
    private String port;
    /**实例名称*/
    @LogField(title = "实例名称")
    private String serverName;
    /**schema名*/
    @LogField(title = "schema")
    private String schema;
    /**删除标志*/
    private String del_flag;
    /**来源单位*/
    @LogField(title = "来源单位")
    private String unit;
    /**联系人*/
    private String userName;
    /**联系方式*/
    private String phone;
    /**数据库连接地址*/
    @LogField(title = "jdbcUrl")
    private String jdbcUrl;
    /**连接结果信息*/
    @LogField(title = "结果信息")
    private String message;
    /**创建者*/
    private String createBy;
    /**更新者*/
    private String updateBy;
    /**创建时间*/
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createDate;
    /**更新时间*/
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateDate;
    /**所属行政区划*/
    private String area;
    /**0sid， 1service_name*/
    private String link;
    /**是否集群*/
    private String clusterFlag;
    /**集群tns信息*/
    private String clusterTns;

    private Connection conn;
    private PreparedStatement preparedStatement;
    private ResultSet resultSets;
}
