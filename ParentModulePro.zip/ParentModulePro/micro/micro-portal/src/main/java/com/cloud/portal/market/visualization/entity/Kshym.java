package com.cloud.portal.market.visualization.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.cloud.admin.api.annotation.LogField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author maojia
 * @date Created in 2020/4/13 10:46
 * @description:可视化页面
 * @modified By:maojia
 */
@Data
@TableName("T_PORTAL_KSHYM")
public class Kshym implements Serializable {

  @LogField(title = "主键ID")
  private String id;
  @LogField(title = "模型名称")
  private String mxmc;
  @LogField(title = "模型地址")
  private String mxdz;
  @LogField(title = "模型所属地市")
  private String mxssds;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
  private LocalDateTime createdate;
  @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
  private LocalDateTime updatetime;
  @LogField(title = "建模单位")
  private String jmdw;
  @LogField(title = "类型")
  private String type;
  @LogField(title = "排序")
  private String sort;


}
