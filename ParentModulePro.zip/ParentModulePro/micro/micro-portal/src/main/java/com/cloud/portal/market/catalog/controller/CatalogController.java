package com.cloud.portal.market.catalog.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.cloud.admin.api.vo.TreeUtil;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.catalog.model.Catalog;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.catalog.service.CatalogLinkService;
import com.cloud.portal.market.catalog.service.CatalogService;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Wrapper;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author huangyingx
 * @date Created in 2020/3/11 13:19
 * @description: 目录编排控制层
 * @modified By: huangyingx
 */
@RestController
@AllArgsConstructor
@RequestMapping("/market/catalog")
public class CatalogController {

    @Autowired
    private CatalogService catalogService;
    @Autowired
    private CatalogLinkService catalogLinkService;

    @GetMapping("/list/{type}")
    @SysLog(value = "根据类型获取列表信息")
    @ApiOperation(httpMethod = "GET", value = "根据类型获取列表信息")
    public R findListByType(@PathVariable("type") String type){
        return new R<>(TreeUtil.buildByRecursive(catalogService.findListByType(type),"0"));
    }

    @PostMapping("/add")
    @SysLog(value = "添加目录",type = CommonConstants.LOG_ADD)
    public R save(@RequestBody Catalog catalog){
        //校验同级目录下存在重名
        if(catalogService.hasExistCatalog(catalog)){
            return R.failed("该目录已存在");
        }else{
            return new R<>(catalogService.saveCatalog(catalog));
        }
    }

    @PutMapping("/put")
    @SysLog(value = "修改目录",type = CommonConstants.LOG_EDIT)
    public R putPlanLibrary(@RequestBody Catalog catalog) {
        //校验同级目录下存在重名
        if(catalogService.hasExistCatalog(catalog)){
            return R.failed("该目录已存在");
        }else{
            return new R<>(catalogService.updateCatalog(catalog));
        }
    }

    @DeleteMapping("/delete/{id}")
    @SysLog(value = "删除目录",type = CommonConstants.LOG_DELELE)
    public R deleteById(@PathVariable String id) {
        //被引用后不能删除校验
        //判断是否是子节点
        boolean flag = false;
        List<CatalogLink> list;
        Catalog catalog = catalogService.findById(id);
        if(Catalog.ROOTID.equals(catalog.getParentId())){
            //父节点检查子节点是否被引用
            list = catalogLinkService.findByParentId(id);
        }else{
            list = catalogLinkService.list(Wrappers.query(new CatalogLink()).eq(CatalogLink::getCatalogId,id));
        }
        if(list!=null && list.size()>0){
            return R.failed("该目录或其子级已被引用，不能删除");
        }else{
            return new R<>(catalogService.deleteById(id));
        }
    }

    @GetMapping("/link/{otherId}")
    @SysLog(value = "根据otherId获取列表信息（不含名称）")
    @ApiOperation(httpMethod = "GET", value = "根据otherId获取列表信息（不含名称）")
    public R findLinkByOtherId(@PathVariable("otherId") String otherId){
        return new R<>(catalogLinkService.findByOtherId(otherId));
    }

    @GetMapping("/link_obj/{otherId}")
    @SysLog(value = "根据otherId获取列表信息(含名称)")
    @ApiOperation(httpMethod = "GET", value = "根据otherId获取列表信息(含名称)")
    public R findLinkObjByOtherId(@PathVariable("otherId") String otherId){
        return new R<>(catalogLinkService.findObjByOtherId(otherId));
    }


    @PutMapping("save_sort")
    @SysLog(value = "保存子级排序")
    public R saveSort(@RequestBody List<Catalog> catalogList){
        return new R<>(catalogService.saveSort(catalogList));
    }
}
