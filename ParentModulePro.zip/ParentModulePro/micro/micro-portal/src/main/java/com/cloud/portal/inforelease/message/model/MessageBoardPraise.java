package com.cloud.portal.inforelease.message.model;

import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * @author ryt
 * @Date Created in 2020/5/14 17:32
 * Description: 留言板点赞实体
 * Modified By:
 */
@Data
@TableName("T_PORTAL_MESSAGE_BOARD_PRAISE")
@EqualsAndHashCode(callSuper = true)
public class MessageBoardPraise extends Model<MessageBoardPraise> {
    /**
     * id
     */
    @TableId(type = IdType.UUID)
    private String id;
    /**
     * 留言板id
     */
    private String boardId;
    /**
     * 用户id
     */
    private String userId;

    /**
     * 点赞时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private LocalDateTime praiseTime;

}
