package com.cloud.portal.market.accessible.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.accessible.entity.ServiceFlowInfo;
import com.cloud.portal.market.accessible.service.AccessibleService;
import com.cloud.portal.market.accessible.service.impl.AccessibleServiceImpl;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.UsePowerFlow;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.services.entity.ServiceInterface;
import io.swagger.annotations.Api;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 * @author chenchunl
 * @date Created in 2020/3/23 14:34
 * @description:   服务申请流程controller
 * @modified By:chenchunl
 */
@RestController
@AllArgsConstructor
@RequestMapping("/accessible/")
@Api(value = "accessible/apply", description = "服务申请流程模块")
public class AccessibleController {

    @Autowired
    private AccessibleService accessibleService;


    @GetMapping(value = "page")
    @SysLog(value = "服务申请列表查询分页")
    public R applyForPage(Page page, ServiceFlowInfo serviceFlowInfo) {
        return R.ok(accessibleService.page(page, serviceFlowInfo));
    }


    @GetMapping("/auditPage")
    @SysLog(value = "服务申请审核列表查询分页")
    public R auditPage(Page page, ServiceFlowInfo serviceFlowInfo) {
        return R.ok(accessibleService.auditPage(page, serviceFlowInfo));
    }

    /**
     * 删除服务接口
     *
     * @param id ID 服务接口id
     * @return success/false
     */
    @SysLog(value = "删除服务申请",type = CommonConstants.LOG_DELELE)
//    @PreAuthorize("@pms.hasPermission('service_interface_del')")
    @DeleteMapping("/{id}")
    public R removeById(@PathVariable String id) {
        return accessibleService.removeApply(id);
    }

    @PostMapping("/save")
    @SysLog(value = "新增服务申请")
    public R ApplyInfoSave(@Valid @RequestBody ServiceFlowInfo serviceFlowInfo) {

        if("2".equals(serviceFlowInfo.getStatus())){
            ServiceFlowInfo search = new ServiceFlowInfo();
            search.setServiceIds(serviceFlowInfo.getServiceIds());
            search.setStatus(serviceFlowInfo.getStatus());
            List<ServiceFlowInfo> list = accessibleService.findListByService(search);
            if(list!=null && list.size()>0){
                return R.failed(list,"有"+list.size()+"个服务重复提交使用申请");
            }
        }
        return  accessibleService.applyInfoSave(serviceFlowInfo);
    }

    @PostMapping("/update")
    @SysLog(value = "修改服务申请信息")
    public R updateApplyInfo(@Valid @RequestBody ServiceFlowInfo serviceFlowInfo) {
        return accessibleService.updateApplyInfo(serviceFlowInfo);
    }

    @PostMapping("/audit")
    @SysLog(value = "审核服务申请信息")
    @PreAuthorize("@pms.hasPermission('accessible_apply_audit')")
    public R auditApplyInfo(@Valid @RequestBody ServiceFlowInfo serviceFlowInfo) {
        return accessibleService.auditApplyInfo(serviceFlowInfo);
    }

    @SysLog(value = "提交服务申请",type = CommonConstants.LOG_DELELE)
    @PostMapping("/submit/{id}")
    public R submitApplyInfo(@PathVariable String id) {
        return accessibleService.submitApplyInfo(id);
    }

    @SysLog(value = "根据申请id获取申请的服务接口信息",type = CommonConstants.LOG_DELELE)
    @GetMapping("/serviceInterface/{id}")
    public R getServiceInterfaceById(@PathVariable String id) {
        return accessibleService.getServiceInterfaceById(id);
    }

    @PostMapping("/again")
    @SysLog(value = "提交服务申请")
    public R ApplyInfoAgain(@Valid @RequestBody ServiceFlowInfo serviceFlowInfo) {
        return  accessibleService.applyInfoSave(serviceFlowInfo);
    }

    /**
     * 校验应用工具集合当前用户是否有授权
     * @param ids
     * @return
     */
  /*  @GetMapping("exists")
    @SysLog("校验应用工具集合当前用户是否有授权")
    public R existsPower(@RequestParam(value = "ids",required = true)  String ids,
                         @RequestParam(value = "status",required = false)String status){
        return R.ok(appToolPowerService.exists(ids,status));
    }*/
}
