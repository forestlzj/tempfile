package com.cloud.portal.market.work.service.impl;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.work.mapper.BenchComponentMapper;
import com.cloud.portal.market.work.mapper.BenchMapper;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchComponent;
import com.cloud.portal.market.work.service.BenchComponentService;
import com.cloud.portal.market.work.service.BenchService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Wrapper;
import java.util.Date;
import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/8 15:11
 * @description:个人工作台组件信息
 * @modified By:liuwei
 */
@Service
@AllArgsConstructor
public class BenchComponentServiceImpl extends ServiceImpl<BenchComponentMapper, BenchComponent> implements BenchComponentService {

    /**
     * 查询列表（分页）
     * @param page
     * @param benchComponent
     * @return
     */
    @Override
    public IPage<BenchComponent> page(IPage<BenchComponent> page, BenchComponent benchComponent) {
        return this.baseMapper.findListPage(page,benchComponent);
    }


    /**
     * 查询列表（分页）
     * @param page
     * @param benchComponent
     * @return
     */
    @Override
    public IPage<BenchComponent> findQueryPage(IPage<BenchComponent> page, BenchComponent benchComponent) {
        IPage<BenchComponent> benchComponentPage=this.baseMapper.findQueryPage(page,benchComponent);
        return benchComponentPage;
    }


    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateDel(List<String> list){
        try{
            this.baseMapper.updateDel(list);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveComponent(BenchComponent benchComponent) {
        benchComponent = initComponent(benchComponent);
        return SqlHelper.delBool(this.baseMapper.insert(benchComponent));
    }

    private BenchComponent initComponent(BenchComponent benchComponent) {
        MicroUser microUser = SecurityUtils.getUser();
        benchComponent.setId(IdUtil.randomUUID());
        benchComponent.setUpdateBy(microUser.getId());
        benchComponent.setCreateBy(microUser.getId());
        benchComponent.setCreateTime(new Date(System.currentTimeMillis()));
        benchComponent.setUpdateTime(benchComponent.getCreateTime());
        benchComponent.setDelFlag(CommonConstants.STATUS_NORMAL);
        return benchComponent;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateComponent(BenchComponent benchComponent) {
        benchComponent = updateInit(benchComponent);
        return SqlHelper.delBool(this.baseMapper.updateById(benchComponent));
    }

    private BenchComponent updateInit(BenchComponent benchComponent) {
        MicroUser microUser = SecurityUtils.getUser();
        benchComponent.setUpdateTime(new Date(System.currentTimeMillis()));
        benchComponent.setUpdateBy(microUser.getId());
        benchComponent.setDelFlag(CommonConstants.STATUS_NORMAL);
        return benchComponent;
    }


    /**
     * 查询工作台可以添加的组件信息
     * @param bench
     * @return
     */
    @Override
    public List<BenchComponent> findByBenchId(Bench bench) {
        return this.baseMapper.findAll();
    }


    /**
     * 根据value查询组件信息
     * @param benchComponent
     * @return
     */
    @Override
    public BenchComponent findByValue(BenchComponent benchComponent){
        return this.baseMapper.findByValue(benchComponent);
    }
}
