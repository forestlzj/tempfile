package com.cloud.portal.market.apptool.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.core.util.R;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.apptool.mapper.OptManualMapper;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.apptool.service.OptManualService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wengshij
 * @date Created in 2020/3/13 10:13
 * @description: 应用工具操作手册文件信息实现层
 * @modified By:wengshij
 */
@Service
@Slf4j
public class OptManualServiceImpl extends ServiceImpl<OptManualMapper, OptManual> implements OptManualService {

    /**
     * minio 连接信息
     */
    @Autowired
    private MinioTemplate minioTemplate;

    @Override
    public R uploadManual(MultipartFile file) throws Exception {
        String fileName = file.getOriginalFilename();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String newFileName = IdUtil.randomUUID() + fileName.substring(fileName.lastIndexOf("."));
        StringBuffer nameBuffer = new StringBuffer();
        nameBuffer.append("manual").append("/")
                .append(SecurityUtils.getUser().getId()).append("/")
                .append(sdf.format(System.currentTimeMillis())).append("/")
                .append(newFileName);
        minioTemplate.createBucket(PortalConstants.MINIO_MARKET_BUCKET);
        String url = Base64.encode(nameBuffer.toString());
        minioTemplate.putObject(PortalConstants.MINIO_MARKET_BUCKET, nameBuffer.toString(), file.getInputStream());
        return R.ok(url);
    }

    @Override
    public R deleteManual(OptManual optManual) {
        if (null != optManual && StringUtils.isNotBlank(optManual.getFiles())) {
            String filePath = optManual.getFiles();
            Arrays.stream(filePath.split(",")).forEach(path -> {
                try {
                    minioTemplate.removeObject(PortalConstants.MINIO_MARKET_BUCKET, Base64.decodeStr(path));
                } catch (Exception e) {
                    log.error("文件清除异常", e.getMessage());
                    e.printStackTrace();
                }
            });
            return R.ok("文件清除成功");
        } else {
            return R.failed("清除失败、文件不存在");
        }


    }

    @Override
    public InputStream downLoadManual(OptManual optManual) {

        String fileName = Base64.decodeStr(optManual.getFiles());
        InputStream inputStream = minioTemplate.getObject(PortalConstants.MINIO_MARKET_BUCKET, fileName);
        if(StringUtils.isNotBlank(optManual.getId())){
            optManual.setDownloadNum(optManual.getDownloadNum() + 1);
            this.baseMapper.updateById(optManual);
        }
        return inputStream;
    }

    @Override
    public List<OptManual> findList(OptManual optManual) {
        Map<String, Object> map = new HashMap<>(1);
        map.put("APP_TOOL_ID", optManual.getAppToolId());
        return this.baseMapper.selectByMap(map);

    }

}
