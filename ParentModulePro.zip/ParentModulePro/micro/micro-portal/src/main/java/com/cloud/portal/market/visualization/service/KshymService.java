package com.cloud.portal.market.visualization.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.visualization.entity.Kshym;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/4/13 11:04
 * @description:
 * @modified By:maojia
 */
public interface KshymService extends IService<Kshym> {
    /**
     * 查询列表（分页）
     * @param page
     * @param kshym
     * @return
     */
    IPage<List<Kshym>> findListPage(IPage<Kshym> page,Kshym kshym);

    /**
     * 查询列表
     * @param all
     * @return
     */
    List<Kshym> findList(String all);

    /**
     * 根据id查询
     * @param id
     * @return
     */
    List<Kshym> findListById(String id);

}
