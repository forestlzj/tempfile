package com.cloud.portal.inforelease.message.controller;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.IoUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.inforelease.message.model.MessageBoard;
import com.cloud.portal.inforelease.message.model.MessageBoardPraise;
import com.cloud.portal.inforelease.message.service.MessageBoardService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;

/**
 * @author rush
 * @Date Created in 2020/3/12 15:36
 * Description: 留言板控制层
 * Modified By:
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/message/board/")
public class MessageBoardController {

    /**
     * 留言板接口层
     */
    private final MessageBoardService messageBoardService;

    /**
     * 分页查询 留言信息
     *
     * @param page         分页对象
     * @param messageBoard 留言板实体类
     * @return
     */
    @GetMapping("page")
    @SysLog("留言查询")
    public R getMessageBoardPage(Page page, MessageBoard messageBoard) {
        return R.ok(messageBoardService.getListPage(page, messageBoard));
    }

    /**
     * 通过id查询 留言
     *
     * @param id id
     * @return R
     */
    @GetMapping("get")
    public R getById(@Param("id") String id) {
        return R.ok(messageBoardService.getMessageBoardById(id));
    }

    @PutMapping("/put")
    @SysLog(value = "留言修改", type = CommonConstants.LOG_EDIT)
    public R putPlanLibrary(@RequestBody MessageBoard messageBoard) {
        return new R<>(messageBoardService.updateById(messageBoard));
    }

    @DeleteMapping("/removeById/{id}")
    @SysLog(value = "删除留言", type = CommonConstants.LOG_DELELE)
    public R removeById(@PathVariable String id) {
        //删除主贴

        return new R<>(messageBoardService.removeById(id));
    }

    /**
     * 新增 留言
     *
     * @param messageBoard
     * @return R
     */
    @SysLog(value = "添加留言", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    public R save(@RequestBody MessageBoard messageBoard) {
        return R.ok(messageBoardService.saveMessageBoard(messageBoard));
    }

    /**
     * 置顶、加精、官方
     *
     * @param messageBoard
     * @return
     */
    @PutMapping("/topCreamOfficial")
    @SysLog(value = "留言置顶、加精、官方", type = CommonConstants.LOG_EDIT)
    public R topCreamOfficial(@RequestBody MessageBoard messageBoard) {
        MessageBoard messageB = messageBoardService.getById(messageBoard.getId());
        if (messageBoard.getViewCount() == 1) {
            messageB.setViewCount(messageB.getViewCount() + 1);
        }
        if (StringUtils.isNotEmpty(messageBoard.getPublicTags())) {
            switch (messageBoard.getPublicTags()) {
                case "top":
                    messageB.setIsTop(messageBoard.getIsTop());
                    break;
                case "cream":
                    messageB.setIsCream(messageBoard.getIsCream());
                    break;
                case "official":
                    messageB.setIsOfficial(messageBoard.getIsOfficial());
                    break;
                default:
                    break;
            }
        }


        return new R<>(messageBoardService.updateById(messageB));
    }

    @RequestMapping(value = "uploadPic")
    @ResponseBody
    public R upload(MultipartFile file) throws Exception {
        return messageBoardService.uploadPic(file);
    }


    @RequestMapping(value = "/getPic/{base64Id}")
    @ResponseBody
    public void getIcon(@PathVariable("base64Id") String base64Id, HttpServletResponse response) {
        try {
            if (StringUtils.isNotBlank(base64Id)) {
                String fileName = Base64.decodeStr(base64Id);
                fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
                response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
                IoUtil.copy(messageBoardService.downLoadPic(base64Id), response.getOutputStream());
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @SysLog(value = "留言板点赞", type = CommonConstants.LOG_ADD)
    @PostMapping("savePraise")
    public R savePraise(@RequestBody MessageBoardPraise messageBoardPraise) {
        return R.ok(messageBoardService.savePraise(messageBoardPraise));
    }

    @DeleteMapping("deletePraise/{boardId}")
    @SysLog(value = "留言板取消点赞", type = CommonConstants.LOG_DELELE)
    public R deletePraise(@PathVariable String boardId) {
        return new R<>(messageBoardService.deletePraise(boardId));
    }


}
