package com.cloud.portal.market.catalog.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.admin.api.dto.TreeNode;
import com.cloud.portal.market.catalog.model.Catalog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/10 16:19
 * @description: 目录编排mapper接口
 * @modified By: huangyingx
 */
@Mapper
public interface CatalogMapper extends BaseMapper<Catalog> {

    List<Catalog> findListByType(@Param("type") String type);

    int deleteCatalogById(@Param("id") String id);

    int insertCatalog(Catalog entity);

    int updateCatalog(Catalog entity);

    Catalog findById(@Param("id") String id);

    List<Catalog> existCatalog(Catalog entity);

    int updateSortByList(@Param("nodes") List<TreeNode> nodes);
}
