package com.cloud.portal.data.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.portal.data.mapper.DataResourceCountMapper;
import com.cloud.portal.data.model.DataResourceCount;
import com.cloud.portal.data.service.DataResourceCountService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 * @author yuhaob
 * @date Created in 2020/4/16 11:17
 * @description:
 * @modified By:yuhaob
 */
@Slf4j
@Service
public class DataResourceCountServiceImpl extends ServiceImpl<DataResourceCountMapper, DataResourceCount> implements DataResourceCountService {
    @Override
    public List<Map<String, Object>> getNewMap() {
        return this.baseMapper.getNewMap();
    }

    @Override
    public List<Map<String, Object>> getNewSys() {
        List<Map<String, Object>> newSys = this.baseMapper.getNewSys();
        for (Map<String, Object> map:newSys
             ) {
            long totalLong = Long.parseLong(map.get("total").toString());
            long preTotalLong = Long.parseLong(map.get("preTotal").toString());
            BigDecimal total = BigDecimal.valueOf(totalLong);
            BigDecimal preTotal = BigDecimal.valueOf(preTotalLong);
            String info = "";
            if(total.compareTo(preTotal)==1){
                info =""+(totalLong - preTotalLong) * 1.0 / preTotalLong * 100;
            }else if(total.compareTo(preTotal)==-1){
                info =""+(preTotalLong - totalLong) * 1.0 / preTotalLong * 100;
            }else{
                info ="0.00";
            }
            map.put("proportion", info.substring(0, info.indexOf(".") + 3) + "%");


        }
        return newSys;
    }

    @Override
    public List<Map<String, Object>> getNewCity() {
        return this.baseMapper.getNewCity();
    }

   /* public static void main(String[] args) {
        Long total = Long.parseLong("463464242623");
        Long preTotal = Long.parseLong("463464242623");
        String info = "";
        if(total.longValue()>preTotal.longValue()){
            info =String.valueOf((total - preTotal) * 1.0 / preTotal * 100);
        }else if(total.longValue()<preTotal.longValue()){
            info =String.valueOf((preTotal - total) * 1.0 / preTotal * 100);
        }else{
            info="0.00";
        }
        System.out.println(info.substring(0, info.indexOf(".") + 3) + "%");
    }*/

}
