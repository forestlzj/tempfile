package com.cloud.portal.market.apptoolpower.model;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.portal.market.apptool.model.AppToolTree;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/26 16:57
 * @description:应用工具权限分配
 * @modified By:liuwei
 */
@Data
@TableName("T_PORTAL_APP_TOOL_POWER")
@EqualsAndHashCode(callSuper = true)
public class AppToolPower extends Model<AppToolPower> {
    /**
     * 用户id
     */
    private String userId;
    /**
     * 应用工具id
     */
    private String appToolId;
    /**
     * 排序
     */
    private String sort;
    /**
     * 显示0、隐藏1
     */
    private String showHide;
    /**
     * 收藏0、未收藏1
     */
    private String collector;
    /**
     * 工具tool、应用app
     */
    private String type;
    /**
     * 状态，0-未通过，1-通过
     */
    private String status;
    @TableField(exist = false)
    List<AppToolTree> appToolTreeList;

    @TableField(exist = false)
    List<AppToolPower> appToolPowerList;
}
