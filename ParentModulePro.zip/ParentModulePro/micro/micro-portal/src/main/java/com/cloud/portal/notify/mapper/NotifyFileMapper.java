package com.cloud.portal.notify.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.notify.model.NotifyFile;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author yuhaob
 * @date Created in 2020/3/25 15:06
 * @description:
 * @modified By:yuhaob
 */
@Mapper
public interface NotifyFileMapper extends BaseMapper<NotifyFile> {
    List<NotifyFile> findListById(String id);
}
