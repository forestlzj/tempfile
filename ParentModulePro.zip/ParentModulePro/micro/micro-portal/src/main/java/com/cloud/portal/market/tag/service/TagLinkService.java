package com.cloud.portal.market.tag.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.tag.entity.TagLink;
import feign.Param;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/19 15:01
 * @description:
 * @modified By:maojia
 */
public interface TagLinkService extends IService<TagLink> {

    /**
     *根据appToolId获取列表信息
     * @param appToolId
     * @return
     */
    List<TagLink> findListByAppToolId(String appToolId);

    /**
     * 根据labelId获取列表信息
     * @param labelId
     * @return
     */
    List<TagLink> findListByLabelId(String labelId);

    /**
     * 批量插入数据
     * @param tagList
     * @param appToolId
     * @return
     */
    boolean insertBatchByAppToolId( List<String> tagList,String appToolId);

    /**
     * 根据appToolId删除关联记录
     * @param appToolId
     * @return
     */
    boolean deleteByAppToolId(String appToolId);
}
