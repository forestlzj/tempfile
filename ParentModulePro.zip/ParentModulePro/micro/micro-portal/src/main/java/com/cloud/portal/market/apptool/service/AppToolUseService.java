package com.cloud.portal.market.apptool.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolUse;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/24 9:12
 * @description:
 * @modified By:maojia
 */
public interface AppToolUseService extends IService<AppToolUse> {


    /**
     * 应用工具插入更新操作
     * @param appToolId 应用工具ID
     * @param type 类型
     * @return
     */
    boolean mergeAppToolUse(String appToolId,String type);

    /**
     * 获取最近使用应用工具
     * @param appToolUse
     * @return
     */
    List<AppTool> getUseList(AppToolUse appToolUse);

}
