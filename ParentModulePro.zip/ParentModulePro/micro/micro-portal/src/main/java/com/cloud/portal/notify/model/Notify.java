package com.cloud.portal.notify.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.cloud.admin.api.annotation.LogField;
import com.cloud.admin.api.entity.SysUser;
import com.cloud.portal.market.apptool.model.OptManual;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author yuhaob
 * @date Created in 2020/3/17 9:10
 * @description:
 * @modified By:yuhaob
 */
@Data
@TableName("SYS_OA_NOTIFY")
public class Notify implements Serializable {
    private static final long serialVersionUID = 1L;
    @LogField(title ="主键")
    @TableId(type = IdType.UUID)
    private String id;
    @LogField(title ="标题")
    private String title;
    @LogField(title ="类型")
    private String type;
    @LogField(title ="状态")
    private String status;
    @LogField(title ="内容")
    private String content;
    @LogField(title ="接收单位")
    private String receiveUnits;
    @LogField(title ="附件")
    private String files;
    @LogField(title ="备注")
    private String remark;
    @LogField(title ="创建人")
    private String createBy;
    @LogField(title ="修改人")
    private String updateBy;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date createTime;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date updateTime;
    @LogField(title ="有效性（0正常,1删除）")
    private String delFlag;

    @TableField(exist = false)
    private String isSelf;		// 是否只查询自己的通知
    @TableField(exist = false)
    private List<NotifyRecord> notifyRecordList;
    @TableField(exist = false)
    private SysUser user;       // 警员信息
    @TableField(exist = false)
    private String readNum;		// 已读人数
    @TableField(exist = false)
    private String unReadNum;	// 未读人数
    @TableField(exist = false)
    private String readStatus;  // 阅读人数
    @TableField(exist = false)
    private String receiveUnitsName;  //部门名称

    @TableField(exist = false)
    private List<NotifyFile> notifyFile;

    @TableField(exist = false)
    private String readFlag;   //状态(0-未读，1-已读)

    @TableField(exist = false)
    private String notifyFileStr;
}
