package com.cloud.portal.data.controller;

import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.data.service.DataResourceCountService;
import com.netflix.discovery.converters.Auto;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author yuhaob
 * @date Created in 2020/4/16 11:15
 * @description:
 * @modified By:yuhaob
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/dataResourceCount")
public class DataResourceCountController {

    @Auto
    private DataResourceCountService dataResourceCountService;

    @GetMapping("/getMapData")
    @SysLog(value = "获取地图信息")
    public R getMapData() {
        Map<String, Object> result = new HashMap<String, Object>(3);
        List<Map<String, Object>> list = dataResourceCountService.getNewMap();
        return new R<>(list);
    }

    @GetMapping("/getSysData")
    @SysLog(value = "获取系统上报信息")
    public R getSysData() {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Map<String, Object>> list = dataResourceCountService.getNewSys();
        return new R<>(list);
    }


    @GetMapping("/getCityData")
    @SysLog(value = "获取地市上报信息")
    public R getCityData() {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Map<String, Object>> list = dataResourceCountService.getNewCity();
        return new R<>(list);
    }
}
