package com.cloud.portal.market.apptool.model;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.annotation.*;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.apache.commons.lang.StringUtils;

import java.util.Date;

/**
 * @author wengshij
 * @date Created in 2020/3/25 10:22
 * @description:应用工具
 * @modified By:wengshij
 */
@Data
@TableName("T_PORTAL_APP_TOOL_FLOW")
@EqualsAndHashCode(callSuper = true)
public class AppToolFlow extends Model<AppToolFlow> {

    /**
     * 主键ID
     */
    @TableId(type = IdType.INPUT)
    private String id;
    /**
     * 应用工具ID
     */
    private String appToolId;
    /**
     * 申请操作内容（JSON格式）
     */
    private String applyContent;
    /**
     * 申请人
     */
    private String applicant;
    /**
     * 申请时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date applyTime;
    /**
     * 审批人(默认是管理员)
     */
    private String approver;
    /**
     * 审批时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date approvalTime;
    /**
     * 状态（0-草稿,1-审批中,2-驳回,3-通过）
     */
    private String status;
    /**
     * 审批意见
     */
    private String opinion;
    /**
     * 创建时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * 删除标识
     */
    @TableLogic
    private String delFlag;
    /**
     * 操作类型(0-上架 1-下架 2-更新 3-删除)
     */
    private String optType;
    /**
     * 申请说明
     */
    private String applyExplain;
    /**
     * 申请类型
     * app-应用
     * tool-工具
     */
    private String type;
    /**
     * 审批人姓名
     */
    @TableField(exist = false)
    private String approveName;

    /**
     * 申请人姓名
     */
    @TableField(exist = false)
    private String applicantName;


    @TableField(exist = false)
    private AppTool appTool;

    /**
     * 流程标识
     * 主要标识是否同一个流程信息
     */
    private String flowFlag;

    public AppTool getAppTool() {
        AppTool appTool = new AppTool();
        if (StringUtils.isNotBlank(this.applyContent)) {
            appTool = JSONUtil.toBean(this.applyContent, AppTool.class);
        }
        return appTool;
    }
}
