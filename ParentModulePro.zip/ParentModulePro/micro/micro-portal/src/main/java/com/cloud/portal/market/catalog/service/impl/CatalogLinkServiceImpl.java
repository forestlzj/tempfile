package com.cloud.portal.market.catalog.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.portal.market.catalog.mapper.CatalogLinkMapper;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.catalog.service.CatalogLinkService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author huangyingx
 * @date Created in 2019/8/5 11:21
 * @description: 目录编排管理关联service实现类
 * @modified By: huangyingx
 */
@Service
@AllArgsConstructor
public class CatalogLinkServiceImpl extends ServiceImpl<CatalogLinkMapper, CatalogLink> implements CatalogLinkService {

    @Override
    public boolean insertBatchByOtherId(List<String> catalogList, String otherId) {
        return this.baseMapper.insertBatchByOtherId(catalogList,otherId);
    }

    @Override
    public boolean deleteByOtherId(String otherId) {
        return this.baseMapper.deleteByOtherId(otherId);
    }

    @Override
    public List<CatalogLink> findByOtherId(String otherId) {
        Map<String,Object> params = new HashMap<>();
        params.put("other_id",otherId);
        return (List<CatalogLink>) super.listByMap(params);
    }

    @Override
    public List<CatalogLink> findObjByOtherId(String otherId) {
        return this.baseMapper.findObjByOtherId(otherId);
    }

    @Override
    public List<CatalogLink> findByParentId(String parentId) {
        return this.baseMapper.findListByParentId(parentId);
    }


}
