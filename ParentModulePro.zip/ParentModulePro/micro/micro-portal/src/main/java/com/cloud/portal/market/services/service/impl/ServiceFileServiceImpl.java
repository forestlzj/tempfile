package com.cloud.portal.market.services.service.impl;

import cn.hutool.core.codec.Base64;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.services.entity.ServiceFile;
import com.cloud.portal.market.services.mapper.ServiceFileMapper;
import com.cloud.portal.market.services.service.ServiceFileService;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.List;

/**
 * @author chenchunl
 * @date Created in 2020/4/9 14:33
 * @description:
 * @modified By:chenchunl
 */
@Service
public class ServiceFileServiceImpl  extends ServiceImpl<ServiceFileMapper, ServiceFile> implements ServiceFileService {

    /**
     * minio 连接信息
     */
    @Autowired
    private MinioTemplate minioTemplate;

    @Override
    public List<ServiceFile> findServiceFileByServiceId(String id) {
        return this.baseMapper.findServiceFileByServiceId(id);
    }

    @Override
    public boolean delFileByServiceId(String serviceId) {
        return this.baseMapper.delFileByServiceId(serviceId);
    }

    @Override
    public InputStream downLoadServiceFile(ServiceFile serviceFile) {

        InputStream inputStream = minioTemplate.getObject(PortalConstants.MINIO_MARKET_BUCKET,  Base64.decodeStr(serviceFile.getFiles()));
        if(StringUtils.isNotBlank(serviceFile.getId())){
            serviceFile.setDownloadNum(serviceFile.getDownloadNum() + 1);
            this.baseMapper.updateDownloadNumById(serviceFile);
        }
        return inputStream;
    }

}
