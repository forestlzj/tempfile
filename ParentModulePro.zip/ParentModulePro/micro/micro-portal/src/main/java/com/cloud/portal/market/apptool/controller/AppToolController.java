package com.cloud.portal.market.apptool.controller;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.IoUtil;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.service.AppToolService;
import com.cloud.portal.market.common.constant.MarketConstants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author wengshij
 * @date Created in 2020/3/11 9:08
 * @description:应用和工具信息控制层
 * @modified By:wengshij
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/app/tool/")
public class AppToolController {
    /**
     * 应用工具接口层
     */
    private final AppToolService appToolService;


    /**
     * 分页查询 应用工具信息
     *
     * @param page    分页对象
     * @param appTool 应用工具实体类
     * @return
     */
    @GetMapping("page")
    @SysLog(value = "[应用/工具]查询")
    public R getAppToolPage(Page page, AppTool appTool) {
        return R.ok(appToolService.getListPage(page, appTool));
    }


    /**
     * 门户应用工具查询、仅限于个人
     *
     * @param page
     * @param appTool
     * @return
     */
    @GetMapping("findAppToolPage")
    @SysLog(value = "门户[应用/工具]查询")
    public R findAppToolPage(Page page, AppTool appTool) {
        return R.ok(appToolService.findAppToolPage(page, appTool));
    }


    @GetMapping("getAll/{id}")
    public R getAll(@PathVariable("id") String id) {
        return R.ok(appToolService.getAll(id));
    }

    /**
     * 通过id查询 应用工具
     *
     * @param id id
     * @return R
     */
    @GetMapping("get/{id}")
    @Cacheable(value = MarketConstants.APP_TOOL_CACHE_NAME, key = "'simple_'.concat(#id)")
    public R getById(@PathVariable("id") String id) {
        return R.ok(appToolService.getById(id));
    }

    /**
     * 新增 应用工具
     *
     * @param appTool
     * @return R
     */
    @SysLog(value = "[应用/工具]新增", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    @PreAuthorize("@pms.hasPermission('app_tool_add')")
    public R save(@RequestBody AppTool appTool) {
        return R.ok(appToolService.saveAppTool(appTool));
    }

    /**
     * 修改 应用工具
     *
     * @param appTool
     * @return R
     */
    @SysLog(value = "[应用/工具]修改", type = CommonConstants.LOG_EDIT)
    @PostMapping("update")
    @PreAuthorize("@pms.hasPermission('app_tool_edit')")
    public R updateById(@RequestBody AppTool appTool) {

        return R.ok(appToolService.updateAppTool(appTool));
    }

    /**
     * 通过id删除 应用工具
     *
     * @param id 主键ID
     * @return R
     */
    @SysLog(value = "[应用/工具]删除", type = CommonConstants.LOG_DELELE)
    @DeleteMapping("delete/{id}")
    @PreAuthorize("@pms.hasPermission('app_tool_del')")
    @CacheEvict(value = MarketConstants.APP_TOOL_CACHE_NAME, allEntries = true)
    public R removeById(@PathVariable String id) {
        return R.ok(appToolService.removeById(id));
    }

    @RequestMapping(value = "uploadIcon")
    @ResponseBody
    public R upload(MultipartFile file) throws Exception {
        return appToolService.uploadIcon(file);
    }


    @RequestMapping(value = "/getIcon/{base64Id}")
    @ResponseBody
    public void getIcon(@PathVariable("base64Id") String base64Id, HttpServletResponse response) {
        try {
            if (StringUtils.isNotBlank(base64Id)) {
                String fileName = Base64.decodeStr(base64Id);
                fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
                response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
                IoUtil.copy(appToolService.downLoadIcon(base64Id), response.getOutputStream());
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @DeleteMapping("deleteIcon/{base64Id}")
    public R deleteIcon(@PathVariable String base64Id) {
        return appToolService.deleteIcon(base64Id);
    }

    @GetMapping("/list/ids/{ids}")
    @SysLog(value = "根据id集合获取信息", type = CommonConstants.LOG_ADD)
    public R findListByIds(@PathVariable String ids) {
        List<AppTool> result = new ArrayList<>();
        String[] arr = ids.split(",");
        for (int i = 0; i < arr.length; i++) {
            result.add(appToolService.getById(arr[i]));
        }
        return new R<>(result);
    }

    @GetMapping("list")
    @SysLog(value = "获取列表信息(不分页)")
    public R findList(AppTool appTool) {
        return new R<>(appToolService.getListPage(appTool));
    }

    @GetMapping("no_authorize/list")
    @SysLog(value = "获取没有使用权限的信息列表")
    public R findNoAuthorizeList(AppTool appTool) {
        return new R<>(appToolService.getNoAuthorizeList(appTool));
    }

    @GetMapping("getAppToolTree")
    @SysLog(value = "[应用/工具]树形查询")
    public R getAppToolTree(AppTool appTool) {
        if (null == appTool) {
            appTool = new AppTool();
        }
        //利用权限标识暂时保存缓存key值
        appTool.setPermission(MarketConstants.APP_TOOL_CACHE_KEY_TREE_NAME);
        return R.ok(appToolService.getAppToolTree(appTool));
    }

    @GetMapping("findAllToolPage")
    @SysLog(value = "工具查询")
    public R findAllToolPage(Page page, AppTool appTool) {
        return R.ok(appToolService.findAllToolPage(page, appTool));
    }


    @GetMapping("findTopToolList")
    @SysLog(value = "工具TOP10查询")
    public R findTopToolList(AppTool appTool) {
        return R.ok(appToolService.findTopToolList(appTool));
    }


    @PutMapping("countUpViewNum/{appToolId}/{type}")
    @SysLog(value = "应用工具计数", type = CommonConstants.LOG_EDIT)
    public R countUpViewNum(@PathVariable String appToolId,@PathVariable String type) {
        return R.ok(appToolService.countUpViewNum(appToolId,type));
    }

    @GetMapping("findAllAppPage")
    @SysLog(value = "应用查询")
    public R findAllAppPage(Page page, AppTool appTool) {
        return R.ok(appToolService.findAllAppPage(page, appTool));
    }


    @GetMapping("totalIsApplyApp")
    @SysLog(value = "统计可申请应用")
    public R totalIsApplyApp(Page page, AppTool appTool) {
        return R.ok(appToolService.totalIsApplyApp(appTool));
    }


    @GetMapping("auth/findAppToolKind")
    public R findAppToolKind(Page page, AppTool appTool) {
        return R.ok(appToolService.findAppToolKind(page, appTool));
    }

    /**
     * 应用工具统计
     *
     * @return
     */
    @GetMapping("auth/getAppToolCount")
    public R getAppToolCount() {
        return R.ok(appToolService.getAppToolCount());
    }

    @GetMapping("person/getAppToolList")
    @SysLog(value = "个人工作台 获取当前用户所有应用、工具")
    public R getAppToolList(AppTool appTool) {
        MicroUser user = SecurityUtils.getUser();
        appTool.setUserId(user.getId());
        if(StringUtils.isNotBlank(appTool.getName())){
            List<AppTool> appToolList = appToolService.getUserAppToolList(appTool);
            appToolList = appToolList.stream().filter(appTool1 ->
                    appTool1.getName().contains(appTool.getName())
            ).collect(Collectors.toList());
            return R.ok(appToolList);
        }else{
            return R.ok(appToolService.getUserAppToolList(appTool));
        }

    }

    @GetMapping("list/opt")
    @SysLog(value = "获取有权限并存在操作手册的应用工具列表")
    public R findHasOptManualAuthorizeList(@RequestParam(value = "name",required = false) String name,
                                           @RequestParam(value="bussType") String bussType){
        return R.ok(appToolService.findHasOptManualAuthorizeList(name,bussType));
    }

}

