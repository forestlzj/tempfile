package com.cloud.portal.market.tag.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.portal.market.tag.entity.TagLink;
import com.cloud.portal.market.tag.mapper.TagLinkMapper;
import com.cloud.portal.market.tag.service.TagLinkService;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/19 15:02
 * @description:
 * @modified By:maojia
 */
@Service
public class TagLinkServiceImpl extends ServiceImpl<TagLinkMapper, TagLink> implements TagLinkService {

    @Override
    public List<TagLink> findListByAppToolId(String appToolId) {
        return this.baseMapper.findListByAppToolId(appToolId);
    }

    @Override
    public boolean insertBatchByAppToolId(List<String> tagList, String appToolId) {
        return this.baseMapper.insertBatchByAppToolId(tagList,appToolId);
    }

    @Override
    public boolean deleteByAppToolId(String appToolId) {
        return this.baseMapper.deleteByAppToolId(appToolId);
    }

    @Override
    public List<TagLink> findListByLabelId(String labelId) {
        return this.baseMapper.findListByLabelId(labelId);
    }
}
