package com.cloud.portal.market.apptool.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.admin.api.entity.SysUser;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.apptool.mapper.AppToolMapper;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolFlow;
import com.cloud.portal.market.apptool.model.AppToolTree;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.apptool.service.AppToolService;
import com.cloud.portal.market.apptool.service.AppToolUseService;
import com.cloud.portal.market.apptool.service.OptManualService;
import com.cloud.portal.market.apptoolpower.model.AppToolPower;
import com.cloud.portal.market.apptoolpower.service.AppToolPowerService;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.catalog.service.CatalogLinkService;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.common.util.AppToolUtil;
import com.cloud.portal.market.tag.entity.TagLink;
import com.cloud.portal.market.tag.service.TagLinkService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author wengshij
 * @date Created in 2020/3/11 10:07
 * @description: 应用工具接口实现层
 * @modified By:wengshij
 */
@Service
@AllArgsConstructor
public class AppToolServiceImpl extends ServiceImpl<AppToolMapper, AppTool> implements AppToolService {

    /**
     * minio 接口服务信息
     */
    @Autowired
    private MinioTemplate minioTemplate;
    /**
     * 操作文档 接口
     */
    @Autowired
    private OptManualService optManualService;
    /**
     * 类目关联信息
     */
    @Autowired
    private CatalogLinkService catalogLinkService;
    /**
     *
     */
    @Autowired
    private TagLinkService tagLinkService;
    @Autowired
    private AppToolUseService appToolUseService;
    @Autowired
    private AppToolPowerService appToolPowerService;


    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.APP_TOOL_CACHE_NAME, allEntries = true)
    public boolean saveAppTool(AppTool appTool) {
        appTool = AppToolUtil.initAppToolParams(appTool);
        optManualService.saveBatch(appTool.getOptManualList());
        catalogLinkService.saveBatch(appTool.getCatalogLinkList());
        tagLinkService.saveBatch(appTool.getTagLinkList());
        //授权给上架申请人，管理员不用授权
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        String userId = sysUser.getUserId();
        if(!"1".equals(userId)){
            savePower(userId,appTool);
        }
        return SqlHelper.delBool(this.baseMapper.insert(appTool));

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.APP_TOOL_CACHE_NAME, allEntries = true)
    public boolean updateAppTool(AppTool appTool) {
        appTool = updateInit(appTool);
        optManualService.saveBatch(appTool.getOptManualList());
        return SqlHelper.delBool(this.baseMapper.updateById(appTool));
    }

    private AppTool updateInit(AppTool appTool) {
        //获取旧的应用工具信息
        AppTool oldAppTool = this.getAll(appTool.getId());
        //判断两个图标是否相同
        if (StringUtils.isNotBlank(oldAppTool.getIcon()) && StringUtils.isNotBlank(appTool.getIcon()) && !oldAppTool.getIcon().equals(appTool.getIcon())) {
            this.deleteIcon(oldAppTool.getIcon());
        }
        //判断编目信息是否更改
        String oldCatalogId = oldAppTool.getCatalogId();
        String[] oldCatalogIdArray = new String[0];
        if (StringUtils.isNotBlank(oldCatalogId)) {
            oldCatalogIdArray = StringUtils.split(oldCatalogId, ",");
            Arrays.sort(oldCatalogIdArray);
        }
        String newCatalogId = appTool.getCatalogId();
        String[] newCatalogIdArray = new String[0];
        if (StringUtils.isNotBlank(newCatalogId)) {
            newCatalogIdArray = StringUtils.split(newCatalogId, ",");
            Arrays.sort(newCatalogIdArray);
        }
        if (!Arrays.equals(oldCatalogIdArray, newCatalogIdArray)) {
            //如果不相等 则需要更新编目(先删除 插入)
            catalogLinkService.deleteByOtherId(appTool.getId());
            List<CatalogLink> catalogLinkList = Arrays.stream(newCatalogIdArray).map(catalogId -> {
                CatalogLink catalogLink = new CatalogLink();
                catalogLink.setOtherId(appTool.getId());
                catalogLink.setCatalogId(catalogId);
                return catalogLink;
            }).collect(Collectors.toList());
            if (CollectionUtil.isNotEmpty(catalogLinkList)) {
                catalogLinkService.saveBatch(catalogLinkList);
            }
        }
        //判断标签信息是否做了更改
        List<String> newTagLabel = appTool.getLabelId();
        String[] newTagLabelArray = new String[0];
        if (CollectionUtil.isNotEmpty(newTagLabel)) {
            newTagLabelArray = newTagLabel.toArray(new String[newTagLabel.size()]);
            Arrays.sort(newTagLabelArray);
        }
        List<String> oldTagLabel = oldAppTool.getLabelId();
        String[] oldTagLabelArray = new String[0];
        if (CollectionUtil.isNotEmpty(oldTagLabel)) {

            oldTagLabelArray = oldTagLabel.toArray(new String[oldTagLabel.size()]);
            Arrays.sort(oldTagLabelArray);
        }
        if (!Arrays.equals(oldTagLabelArray, newTagLabelArray)) {
            //标签不等
            tagLinkService.removeByMap(new HashMap<String, Object>(1) {{
                put("APP_TOOL_ID", appTool.getId());
            }});
            tagLinkService.saveBatch(appTool.getLabelId().stream().map(label -> {
                TagLink tagLink = new TagLink();
                tagLink.setAppToolId(appTool.getId());
                tagLink.setLabelId(label);
                return tagLink;
            }).collect(Collectors.toList()));

        }


        //判断操作手册是否做了修改 如果修改了就删除对应的列表信息
        OptManual searchOptManual = new OptManual();
        searchOptManual.setAppToolId(appTool.getId());
        List<OptManual> oldOptManualList = optManualService.findList(searchOptManual);
        List<OptManual> newOptManualList = appTool.getOptManualList();
        if (CollectionUtil.isNotEmpty(oldOptManualList)) {
            if (CollectionUtil.isNotEmpty(newOptManualList)) {
                Map<String, OptManual> transMap = new HashMap<>(16);
                oldOptManualList.stream().forEach(oldOptManual ->
                        transMap.put(oldOptManual.getFiles(), oldOptManual)
                );
                newOptManualList.stream().forEach(newOptManual -> {
                            OptManual optManual = transMap.get(newOptManual.getFiles());
                            if (null != optManual) {
                                transMap.remove(newOptManual.getFiles());
                            } else {
                                newOptManual.setId(null);
                                transMap.put(newOptManual.getFiles(), newOptManual);
                            }
                        }
                );
                List<OptManual> tempOptManualList = new ArrayList<>();
                if (CollectionUtil.isNotEmpty(transMap)) {
                    transMap.forEach((key, opt) -> {
                        if (StringUtils.isNotBlank(opt.getId())) {
                            optManualService.removeById(opt.getId());
                            optManualService.deleteManual(opt);
                        } else {
                            tempOptManualList.add(opt);
                        }
                    });
                }
                appTool.setOptManualList(tempOptManualList);
            } else {
                optManualService.removeByMap(new HashMap<String, Object>(1) {{
                    put("APP_TOOL_ID", appTool.getId());
                }});
                OptManual optManual = new OptManual();
                optManual.setFiles(StringUtils.join(oldOptManualList.stream().map(OptManual::getFiles).collect(Collectors.toList()), ","));
                optManualService.deleteManual(optManual);
            }
        }
        MicroUser microUser = SecurityUtils.getUser();
        appTool.setUpdateTime(new Date(System.currentTimeMillis()));
        appTool.setUpdateBy(microUser.getId());
        appTool.setOptManualList(AppToolUtil.initOptAppToolManual(appTool));
        appTool.setDelFlag(CommonConstants.STATUS_NORMAL);
        return appTool;

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.APP_TOOL_CACHE_NAME, allEntries = true)
    public R deleteAppTool(String id) {
        AppTool appTool = this.baseMapper.selectById(id);

        //首先查询出该主题的所有操作手册
        List<OptManual> optManualList = optManualService.list(Wrappers.query(new OptManual()).eq(OptManual::getAppToolId, id));
        if (CollectionUtil.isNotEmpty(optManualList)) {
            optManualList.stream().forEach(optManual ->
                    //删除minio 中的文件
                    optManualService.deleteManual(optManual)
            );
        }
        //删除 图标
        this.deleteIcon(appTool.getIcon());
        //删除操作手册信息
        optManualService.remove(Wrappers.query(new OptManual()).eq(OptManual::getAppToolId, id));
        //todo 删除 目录编排 删除标签信息

        return R.ok(SqlHelper.delBool(this.baseMapper.deleteById(id)));
    }

    @Override
    public R uploadIcon(MultipartFile file) throws Exception {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        Map<String, String> result = new HashMap<>(2);
        StringBuffer nameBuffer = new StringBuffer();
        String fileName = file.getOriginalFilename();
        String newFileName = IdUtil.randomUUID() + fileName.substring(fileName.lastIndexOf("."));
        nameBuffer.append("icon").append("/")
                .append(SecurityUtils.getUser().getId()).append("/")
                .append(sdf.format(System.currentTimeMillis())).append("/")
                .append(newFileName);
        minioTemplate.createBucket(PortalConstants.MINIO_MARKET_BUCKET);
        minioTemplate.putObject(PortalConstants.MINIO_MARKET_BUCKET, nameBuffer.toString(), file.getInputStream());
        String baseId = Base64.encode(nameBuffer.toString());
        result.put("name", fileName);
        result.put("baseId", baseId);
        result.put("url", "portal/app/tool/getIcon/" + baseId);
        return R.ok(result);
    }

    @Override
    public R deleteIcon(String base64Id) {
        try {
            minioTemplate.removeObject(PortalConstants.MINIO_MARKET_BUCKET, Base64.decodeStr(base64Id));
        } catch (Exception e) {
            e.printStackTrace();
            return R.failed();
        }
        return R.ok();
    }

    @Override
    public InputStream downLoadIcon(String base64Id) {
        String fileName = Base64.decodeStr(base64Id);
        InputStream inputStream = minioTemplate.getObject(PortalConstants.MINIO_MARKET_BUCKET, fileName);
        return inputStream;
    }

    @Override
    public IPage<AppTool> getListPage(IPage<AppTool> page, AppTool appTool) {
        return this.baseMapper.getListPage(page, appTool);
    }

    @Override
    public IPage<AppTool> findAppToolPage(IPage<AppTool> page, AppTool appTool) {
        MicroUser microUser = SecurityUtils.getUser();
        if (!microUser.isAdmin()) {
            appTool.setUserId(SecurityUtils.getUser().getId());
        }
        return this.baseMapper.getListPage(page, appTool);
    }

    @Override
    @Cacheable(value = MarketConstants.APP_TOOL_CACHE_NAME, key = "'complex_'.concat(#appId)")
    public AppTool getAll(String appId) {
        AppTool appTool = this.baseMapper.getAll(appId);
        List<CatalogLink> catalogLinkList = appTool.getCatalogLinkList();
        if (CollectionUtil.isNotEmpty(catalogLinkList)) {
            appTool.setCatalogId(StringUtils.join(catalogLinkList.stream().map(CatalogLink::getCatalogId).collect(Collectors.toList()), ","));
        }
        List<TagLink> tagLinkList = appTool.getTagLinkList();
        if (CollectionUtil.isNotEmpty(tagLinkList)) {
            appTool.setLabelId(tagLinkList.stream().map(TagLink::getLabelId).collect(Collectors.toList()));
        }
        return appTool;
    }

    @Override
    public List<AppTool> getListPage(AppTool appTool) {
        return this.baseMapper.getListPage(appTool);
    }

    @Override
    public List<AppTool> getNoAuthorizeList(AppTool appTool) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        appTool.setUserId(sysUser.getUserId());
        return this.baseMapper.getNoAuthorizeList(appTool);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.APP_TOOL_CACHE_NAME, allEntries = true)
    public R approvalSave(AppTool appTool) {
        optManualService.saveBatch(appTool.getOptManualList());
        catalogLinkService.saveBatch(appTool.getCatalogLinkList());
        tagLinkService.saveBatch(appTool.getTagLinkList());
        //授权给上架申请人，管理员不用授权
        String userId = appTool.getCreateBy();
        if(!"1".equals(userId)){
            savePower(userId,appTool);
        }
        return R.ok(SqlHelper.delBool(this.baseMapper.insert(appTool)));

    }

    @Override
    @Cacheable(value = MarketConstants.APP_TOOL_CACHE_NAME, key = "#appTool.permission")
    public List<AppToolTree> getAppToolTree(AppTool appTool) {
        List<AppToolTree> result = new ArrayList<>(2);
        Map<String, Object> map = new HashMap<>(1);
        map.put("DEL_FLAG", CommonConstants.STATUS_NORMAL);
        List<AppTool> appToolList = this.baseMapper.selectByMap(map);
        AppToolTree appTree = new AppToolTree();
        appTree.setLabel("应用");
        appTree.setValue(MarketConstants.APP_TYPE);
        appTree.setType(MarketConstants.APP_TYPE);
        appTree.setId(MarketConstants.APP_TYPE);
        appTree.setParentId("0");
        AppToolTree toolTree = new AppToolTree();
        toolTree.setLabel("工具");
        toolTree.setValue(MarketConstants.TOOL_TYPE);
        toolTree.setType(MarketConstants.TOOL_TYPE);
        toolTree.setId(MarketConstants.TOOL_TYPE);
        toolTree.setParentId("0");
        appToolList.stream().forEach(obj -> {
            AppToolTree appToolTree = new AppToolTree();
            appToolTree.setId(obj.getId());
            appToolTree.setType(obj.getBussType());
            appToolTree.setValue(obj.getId());
            appToolTree.setLabel(obj.getName());
            if (MarketConstants.APP_TYPE.equals(obj.getBussType())) {
                appToolTree.setParentId(MarketConstants.APP_TYPE);
                appTree.add(appToolTree);
            }
            if (MarketConstants.TOOL_TYPE.equals(obj.getBussType())) {
                appToolTree.setParentId(MarketConstants.TOOL_TYPE);
                toolTree.add(appToolTree);
            }
        });
        result.add(appTree);
        result.add(toolTree);
        return result;
    }

    @Override
    public IPage<AppTool> findAllToolPage(IPage<AppTool> page, AppTool appTool) {

        MicroUser microUser = SecurityUtils.getUser();
        if (!microUser.isAdmin()) {
            appTool.setUserId(microUser.getId());
        }
        return this.baseMapper.findAllToolPage(page, appTool);
    }

    @Override
    public List<AppTool> findTopToolList(AppTool appTool) {
        MicroUser microUser = SecurityUtils.getUser();
        if (!microUser.isAdmin()) {
            appTool.setUserId(microUser.getId());
        }
        return this.baseMapper.findTopToolList(appTool);
    }

    @Override
    public boolean countUpViewNum(String appToolId, String type) {
        if (StringUtils.isBlank(appToolId)) {
            return Boolean.FALSE;
        }
        appToolUseService.mergeAppToolUse(appToolId, type);
        return SqlHelper.delBool(this.baseMapper.countUpViewNum(appToolId));
    }

    @Override
    public IPage<AppTool> findAllAppPage(IPage<AppTool> page, AppTool appTool) {
        MicroUser microUser = SecurityUtils.getUser();
        if (!microUser.isAdmin()) {
            appTool.setUserId(microUser.getId());
        }
        return this.baseMapper.findAllAppPage(page, appTool);
    }

    @Override
    public int totalIsApplyApp(AppTool appTool) {
        MicroUser microUser = SecurityUtils.getUser();
        if (!microUser.isAdmin()) {
            appTool.setUserId(microUser.getId());
            return this.baseMapper.totalIsApplyApp(appTool);
        } else {
            return 0;
        }
    }

    @Override
    public IPage<AppTool> findAppToolKind(IPage<AppTool> page, AppTool appTool) {
        MicroUser microUser = SecurityUtils.getUser();
        if (null != microUser && !microUser.isAdmin()) {
            appTool.setUserId(microUser.getId());
        }
        return this.baseMapper.findAppToolKind(page, appTool);
    }

    @Override
    public Map getAppToolCount() {
        Map result = new HashMap(2);
        result.put(MarketConstants.APP_TYPE, 0);
        result.put(MarketConstants.TOOL_TYPE, 0);
        List<Map> mapList = this.baseMapper.getAppToolCount();
        if (CollectionUtil.isNotEmpty(mapList)) {
            mapList.stream().forEach(obj -> {
                Object key = obj.get("bussType");
                Object value = obj.get("total");
                if (null != key && MarketConstants.APP_TYPE.equals(key.toString())) {
                    result.put(MarketConstants.APP_TYPE, value == null ? 0 : value);
                } else if (null != key && MarketConstants.TOOL_TYPE.equals(key.toString())) {
                    result.put(MarketConstants.TOOL_TYPE, value == null ? 0 : value);
                }
            });
        }
        return result;
    }

    /**
     * 个人工作台 获取当前用户所有应用、工具
     *
     * @param appTool
     * @return
     */
    @Override
    @Cacheable(value = MarketConstants.APP_TOOL_CACHE_NAME, key = "'personAppTool_'+#appTool.userId+'_'+#appTool.bussType+'_'+#appTool.showHide")
    public List<AppTool> getUserAppToolList(AppTool appTool) {
        List<AppTool> appToolList;
        MicroUser user = SecurityUtils.getUser();
        if (StringUtils.isNotBlank(appTool.getUserId()) && !user.isAdmin()) {
            appToolList = baseMapper.getUserAppToolList(appTool);
        } else {
            AppTool temp = new AppTool();
            temp.setBussType(appTool.getBussType());
            temp.setStatus("0");
            appToolList = baseMapper.getListPage(temp);
        }
        return appToolList;
    }

    @Override
    public List<AppTool> findHasOptManualAuthorizeList(String name, String bussType) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        return this.baseMapper.findHasOptManualAuthorizeList(name, bussType, (!sysUser.isAdmin() ? sysUser.getUserId() : null));
    }

    private void savePower(String userId,AppTool appTool){
        AppToolPower appToolPower = new AppToolPower();
        appToolPower.setAppToolId(appTool.getId());
        appToolPower.setUserId(userId);
        appToolPower.setType(appTool.getBussType());
        appToolPowerService.saveAppToolPower(appToolPower);
    }
}
