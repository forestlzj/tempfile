package com.cloud.portal.market.apptool.service.impl;

import cn.hutool.core.util.IdUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.security.component.PermissionService;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.util.DateUtil;
import com.cloud.portal.market.apptool.mapper.AppToolFlowMapper;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolFlow;
import com.cloud.portal.market.apptool.model.AppToolFlowStep;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.apptool.service.AppToolFlowService;
import com.cloud.portal.market.apptool.service.AppToolService;
import com.cloud.portal.market.apptool.service.OptManualService;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.common.util.AppToolUtil;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author wengshij
 * @date Created in 2020/3/25 10:22
 * @description:应用工具上线审批流程信息
 * @modified By:wengshij
 */
@Service
public class AppToolFlowServiceImpl extends ServiceImpl<AppToolFlowMapper, AppToolFlow> implements AppToolFlowService {

    @Autowired
    private AppToolService appToolService;
    @Autowired
    private OptManualService optManualService;

    /**
     * 权限控制接口
     */
    @Autowired
    private PermissionService pms;

    @Override
    public IPage<AppToolFlow> getAppToolFlowPage(IPage<AppToolFlow> page, AppToolFlow appToolFlow) {
        boolean hasPower = pms.hasPermission(MarketConstants.APP_TOOL_FLOW_LIST_POWER);
        MicroUser microUser = SecurityUtils.getUser();
        if (!hasPower) {
            if (!microUser.isAdmin()) {
                appToolFlow.setCreateBy(microUser.getId());
            }
        }
        return this.baseMapper.getAppToolFlowPage(page, appToolFlow);
    }

    /**
     * 审批操作
     *
     * @param appToolFlow
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean approval(AppToolFlow appToolFlow) {
        AppToolFlow flow = this.baseMapper.selectById(appToolFlow.getId());
        if (null == flow) {
            throw new RuntimeException("信息丢失");
        }
        if (!MarketConstants.APPLY_STATUS_APPROVAL.equals(flow.getStatus())) {
            throw new RuntimeException("该信息已被处理、请刷新后重试");
        }
        String optType = flow.getOptType();
        MicroUser microUser = SecurityUtils.getUser();
        appToolFlow.setUpdateBy(microUser.getId());
        appToolFlow.setApprover(microUser.getId());
        appToolFlow.setUpdateTime(new Date(System.currentTimeMillis()));
        appToolFlow.setApprovalTime(new Date(System.currentTimeMillis()));
        appToolFlow.setApplyContent(flow.getApplyContent());
        if (MarketConstants.APPLY_STATUS_PASS.equals(appToolFlow.getStatus())) {
            switch (optType) {
                case MarketConstants.APPLY_OPT_TYPE_UPPER_SHELF:
                    appToolService.approvalSave(flow.getAppTool());
                    break;
                case MarketConstants.APPLY_OPT_TYPE_LOWER_SHELF:
                    AppTool appTool = new AppTool();
                    appTool.setStatus(MarketConstants.APP_TOOL_STATUS_DOWN);
                    appTool.setId(flow.getAppToolId());
                    appTool.setUpdateTime(new Date(System.currentTimeMillis()));
                    appTool.setUpdateBy(microUser.getId());
                    AppTool temp = flow.getAppTool();
                    temp.setStatus(MarketConstants.APP_TOOL_STATUS_DOWN);
                    appToolFlow.setApplyContent(JSONUtil.toJsonStr(temp));
                    appToolService.updateById(appTool);
                    break;
                case MarketConstants.APPLY_OPT_TYPE_UPDATE:
                    appToolService.updateAppTool(flow.getAppTool());
                    break;
                default:
                    throw new RuntimeException("处理信息异常、请刷新后重试吧");

            }
        }


        return SqlHelper.delBool(baseMapper.approval(appToolFlow));
    }

    /**
     * 申请操作（修改、提交）
     * 驳回状态转草稿或者提交
     * 直接存草稿
     * 直接提交
     *
     * @param appTool
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public R applyOperation(AppTool appTool) {

        appTool = AppToolUtil.initAppToolParams(appTool);
        MicroUser microUser = SecurityUtils.getUser();
        if (StringUtils.isBlank(appTool.getAppToolFlowId())) {

            int flag = baseMapper.getExitByAppToolId(appTool.getId(), "");
            if (flag > 0) {
                throw new RuntimeException("该记录[" + appTool.getName() + "]" + "不可重复申请...");
            }
            appTool.setStatus(MarketConstants.APP_TOOL_STATUS_UP);
            AppToolFlow appToolFlow = new AppToolFlow();
            appToolFlow = initFlowData(appToolFlow, appTool);
            return R.ok(this.baseMapper.insert(appToolFlow));
        } else {
            AppToolFlow appToolFlow = this.baseMapper.selectById(appTool.getAppToolFlowId());
            if (null == appToolFlow) {
                throw new RuntimeException("数据丢失、请刷新后重新");
            }
            if (!MarketConstants.APPLY_STATUS_DRAFT.equals(appToolFlow.getStatus()) && !MarketConstants.APPLY_STATUS_REJECT.equals(appToolFlow.getStatus())) {
                throw new RuntimeException("该记录已被处理、请刷新后重试");
            }
            appToolFlow.setOptType(appToolFlow.getOptType());
            appToolFlow.setUpdateBy(microUser.getId());
            appToolFlow.setUpdateTime(new Date(System.currentTimeMillis()));
            appToolFlow.setApplyExplain(appTool.getApplyExplain());
            appToolFlow.setApplyContent(JSONUtil.toJsonStr(appTool));
            //如果是驳回状态、需要将原纪录删除、然后再插入一条数据
            if (MarketConstants.APPLY_STATUS_REJECT.equals(appToolFlow.getStatus())) {
                this.baseMapper.deleteById(appTool.getAppToolFlowId());
                appToolFlow.setStatus(appTool.getFlowStatus());
                appToolFlow.setId(IdUtil.randomUUID());
                appToolFlow.setApprovalTime(null);
                appToolFlow.setApprover(null);
                appToolFlow.setOpinion(null);
                return R.ok(this.baseMapper.insert(appToolFlow));
            } else {
                appToolFlow.setStatus(appTool.getFlowStatus());
                return R.ok(this.baseMapper.updateById(appToolFlow));
            }
        }


    }

    private AppToolFlow initFlowData(AppToolFlow appToolFlow, AppTool appTool) {
        if (null == appToolFlow) {
            appToolFlow = new AppToolFlow();
        }
        MicroUser microUser = SecurityUtils.getUser();
        appToolFlow.setDelFlag(CommonConstants.STATUS_NORMAL);
        appToolFlow.setAppToolId(appTool.getId());
        appToolFlow.setId(IdUtil.randomUUID());
        appToolFlow.setApplyContent(JSONUtil.toJsonStr(appTool));
        appToolFlow.setApplyTime(new Date(System.currentTimeMillis()));
        appToolFlow.setApplicant(microUser.getId());
        appToolFlow.setApplyTime(new Date(System.currentTimeMillis()));
        appToolFlow.setType(appTool.getBussType());
        appToolFlow.setCreateTime(new Date(System.currentTimeMillis()));
        appToolFlow.setUpdateTime(appToolFlow.getCreateTime());
        appToolFlow.setCreateBy(microUser.getId());
        appToolFlow.setUpdateBy(microUser.getId());
        appToolFlow.setApplyExplain(appTool.getApplyExplain());
        appToolFlow.setStatus(appTool.getFlowStatus());
        appToolFlow.setOptType(appTool.getOptType());
        appToolFlow.setFlowFlag(IdUtil.randomUUID());
        return appToolFlow;
    }


    @Override
    public R downApproval(AppToolFlow appToolFlow) {
        if (StringUtils.isBlank(appToolFlow.getAppToolId())) {
            throw new RuntimeException("数据丢失、请刷新后重试吧...");
        }


        AppTool appTool = appToolService.getAll(appToolFlow.getAppToolId());

        if (appTool == null) {
            throw new RuntimeException("数据丢失、请刷新后重试吧...");
        }
        if (!MarketConstants.APP_TOOL_STATUS_UP.equals(appTool.getStatus())) {
            throw new RuntimeException("该记录不在上架状态、不需要申请操作...");
        }
        int flag = baseMapper.getExitByAppToolId(appToolFlow.getAppToolId(), "");
        if (flag > 0) {
            throw new RuntimeException("该记录[" + appTool.getName() + "]" + "不可重复申请...");
        }
        OptManual optManual = new OptManual();
        optManual.setAppToolId(appToolFlow.getAppToolId());
        appTool.setOptManualList(optManualService.findList(optManual));
        AppToolFlow tempAppToolFlow = new AppToolFlow();
        tempAppToolFlow = initFlowData(tempAppToolFlow, appTool);
        tempAppToolFlow.setOptType(MarketConstants.APPLY_OPT_TYPE_LOWER_SHELF);
        tempAppToolFlow.setStatus(MarketConstants.APPLY_STATUS_APPROVAL);
        tempAppToolFlow.setApplyExplain(appToolFlow.getApplyExplain());

        return R.ok(SqlHelper.delBool(this.baseMapper.insert(tempAppToolFlow)));
    }


    @Override
    public List<AppToolFlowStep> findStepList(String flowFlag) {
        List<AppToolFlow> appToolFlowList;
        String br = "<br/>";
        String[] stepStatus = {"wait", "process", "finish", "error", "success"};
        List<AppToolFlowStep> flowSteps = new ArrayList<>();
        if (StringUtils.isNotBlank(flowFlag)) {
            AppToolFlow search = new AppToolFlow();
            search.setFlowFlag(flowFlag);
            appToolFlowList = this.baseMapper.findStepList(search);
            appToolFlowList.stream().forEach(appToolFlow -> {
                AppToolFlowStep first = new AppToolFlowStep();
                AppToolFlowStep second = new AppToolFlowStep();
                String status = appToolFlow.getStatus();
                StringBuffer firstBuffer = new StringBuffer();
                StringBuffer secondBuffer = new StringBuffer();
                firstBuffer.append("申请人：").append(appToolFlow.getApplicantName()).append(br);
                firstBuffer.append("申请时间：").append(DateUtil.formatDateTime(appToolFlow.getApplyTime())).append(br);
                firstBuffer.append("申请说明：").append(appToolFlow.getApplyExplain()).append(br);
                secondBuffer.append("审批人：").append(StringUtils.isBlank(appToolFlow.getApproveName()) ? "管理员" : appToolFlow.getApproveName()).append(br);
                secondBuffer.append("审批时间：").append(appToolFlow.getApprovalTime() == null ? "暂无" : DateUtil.formatDateTime(appToolFlow.getApprovalTime())).append(br);
                secondBuffer.append("审批意见：").append(StringUtils.isBlank(appToolFlow.getOpinion()) ? "暂无" : appToolFlow.getOpinion()).append(br);
                switch (status) {
                    case MarketConstants.APPLY_STATUS_DRAFT:
                        //草稿状态
                        first.setTitle("草稿状态");
                        first.setDesc(firstBuffer.toString());
                        first.setStatus(stepStatus[1]);
                        second.setTitle("等待提交");
                        second.setStatus(stepStatus[0]);
                        second.setDesc(secondBuffer.toString());
                        break;
                    case MarketConstants.APPLY_STATUS_APPROVAL:
                        first.setTitle("已提交");
                        first.setDesc(firstBuffer.toString());
                        first.setStatus(stepStatus[4]);
                        second.setTitle("等待审批");
                        second.setStatus(stepStatus[1]);
                        second.setDesc(secondBuffer.toString());
                        //审批中状态
                        break;
                    case MarketConstants.APPLY_STATUS_REJECT:
                        first.setTitle("已提交");
                        first.setDesc(firstBuffer.toString());
                        first.setStatus(stepStatus[4]);
                        second.setTitle("驳回");
                        second.setStatus(stepStatus[3]);
                        second.setDesc(secondBuffer.toString());
                        //驳回状态
                        break;
                    case MarketConstants.APPLY_STATUS_PASS:
                        //通过状态
                        first.setTitle("已提交");
                        first.setDesc(firstBuffer.toString());
                        first.setStatus(stepStatus[4]);
                        second.setTitle("通过");
                        second.setStatus(stepStatus[4]);
                        second.setDesc(secondBuffer.toString());
                        break;
                    default:
                }
                flowSteps.add(first);
                flowSteps.add(second);
            });
        }
        return flowSteps;
    }


}
