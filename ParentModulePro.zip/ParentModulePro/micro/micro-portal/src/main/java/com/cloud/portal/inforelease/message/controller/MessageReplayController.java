package com.cloud.portal.inforelease.message.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.inforelease.message.model.MessageReplay;
import com.cloud.portal.inforelease.message.service.MessageReplayService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author rush
 * @Date Created in 2020/3/19 14:12
 * Description: 留言板回复控制层
 * Modified By:
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/message/replay/")
public class MessageReplayController {
    /**
     * 留言板回复接口层
     */
    private final MessageReplayService messageReplayService;

    /**
     * 分页查询 留言回复信息
     *
     * @param page          分页对象
     * @param messageReplay 留言回复实体类
     * @return
     */
    @GetMapping("page")
    @SysLog("留言查询")
    public R getMessageBoardPage(Page page, MessageReplay messageReplay) {
        IPage<MessageReplay> messageReplayIpage = messageReplayService.getListPage(page, messageReplay);
        return R.ok(messageReplayIpage);
    }

    /**
     * 查询留言回复列表
     *
     * @param id
     * @return
     */
    @GetMapping("/findList/{id}")
    @SysLog(value = "得到留言回复", type = CommonConstants.LOG_DELELE)
    public R findList(@PathVariable String id) {
        MessageReplay messageReplay = new MessageReplay();
        messageReplay.setBoardId(id);
        List<MessageReplay> messageReplayList = messageReplayService.list(Wrappers.query(messageReplay).orderByAsc(MessageReplay::getCreateTime));
        return R.ok(messageReplayList);
    }

    @DeleteMapping("/removeById/{id}")
    @SysLog(value = "删除留言回复", type = CommonConstants.LOG_DELELE)
    public R removeById(@PathVariable String id) {
        return new R<>(messageReplayService.removeById(id));
    }

    /**
     * 新增 留言回复内容
     *
     * @param messageReplay
     * @return R
     */
    @SysLog(value = "添加留言回复", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    public R save(@RequestBody MessageReplay messageReplay) {

        return R.ok(messageReplayService.saveMessageReplay(messageReplay));
    }
}
