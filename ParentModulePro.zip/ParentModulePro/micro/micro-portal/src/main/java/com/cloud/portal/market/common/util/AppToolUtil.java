package com.cloud.portal.market.common.util;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.IdUtil;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.tag.entity.TagLink;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author wengshij
 * @date Created in 2020/3/27 9:24
 * @description:
 * @modified By:wengshij
 */
@UtilityClass
public class AppToolUtil {

    /**
     * 初始化应用工具参数
     *
     * @param appTool
     * @return
     */
    public AppTool initAppToolParams(AppTool appTool) {
        MicroUser microUser = SecurityUtils.getUser();
        appTool.setId(StringUtils.isBlank(appTool.getId()) ? IdUtil.randomUUID() : appTool.getId());
        appTool.setUpdateBy(microUser.getId());
        appTool.setCreateTime(new Date(System.currentTimeMillis()));
        appTool.setUpdateTime(appTool.getCreateTime());
        appTool.setDelFlag(CommonConstants.STATUS_NORMAL);
        appTool.setGrade(StringUtils.isBlank(appTool.getGrade()) ? MarketConstants.APP_TOOL_GRADE_FIVE : appTool.getGrade());
        appTool.setRecommend(StringUtils.isBlank(appTool.getRecommend()) ? MarketConstants.APP_TOOL_RECOMMEND_NO : appTool.getRecommend());
        appTool.setCreateBy(StringUtils.isBlank(appTool.getCreateBy()) ? microUser.getId() : appTool.getCreateBy());
        appTool.setUpTime(appTool.getCreateTime());
        //1、设置操作手册内容信息
        appTool.setOptManualList(initOptAppToolManual(appTool));
        //2、设置编目信息
        if (StringUtils.isNotBlank(appTool.getCatalogId())) {
            List<CatalogLink> catalogLinkList = new ArrayList<>();
            Arrays.stream(appTool.getCatalogId().split(",")).forEach(catalogId -> {
                CatalogLink catalogLink = new CatalogLink();
                catalogLink.setOtherId(appTool.getId());
                catalogLink.setCatalogId(catalogId);
                catalogLinkList.add(catalogLink);
            });
            appTool.setCatalogLinkList(catalogLinkList);
        }
        if (CollectionUtil.isNotEmpty(appTool.getLabelId())) {
            List<TagLink> tagLinkList = appTool.getLabelId().stream().map(label -> {
                TagLink tagLink = new TagLink();
                tagLink.setAppToolId(appTool.getId());
                tagLink.setLabelId(label);
                return tagLink;
            }).collect(Collectors.toList());
            appTool.setTagLinkList(tagLinkList);
        }
        return appTool;
    }

    /**
     * 初始化 应用工具操作手册信息
     *
     * @param appTool
     * @return
     */
    public List<OptManual> initOptAppToolManual(AppTool appTool) {
        List<OptManual> optManualList = new ArrayList<>();
        if (CollectionUtil.isNotEmpty(appTool.getOptManualList())) {
            appTool.getOptManualList().stream().forEach(optManual -> {
                optManual.setId(IdUtil.randomUUID());
                optManual.setAppToolId(appTool.getId());
                optManual.setCompanyId(appTool.getCompanyId());
                optManual.setCreateBy(appTool.getCreateBy());
                optManual.setUpdateBy(appTool.getUpdateBy());
                optManual.setCreateTime(appTool.getCreateTime());
                optManual.setUpdateTime(appTool.getUpdateTime());
                optManual.setExtType(optManual.getFileName().substring(optManual.getFileName().lastIndexOf(".") + 1));
                optManual.setBucketName(PortalConstants.MINIO_MARKET_BUCKET);
                optManual.setDownloadNum(0);
                optManualList.add(optManual);
            });
        }
        return optManualList;
    }
}
