package com.cloud.portal.market.work.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.work.model.Bench;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:21
 * @description:个人工作台信息
 * @modified By:liuwei
 */
public interface BenchMapper extends BaseMapper<Bench> {
    /**
     * 查询个人工作台信息
     * @param bench
     * @return
     */
    Bench findOwnBench(@Param("bench")Bench bench);

    /**
     * 查询默认个人工作台信息
     * @return
     */
    Bench defaultBench();

    /**
     * 查询默认工作台分页信息
     *
     * @param page
     * @return
     */
    IPage<Bench> getBenchPage(IPage<Bench> page);
}
