package com.cloud.portal.market.services.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.market.services.entity.ServiceFile;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author chenchunl
 * @date Created in 2020/4/9 14:33
 * @description: 服务申请相关附件mapper
 * @modified By:chenchunl
 */
public interface ServiceFileMapper extends BaseMapper<ServiceFile> {

    /**
     * 批量插入文件信息
     * @param serviceFiles
     * @return
     */
    boolean addFiles(@Param("list") List<ServiceFile> serviceFiles);

    /**
     * 根据服务接口id查询相关附件
     * @param id
     * @return
     */
    List<ServiceFile> findServiceFileByServiceId(String id);

    /**
     * 根据服务id删除附件信息
     * @param serviceId
     * @return
     */
    boolean delFileByServiceId(String serviceId);

    /**
     * 通过附件id修改下载次数
     * @param serviceFile
     * @return
     */
    boolean updateDownloadNumById(ServiceFile serviceFile);

}
