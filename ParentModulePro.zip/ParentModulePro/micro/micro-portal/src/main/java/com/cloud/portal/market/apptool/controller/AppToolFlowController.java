package com.cloud.portal.market.apptool.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolFlow;
import com.cloud.portal.market.apptool.service.AppToolFlowService;
import com.cloud.portal.market.common.constant.MarketConstants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * @author wengshij
 * @date Created in 2020/3/25 10:20
 * @description:应用工具申请上架流程
 * @modified By:wengshij
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/app/tool/flow")
public class AppToolFlowController {
    /**
     * 应用上架接口信息
     */
    private final AppToolFlowService appToolFlowService;


    /**
     * 分页查询 应用工具信息
     *
     * @param page        分页对象
     * @param appToolFlow 应用工具流程实体类
     * @return
     */
    @GetMapping("page")
    @SysLog(value = "[应用/工具]审批")
    public R getAppToolFlowPage(Page page, AppToolFlow appToolFlow) {
        return R.ok(appToolFlowService.getAppToolFlowPage(page, appToolFlow));
    }

    /**
     * 审批
     *
     * @param appToolFlow
     * @return
     */
    @PostMapping("approval")
    @SysLog(value = "[应用/工具]审批", type = CommonConstants.LOG_EDIT)
    @PreAuthorize("@pms.hasPermission('app_tool_approval_power')")
    public R approval(@RequestBody AppToolFlow appToolFlow) {
        return R.ok(appToolFlowService.approval(appToolFlow));
    }

    /**
     * 通过id删除 应用工具
     *
     * @param id 主键ID
     * @return R
     */
    @SysLog(value = "应用工具申请流程删除", type = CommonConstants.LOG_DELELE)
    @DeleteMapping("delete/{id}")
    public R removeById(@PathVariable String id) {
        AppToolFlow appToolFlow = appToolFlowService.getById(id);
        if (!MarketConstants.APPLY_STATUS_DRAFT.equals(appToolFlow.getStatus())) {
            throw new RuntimeException("非草稿状态的记录不能被删除。");
        }
        return R.ok(appToolFlowService.removeById(id));
    }


    /**
     * 应用工具上架申请操作
     *
     * @param appTool
     * @return R
     */
    @SysLog(value = "[应用/工具]申请操作", type = CommonConstants.LOG_ADD)
    @PostMapping("applyOperation")
    public R applyOperation(@RequestBody AppTool appTool) {
        return appToolFlowService.applyOperation(appTool);
    }


    @SysLog(value = "[应用/工具]下架操作", type = CommonConstants.LOG_EDIT)
    @PostMapping("downApproval")
    public R downApproval(@RequestBody AppToolFlow appToolFlow) {
        return appToolFlowService.downApproval(appToolFlow);
    }


    /**
     * 通过id查询该应用工具流程信息
     *
     * @param id id
     * @return R
     */
    @GetMapping("get/{id}")
    public R getById(@PathVariable("id") String id) {
        return R.ok(appToolFlowService.getById(id));
    }

    @GetMapping("getFlowStep/{flowFlag}")
    @SysLog(value = "获取流程流转信息")
    public R getFlowStep(@PathVariable("flowFlag") String flowFlag) {
        return R.ok(appToolFlowService.findStepList(flowFlag));
    }

}
