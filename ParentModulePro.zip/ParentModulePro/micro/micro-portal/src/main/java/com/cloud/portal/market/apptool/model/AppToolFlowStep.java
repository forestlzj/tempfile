package com.cloud.portal.market.apptool.model;

import lombok.Data;

import java.io.Serializable;

/**
 * @author wengshij
 * @date Created in 2020/3/30 9:59
 * @description:
 * @modified By:wengshij
 */
@Data
public class AppToolFlowStep implements Serializable {

    /**
     * 状态
     * wait、process、finish、error
     */
    private String status;
    /**
     * 标题
     */
    private String title;

    /**
     * 说明信息
     */
    private String desc;


}
