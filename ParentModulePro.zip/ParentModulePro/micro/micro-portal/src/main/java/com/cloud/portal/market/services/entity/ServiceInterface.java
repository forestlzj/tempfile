package com.cloud.portal.market.services.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

/**
 * @author wuxx
 * @date 2020/3/10 16:54
 * @description: TODO
 * @modified By:
 **/

@Data
@TableName("t_portal_service_interf")
@EqualsAndHashCode(callSuper = true)
public class ServiceInterface extends Model<ServiceInterface> {


    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 服务名称
     */
    @LogField(title = "服务名称")
    private String name;


    @LogField(title = "令牌地址")
    private String tokenUrl;


    @LogField(title = "回调地址")
    private String callBackUrl;

    @LogField(title = "请求地址")
    private String requestUrl;

    /**
     * 状态（0-上架  1-下架 -3其他 ）
     */
    private String status;

    /**
     * 所属公司编号
     */
    private String companyId;

    /**
     * 服务类型( 0-本地接口  1-警务云接口)
     */
    private String serviceType;

    /**
     * 接口地址(直接跳转 ) 当服务类型为1时有效
     */
    @LogField(title = "接口地址")
    private String otherUrl;

    /**
     * 接口明细（请求参数-返回数据-接口示例-错误码）
     */
    private String apiDesc;

    /**
     * 服务简要说明
     */

    private String briefDesc;

    /**
     * 服务图标
     */
    private String icon;

    /**
     * 调用次数
     */
    @LogField(title = "调用次数")
    private String useNum;


    /**
     * 编目ID
     */
    @TableField(exist = false)
    private String catalogId;

    /**
     * 0-正常，1-删除
     */
    @TableLogic
    private String delFlag;
    private String createBy;
    private String updateBy;
    /**
     * 创建时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;

    /**
     * 编目ID集合
     */
    @TableField(exist = false)
    private List<String> catalogIdList;
    
    /**
     * 编目关联信息
     */
    @TableField(exist = false)
    private List<CatalogLink> catalogLinkList;

    /**
     * 相关附件
     */
    @TableField(exist = false)
    private List<ServiceFile> serviceFiles;

    /**
     * 标签ID
     */
    @TableField(exist = false)
    private List<String> labelId;

    /**
     * 标签名
     */
    @TableField(exist = false)
    private String labelName;

    /**
     * 服务接口申请状态   null 未申请  2审批中  3已申请
     */
    @TableField(exist = false)
    private String applyStatus;

    @TableField(exist = false)
    private String applicant;

}
