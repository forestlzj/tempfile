package com.cloud.portal.market.services.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author chenchunl
 * @date Created in 2020/4/9 17:24
 * @description: 服务上架/操作申请
 * @modified By:chenchunl
 */
@Data
@TableName("t_portal_service_opt_flow")
public class ServiceOptFlow extends Model<ServiceOptFlow> {

    private static final long serialVersionUID = -2491056015647160606L;

    @TableId(value = "id",type = IdType.INPUT)
    @LogField(title = "主键")
    private String id;

    @LogField(title = "服务ID")
    private String serviceId;

    @LogField(title = "接口明细")
    private String apiDesc;

    @LogField(title = "申请内容")
    private String applyContent;

    @LogField(title = "申请人")
    private String applicant;

    @LogField(title = "申请时间")
    private Date applyTime;

    @LogField(title = "申请说明）")
    private String applyInstructions;

    @LogField(title = "审批人")
    private String approver;

    @LogField(title = "审批时间")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date approvalTime;


    @LogField(title = "状态（0-草稿,1-驳回,2-审批中,3-通过,）")
    private String status;


    @LogField(title = "审批意见")
    private String opinion;

    @LogField(title = "创建时间")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;


    @LogField(title = "更新时间")
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;


    @LogField(title = "创建者")
    private String createBy;


    @LogField(title = "更新者")
    private String updateBy;


    @LogField(title = "删除标识")
    private String delFlag;

    @LogField(title = "操作类型(0-上架 1-下架 2-更新 3-删除)")
    private String optType;

    /**
     * 申请人姓名
     */
    @TableField(exist = false)
    private String name;

    /**
     * 服务名称
     */
    @TableField(exist = false)
    private String serviceName;

    private String flowFlag;


}
