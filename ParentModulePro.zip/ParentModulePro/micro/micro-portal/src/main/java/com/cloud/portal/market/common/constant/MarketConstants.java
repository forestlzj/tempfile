package com.cloud.portal.market.common.constant;

/**
 * @author wengshij
 * @date Created in 2020/3/25 15:52
 * @description:超市公共参数类
 * @modified By:wengshij
 */
public interface MarketConstants {
    /**
     * 应用工具申请上架操作
     */
    String APPLY_OPT_TYPE_UPPER_SHELF = "0";
    /**
     * 应用工具申请下架操作
     */
    String APPLY_OPT_TYPE_LOWER_SHELF = "1";
    /**
     * 应用工具申请更新操作
     */
    String APPLY_OPT_TYPE_UPDATE = "2";

    /**
     * 审批通过
     */
    String APPLY_STATUS_PASS = "3";
    /**
     * 草稿状态
     */
    String APPLY_STATUS_DRAFT = "0";
    /**
     * 审批中
     */
    String APPLY_STATUS_APPROVAL = "1";
    /**
     * 驳回
     */
    String APPLY_STATUS_REJECT = "2";

    /**
     * 应用类型
     */
    String APP_TYPE = "app";
    /**
     * 工具类型
     */
    String TOOL_TYPE = "tool";
    /**
     * 应用工具上架状态
     */
    String APP_TOOL_STATUS_UP = "0";
    /**
     * 应用工具下架状态
     */
    String APP_TOOL_STATUS_DOWN = "1";

    String APP_TOOL_FLOW_LIST_POWER = "app_tool_flow_list";

    /**
     * 操作手册ID 后缀ID
     */
    String TEMP_OPT_MANUAL_ID = "_temp";

    /**
     * 应用工具缓存信息
     */
    String APP_TOOL_CACHE_NAME = "app_tool_cache";
    /**
     * 应用工具树形结构缓存key值
     */
    String APP_TOOL_CACHE_KEY_TREE_NAME = "tree_";
    /**
     * 应用工具评级 5星级
     */
    String APP_TOOL_GRADE_FIVE = "5";
    /**
     * 应用工具是否推荐使用 否
     */
    String APP_TOOL_RECOMMEND_NO = "1";

    /**
     * 开发公司缓存信息
     */
    String COMPANY_CACHE_NAME = "company_cache";

    /**
     * 开发公司缓存信息
     */
    String CATALOG_CACHE_NAME = "catalog_cache";

    /**
     * 标签缓存信息
     */
    String TAG_CACHE_NAME = "tag_cache";

    /**
     * 可视化页面缓存信息
     */
    String KSHYM_CACHE_NAME = "kshym_cache";

    /**
     * 操作日志访问成功标识
     */
    String LOG_SUCCESS = "0";
    /**
     * 操作日志请求方式
     */
    String LOG_REQUEST_METHOD_GET = "GET";
    /**
     * 操作日志注册公司日志ID
     */
    String LOG_REG_ID = "ygnet";

    String LOG_OPERATE_LIST_POWER = "operate_log_view_all";

}
