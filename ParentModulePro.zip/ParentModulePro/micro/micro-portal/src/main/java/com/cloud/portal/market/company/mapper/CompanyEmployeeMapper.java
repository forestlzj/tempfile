package com.cloud.portal.market.company.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.company.model.Company;
import com.cloud.portal.market.company.model.CompanyEmployee;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/12 14:55
 * @description:
 * @modified By:liuwei
 */
public interface CompanyEmployeeMapper extends BaseMapper<CompanyEmployee>{
    /**
     * 通过公司id更新删除标识
     * @param list
     * @return
     */
    boolean updateDel(List<String> list);

    /**
     * 更新删除标识
     * @param list
     * @return
     */
    boolean updateDelById(List<String> list);
    /**
     * 获取开发公司列表信息
     * @param page
     * @param companyEmployee
     * @return
     */
      IPage<List<CompanyEmployee>> findListPage(IPage<CompanyEmployee> page, @Param("companyEmployee") CompanyEmployee companyEmployee);

}
