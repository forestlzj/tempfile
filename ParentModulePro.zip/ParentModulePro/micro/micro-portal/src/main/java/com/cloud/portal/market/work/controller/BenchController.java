package com.cloud.portal.market.work.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.company.model.Company;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.service.BenchService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:20
 * @description:个人工作台信息
 * @modified By:liuwei
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/work/bench/")
public class BenchController {
    /**
     * 工作台信息接口层
     */
    private final BenchService benchService;
    /**
     * 新增 个人工作台信息
     *
     * @param bench
     * @return R
     */
    @SysLog(value = "个人工作台信息新增", type = CommonConstants.LOG_ADD)
    @PostMapping("save")
    public R save(@RequestBody Bench bench) {
        return R.ok(benchService.saveBench(bench));
    }

    /**
     * 查询个人工作台信息
     * @param bench
     * @return R
     */
    @GetMapping("getBench")
    @SysLog(value = "查询个人工作台信息")
    public R getBench(Bench bench){
        return R.ok(benchService.findBench(bench));
    }

    /**
     * 查询默认工作台信息
     * @return R
     */
    @GetMapping("getDefaultBench")
    @SysLog(value = "查询默认工作台信息")
    public R getDefaultBench(Page page){
        return R.ok(benchService.findBenchPage(page));
    }

}