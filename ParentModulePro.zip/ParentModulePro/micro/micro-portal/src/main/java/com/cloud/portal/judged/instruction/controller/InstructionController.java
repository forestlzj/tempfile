package com.cloud.portal.judged.instruction.controller;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.sqjw.constant.enums.HttpCodeEnum;
import com.cloud.portal.sqjw.model.SqjwYjjg;
import com.cloud.portal.sqjw.service.SqjwService;
import com.cloud.portal.judged.instruction.model.Instruction;
import com.cloud.portal.judged.instruction.service.InstructionService;
import com.cloud.portal.judged.warn.service.WarnInfoService;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.time.LocalDateTime;
import java.util.Map;

/*
 * @author Molly
 * @date Created in 2019/6/24
 * @description: 智能预警-指令控制层
 * @modified By: Molly
 */
@RestController
@AllArgsConstructor
@RequestMapping("/judged/instruction")
public class InstructionController {

    @Autowired
    private InstructionService instructionService;
    @Autowired
    private SqjwService sqjwService;
    @Autowired
    private WarnInfoService warnInfoService;

    @GetMapping("/page")
    @SysLog("预警中心查询")
    @ApiOperation(httpMethod = "GET", value = "预警查询")
    public R findListPage(Page page, Instruction instruction){
        instruction.setNotContainDraft(true);
        return new R<>(instructionService.page(page,instruction));
    }

    @GetMapping("/current_user/send_page")
    @SysLog("查询当前用户发布的指令列表")
    @ApiOperation(httpMethod = "GET", value = "查询当前用户发布的指令列表")
    public R findCurrentUserSendListPage(Page page, Instruction instruction){
        return new R<>(instructionService.findCurrentUserSendListPage(page,instruction));
    }

    @GetMapping("overtime_page")
    @SysLog("查询超时反馈指令")
    @ApiOperation(httpMethod = "GET",value = "查询超时反馈指令")
    public R findOvertimeListPage(Page page,Instruction instruction){
        return new R(instructionService.findOvertimeListPage(page,instruction));
    }

    @PostMapping("/save_artificial_instruction")
    @SysLog(value = "保存人工指令",type = CommonConstants.LOG_ADD)
    @ApiOperation(httpMethod = "POST", value = "保存人工指令")
    public R saveArtificialInstruction(@Valid @RequestBody Instruction instruction) {
        instruction.setType(Instruction.ARTIFICIAL_INSTRUCTION_TYPE);
        instruction.setStatus(Instruction.DRAFT_INSTRUCTION_STATUS);
        return new R<>(instructionService.saveOrUpdate(instruction));
    }

    @PostMapping("/send_artificial_instruction")
    @SysLog(value = "下发人工指令",type = CommonConstants.LOG_ADD)
    @ApiOperation(httpMethod = "POST", value = "下发人工指令")
    public R sendArtificialInstruction(@Valid @RequestBody Instruction instruction, HttpServletRequest request) {
        instruction.setType(Instruction.ARTIFICIAL_INSTRUCTION_TYPE);
        instruction.setStatus(Instruction.DRAFT_INSTRUCTION_STATUS);  //草稿
        instruction.setSendTime(LocalDateTime.now());
        instruction.setSendOrg(SecurityUtils.getUser().getSysDept().getCode());
        instruction.setSenderIdcard(SecurityUtils.getUser().getSysUser().getIdcard());
        instruction.setSenderNo(SecurityUtils.getUser().getSysUser().getPoliceNumber());
        //instruction.setStatus(Instruction.SEND_SUCCESS_INSTRUCTION_STATUS);  //发送成功
        instructionService.saveOrUpdate(instruction);
        //SqjwYjjg result = new SqjwYjjg();
        //warnInfoService.updateSendById(instruction.getWarnId());
        SqjwYjjg result = sqjwService.sendYjxxgl(instruction);
        if(result!=null&& HttpCodeEnum.SUCCESS.getCode().equals(result.getCode())){
            instruction.setStatus(Instruction.SEND_SUCCESS_INSTRUCTION_STATUS);  //发送成功
            instructionService.saveOrUpdate(instruction);
            if(StringUtils.isNotEmpty(instruction.getWarnId())){
                //修改预警下发状态
                warnInfoService.updateSendById(instruction.getWarnId());
            }
        }
        return new R<>(result);//保存下发
    }

    @GetMapping("/delete/{id}")
    @SysLog(value = "删除指令",type = CommonConstants.LOG_DELELE)
    @ApiOperation(httpMethod = "GET", value = "删除指令")
    public R delete(@PathVariable("id") String id){
        return new R<>(instructionService.removeById(id));
    }

    /**
     * 根据指令类型获取列表
     * @param type
     * @return
     */
    @GetMapping("/remote/list/{type}/{status}")
    @SysLog("指令列表")
    public R listByType(@PathVariable("type")String type,String status){
        Instruction instruction = new Instruction();
        instruction.setType(type);
        instruction.setStatus(status);
        return new R<>(instructionService.list(Wrappers.<Instruction>query(instruction)));
    }

    /**
     * 发送自动指令
     * @param instruction
     * @return
     */
    @PostMapping("/remote/send_auto_instruction")
    @SysLog(value = "自动指令",type = CommonConstants.LOG_ADD)
    public R<SqjwYjjg> sendAutoInstruction(@RequestBody Instruction instruction){
        instruction.setType(Instruction.AUTOMATIC_INSTRUCTION_TYPE);
        instruction.setStatus(Instruction.SEND_SUCCESS_INSTRUCTION_STATUS);  //发送成功
        instruction.setSendTime(LocalDateTime.now());
        SqjwYjjg result = sqjwService.sendYjxxgl(instruction);
        if(result!=null&& HttpCodeEnum.SUCCESS.getCode().equals(result.getCode())){
            instructionService.saveAutoInstruction(instruction);
        }
        return new R<>(result);//保存下发
    }

    @GetMapping("/total/today")
    @SysLog("统计当天预警数")
    public R totalByToday(Instruction instruction){
        return new R(instructionService.totalByToday(instruction));
    }

}
