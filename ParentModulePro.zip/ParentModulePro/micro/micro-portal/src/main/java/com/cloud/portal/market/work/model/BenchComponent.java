package com.cloud.portal.market.work.model;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author liuwei
 * @date Created in 2020/4/8 14:59
 * @description:个人工作台组件信息
 * @modified By:liuwei
 */
@Data
@TableName("T_PORTAL_WORK_BENCH_COMPONENT")
@EqualsAndHashCode(callSuper = true)
public class BenchComponent extends Model<BenchComponent> {
    /**
     * 主键ID
     */
    @TableId
    private String id;
    /**
     * 组件名称
     */
    private String name;
    /**
     * 组件key值（不能重复，英文）
     */
    private String keyValue;
    /**
     * 组件页面路径
     */
    private String pagePath;
    /**
     * 备注说明
     */
    private String remark;
    /**
     * 排序
     */
    private Integer sorts;
    /**
     * 创建时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * 删除标识(0正常，1删除)
     */
    private String delFlag;
    /**
     * 显示方式（0:左右两边,1:左边,2:右边）
     */
    private String showType;
    /**
     * 显示隐藏（0:显示,1:隐藏）
     */
    private String showHide;
}
