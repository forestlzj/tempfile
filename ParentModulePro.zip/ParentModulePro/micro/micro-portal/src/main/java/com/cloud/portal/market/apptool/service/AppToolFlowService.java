package com.cloud.portal.market.apptool.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolFlow;
import com.cloud.portal.market.apptool.model.AppToolFlowStep;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author wengshij
 * @date Created in 2020/3/25 10:22
 * @description:
 * @modified By:wengshij
 */
public interface AppToolFlowService extends IService<AppToolFlow> {

    /**
     * 获取应用工具流程信息
     *
     * @param page
     * @param appToolFlow
     * @return
     */
    IPage<AppToolFlow> getAppToolFlowPage(IPage<AppToolFlow> page, AppToolFlow appToolFlow);

    /**
     * 审批
     *
     * @param appToolFlow
     * @return
     */
    boolean approval(AppToolFlow appToolFlow);

    /**
     * 应用工具申请操作处理
     *
     * @param appTool
     * @return
     */
    R applyOperation(AppTool appTool);

    /**
     * 应用过工具申请下架操作
     *
     * @param appToolFlow
     * @return
     */
    R downApproval(AppToolFlow appToolFlow);

    /**
     * 获取流程流转信息
     * 根据流转标识符 获取同一个流程下所有的流转信息
     *
     * @param flowFlag
     * @return
     */
    List<AppToolFlowStep> findStepList(String flowFlag);
}
