package com.cloud.portal.market.work.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.work.model.Bench;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:31
 * @description:个人工作台信息
 * @modified By:liuwei
 */
public interface BenchService extends IService<Bench> {

    /**
     * 添加个人工作台信息
     *
     * @param bench
     * @return
     */
    boolean saveBench(Bench bench);

    /**
     * 查询个人工作台信息（初始化信息）
     *
     * @param bench
     * @return
     */
    Bench findBench(Bench bench);

    /**
     * 根据用户和样式查询工作台信息
     *
     * @param bench
     * @return
     */
    Bench findOwnBench(Bench bench);

    /**
     * 查询默认样式
     *
     * @return
     */
    Bench defaultBench();


    /**
     * 默认工作台分页信息
     *
     * @param page
     * @return
     */
    IPage<Bench> findBenchPage(IPage<Bench> page);
}
