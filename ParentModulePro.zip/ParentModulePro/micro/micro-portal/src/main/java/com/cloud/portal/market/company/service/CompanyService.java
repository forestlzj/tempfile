package com.cloud.portal.market.company.service;


import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.company.model.Company;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/11 17:15
 * @description:开发公司接口层
 * @modified By:liuwei
 */
public interface CompanyService extends IService<Company> {
    /**
     * 查询列表（分页）
     * @param page
     * @param company
     * @return
     */
    IPage<List<Company>> page(IPage<Company> page, Company company);

    /**
     * 删除图标
     *
     * @param base64Id
     * @return
     */
    R deleteIcon(String base64Id);

    /**
     * 上传图标信息
     *
     * @param file
     * @return
     * @throws Exception
     */
    R uploadIcon(MultipartFile file) throws Exception;

    /**
     * 下载图标
     *
     * @param base64Id
     * @return
     */
    InputStream downLoadIcon(String base64Id);



    /**
     * 添加开发公司信息
     *
     * @param company
     * @return
     */
    boolean saveCompany(Company company);

    /**
     * 更新开发公司信息
     * @param company
     * @return
     */
    boolean updateCompany(Company company);

    /**
     * 更新删除标识
     * @param list
     * @return
     */
    boolean updateDel(List<String> list);

    /**
     * 开发公司列表
     * @param all
     * @return
     */
    List<Company> findList(String  all);

    /**
     * 根据id获取公司信息（包括开发人员）
     * @param id
     * @return
     */
    Company getAllById(String id);

}