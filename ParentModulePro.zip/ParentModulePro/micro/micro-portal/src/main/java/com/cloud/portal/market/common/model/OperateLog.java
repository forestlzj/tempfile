package com.cloud.portal.market.common.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.List;

/**
 * @author wengshij
 * @date Created in 2020/4/21 11:14
 * @description:操作日志信息
 * @modified By:wengshij
 */
@Data
@TableName("T_PORTAL_OPERATE_LOG")
@EqualsAndHashCode(callSuper = true)
public class OperateLog extends Model<OperateLog> {
    /**
     * 主键ID
     */
    @TableId(type = IdType.UUID)
    private String id;
    /**
     * 日志访问类型(应用 工具 数据 服务)
     */
    @LogField(title = "日志类型")
    private String operateType;
    /**
     * 标题名称
     */

    @LogField(title = "模块名称")
    private String title;
    /**
     * 访问地址
     */
    private String remoteAdd;
    /**
     * 浏览器
     */
    private String browser;
    /**
     * 请求地址
     */
    private String requestUrl;
    /**
     * 请求方式（get post put）
     */
    private String requestMethod;
    /**
     * 操作时间
     */
    @LogField(title = "操作时间")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    private Date operateTime;
    /**
     * 操作内容
     */
    private String operateCondition;
    /**
     * 身份证或警号
     */
    @LogField(title = "用户编号")
    private String userId;
    /**
     * 机构代码
     */
    private String orgCode;
    /**
     * 用户名称
     */
    @LogField(title = "用户名称")
    private String userName;
    /**
     * 用户名称
     */
    private String orgName;
    /**
     * 操作结果（成功 异常 ）
     */
    @LogField(title = "操作结果")
    private String operateResult;
    /**
     * 异常内容
     */
    private String operateError;
    /**
     * 注册ID（标识是哪家公司的ID）
     */
    private String regId;
    /**
     * 业务表ID
     */
    @LogField(title = "业务表编号")
    private String bussId;
    @TableField(exist = false)
    private List<String> searchDate;

}
