package com.cloud.portal.market.apptool.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.admin.api.entity.SysUser;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.security.component.PermissionService;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.apptool.service.AppToolService;
import com.cloud.portal.market.apptool.service.OptManualService;
import com.cloud.portal.market.apptool.service.UsePowerFlowService;
import com.cloud.portal.market.apptool.mapper.UsePowerFlowMapper;
import com.cloud.portal.market.apptool.model.UsePowerFlow;
import com.cloud.portal.market.apptoolpower.model.AppToolPower;
import com.cloud.portal.market.apptoolpower.service.AppToolPowerService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.stream.Collectors;

/**
 * @author huangyingx
 * @date Created in 2019/8/5 11:21
 * @description: 应用工具申请访问流程service实现类
 * @modified By: huangyingx
 */
@Service
@AllArgsConstructor
public class UsePowerFlowServiceImpl extends ServiceImpl<UsePowerFlowMapper,UsePowerFlow> implements UsePowerFlowService{

    /**
     * 操作文档 接口
     */
    @Autowired
    private OptManualService optManualService;
    /**
     * 权限
     */
    @Autowired
    private PermissionService permissionService;
    /**
     * 应用工具接口
     */
    @Autowired
    private AppToolService appToolService;
    /**
     * 权限表接口
     */
    @Autowired
    private AppToolPowerService appToolPowerService;

    @Override
    public IPage<List<UsePowerFlow>> findPage(IPage<UsePowerFlow> page, UsePowerFlow usePowerFlow) {
        usePowerFlow.setDelFlag(CommonConstants.STATUS_NORMAL);
        return this.baseMapper.findPage(page,usePowerFlow);
    }

    @Override
    public List<UsePowerFlow> findPage(UsePowerFlow usePowerFlow) {
        usePowerFlow.setDelFlag(CommonConstants.STATUS_NORMAL);
        return this.baseMapper.findPage(usePowerFlow);
    }

    @Override
    public IPage<List<UsePowerFlow>> findListByAuthorize(IPage<UsePowerFlow> page, UsePowerFlow usePowerFlow) {
        boolean isApprove = permissionService.hasPermission("app_tool_approve_use");
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        usePowerFlow.setAdmin(sysUser.isAdmin());
        usePowerFlow.setApprove(isApprove);
        if(!sysUser.isAdmin()){
            usePowerFlow.setApplicant(sysUser.getUserId());
        }
        return findPage(page,usePowerFlow);
    }

    @Override
    public List<UsePowerFlow> findListByApplicant(UsePowerFlow usePowerFlow) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        usePowerFlow.setApprove(false);
        usePowerFlow.setApplicant(sysUser.getUserId());
        return findPage(usePowerFlow);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean addApply(UsePowerFlow usePowerFlow) {
        //初始化参数
        usePowerFlow = init(usePowerFlow);
        //翻译appToolNames
        usePowerFlow.setAppToolNames(getAppToolNamesByIds(usePowerFlow.getAppToolIds()));

        Date now = usePowerFlow.getCreateTime();
        String userId = usePowerFlow.getCreateBy();
        String flowId = usePowerFlow.getId();
        if(usePowerFlow.getOptManualList()!=null && usePowerFlow.getOptManualList().size()>0){
            //保存附件
            usePowerFlow.getOptManualList().forEach(e->{
                String fileName = e.getFileName();
                if(StringUtils.isNotBlank(fileName)){
                    e.setExtType(fileName.substring(fileName.indexOf(".")+1,fileName.length()));
                    e.setBucketName(PortalConstants.MINIO_MARKET_BUCKET);
                    e.setCreateTime(now);
                    e.setUpdateTime(now);
                    e.setCreateBy(userId);
                    e.setUpdateBy(userId);
                    e.setAppToolId(flowId);
                }
            });
            optManualService.saveBatch(usePowerFlow.getOptManualList());
        }

        //保存授权信息

        savePowerBatchByIds(usePowerFlow.getAppToolIds(),usePowerFlow.getCreateBy(),usePowerFlow.getBussType(),CommonConstants.STATUS_NORMAL);

        //保存申请信息
        return SqlHelper.delBool(this.baseMapper.insert(usePowerFlow));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateApply(UsePowerFlow usePowerFlow) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        Date now = new Date(System.currentTimeMillis());
        String userId = sysUser.getUserId();
        String flowId = usePowerFlow.getId();
        usePowerFlow.setUpdateBy(sysUser.getUserId());
        usePowerFlow.setUpdateTime(new Date(System.currentTimeMillis()));
        //翻译appToolNames
        usePowerFlow.setAppToolNames(getAppToolNamesByIds(usePowerFlow.getAppToolIds()));
        //提交后才获取申请人
        if(UsePowerFlow.STATUS_EXAMINATION.equals(usePowerFlow.getStatus())){
            usePowerFlow.setApplicant(sysUser.getUserId());
            usePowerFlow.setApplyTime(usePowerFlow.getUpdateTime());
        }
        //附件上传
        OptManual searchOptManual = new OptManual();
        searchOptManual.setAppToolId(usePowerFlow.getId());
        List<OptManual> optManualList = optManualService.findList(searchOptManual);
        List<OptManual> newOptManualList = usePowerFlow.getOptManualList();
        if (CollectionUtil.isNotEmpty(optManualList)) {
            if (CollectionUtil.isNotEmpty(newOptManualList)) {
                Map<String, OptManual> transMap = new HashMap<>(16);
                optManualList.stream().forEach(oldOptManual ->
                        transMap.put(oldOptManual.getFiles(), oldOptManual)
                );
                newOptManualList.stream().forEach(newOptManual -> {
                            OptManual optManual = transMap.get(newOptManual.getFiles());
                            if (null != optManual) {
                                transMap.remove(newOptManual.getFiles());
                            } else {
                                transMap.put(newOptManual.getFiles(), newOptManual);
                            }
                        }
                );
                if (CollectionUtil.isNotEmpty(transMap)) {
                    List<OptManual> tempOptManualList = new ArrayList<>();
                    transMap.forEach((key, value) -> {
                        if (StringUtils.isNotBlank(value.getId())) {
                            optManualService.removeById(value.getId());
                            optManualService.deleteManual(value);
                        } else {
                            tempOptManualList.add(value);
                        }
                    });
                    usePowerFlow.setOptManualList(tempOptManualList);
                } else {
                    usePowerFlow.setOptManualList(null);
                }
                if(usePowerFlow.getOptManualList()!=null && usePowerFlow.getOptManualList().size()>0){
                    //保存附件
                    usePowerFlow.getOptManualList().forEach(e->{
                        String fileName = e.getFileName();
                        if(StringUtils.isNotBlank(fileName)){
                            e.setExtType(fileName.substring(fileName.indexOf(".")+1,fileName.length()));
                            e.setBucketName(PortalConstants.MINIO_MARKET_BUCKET);
                            e.setCreateTime(now);
                            e.setUpdateTime(now);
                            e.setCreateBy(userId);
                            e.setUpdateBy(userId);
                            e.setAppToolId(flowId);
                        }
                    });
                    optManualService.saveBatch(usePowerFlow.getOptManualList());
                }
            } else {
                //附件为空，清空文件库相关文件
                optManualService.removeByMap(new HashMap<String, Object>(1) {{
                    put("APP_TOOL_ID", usePowerFlow.getId());
                }});
                OptManual optManual = new OptManual();
                optManual.setFiles(StringUtils.join(optManualList.stream().map(OptManual::getFiles).collect(Collectors.toList()), ","));
                optManualService.deleteManual(optManual);
            }
        }else{
            if(newOptManualList!=null && newOptManualList.size()>0){
                //保存附件
                usePowerFlow.getOptManualList().forEach(e->{
                    String fileName = e.getFileName();
                    if(StringUtils.isNotBlank(fileName)){
                        e.setExtType(fileName.substring(fileName.indexOf(".")+1,fileName.length()));
                        e.setBucketName(PortalConstants.MINIO_MARKET_BUCKET);
                        e.setCreateTime(now);
                        e.setUpdateTime(now);
                        e.setCreateBy(userId);
                        e.setUpdateBy(userId);
                        e.setAppToolId(flowId);
                    }
                });
                optManualService.saveBatch(usePowerFlow.getOptManualList());
            }
        }

        //保存授权信息
        savePowerBatchByIds(usePowerFlow.getAppToolIds(),userId,usePowerFlow.getBussType(),CommonConstants.STATUS_NORMAL);

        //更新记录
        return SqlHelper.delBool(this.baseMapper.updateById(usePowerFlow));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean deleteApply(String id) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        //删除附件
        //首先查询出该主题的所有操作手册
        List<OptManual> optManualList = optManualService.list(Wrappers.query(new OptManual()).eq(OptManual::getAppToolId, id));
        if (CollectionUtil.isNotEmpty(optManualList)) {
            optManualList.stream().forEach(optManual ->
                    //删除minio 中的文件
                    optManualService.deleteManual(optManual)
            );
        }
        //删除操作手册信息
        optManualService.remove(Wrappers.query(new OptManual()).eq(OptManual::getAppToolId, id));
        //删除记录
        UsePowerFlow usePowerFlow = new UsePowerFlow();
        usePowerFlow.setId(id);
        usePowerFlow.setUpdateTime(new Date(System.currentTimeMillis()));
        usePowerFlow.setUpdateBy(sysUser.getUserId());
        usePowerFlow.setDelFlag(CommonConstants.STATUS_DEL);

        //删除权限记录
        UsePowerFlow flow = getById(id);
        deletePowerByIds(flow.getAppToolIds(),sysUser.getUserId());

        return SqlHelper.delBool(this.baseMapper.updateById(usePowerFlow));
    }

    /**
     * 提交审批
     * @param usePowerFlow
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean approve(UsePowerFlow usePowerFlow) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        usePowerFlow.setUpdateBy(sysUser.getUserId());
        usePowerFlow.setUpdateTime(new Date(System.currentTimeMillis()));
        usePowerFlow.setApprover(usePowerFlow.getUpdateBy());
        usePowerFlow.setApprovalTime(usePowerFlow.getUpdateTime());
        //审批通过status='3'时，插入权限表
        if(UsePowerFlow.STATUS_SUCCESS.equals(usePowerFlow.getStatus())){
            savePowerBatchByIds(usePowerFlow.getAppToolIds(),usePowerFlow.getApplicant(),usePowerFlow.getBussType(),CommonConstants.STATUS_DEL);
        }else if(UsePowerFlow.STATUS_FAIL.equals(usePowerFlow.getStatus())){
            deletePowerByIds(usePowerFlow.getAppToolIds(),usePowerFlow.getApplicant());
        }
        return SqlHelper.delBool(this.baseMapper.updateById(usePowerFlow));
    }

    /**
     * 初始化参数
     * @param usePowerFlow
     * @return
     */
    private UsePowerFlow init(UsePowerFlow usePowerFlow){
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        usePowerFlow.setId(IdUtil.randomUUID());
        usePowerFlow.setCreateTime(new Date(System.currentTimeMillis()));
        usePowerFlow.setCreateBy(sysUser.getUserId());
        usePowerFlow.setUpdateTime(new Date(System.currentTimeMillis()));
        usePowerFlow.setUpdateBy(sysUser.getUserId());
        usePowerFlow.setDelFlag(CommonConstants.STATUS_NORMAL);
        usePowerFlow.setApplicant(sysUser.getUserId());
        if(UsePowerFlow.STATUS_EXAMINATION.equals(usePowerFlow.getStatus())){
            usePowerFlow.setApplyTime(usePowerFlow.getUpdateTime());
        }
        return usePowerFlow;
    }

    /**
     * 翻译应用工具名称集合
     * @param ids
     * @return
     */
    private String getAppToolNamesByIds(String ids){
        List<String> result = new ArrayList<>();
        String[] arr = ids.split(",");
        for (int i = 0; i < arr.length; i++) {
            AppTool appTool = appToolService.getById(arr[i]);
            result.add(appTool.getName());
        }
        return StringUtils.join(result," | ");
    }

    /**
     * 批量保存授权
     * @param ids
     * @param userid
     * @param bussType
     * @param status
     */
    private void savePowerBatchByIds(String ids,String userid,String bussType,String status){
        String[] arrs = ids.split(",");
        List<AppToolPower> list = new ArrayList<>();
        for (String id : arrs) {
            AppToolPower appToolPower = new AppToolPower();
            appToolPower.setAppToolId(id);
            appToolPower.setUserId(userid);
            appToolPower.setType(bussType);
            appToolPower.setStatus(status);
            appToolPower.setSort(CommonConstants.STATUS_NORMAL);
            appToolPower.setCollector(CommonConstants.STATUS_DEL);
            appToolPower.setShowHide(CommonConstants.STATUS_NORMAL);
            list.add(appToolPower);
        }
        appToolPowerService.saveByFlow(list);
    }

    /**
     * 批量删除权限信息
     * @param ids
     * @param userId
     */
    @Transactional(readOnly = true)
    private void deletePowerByIds(String ids,String userId){
        //删除权限记录
        String[] array = ids.split(",");
        for (String s : array){
            appToolPowerService.removeByMap(new HashMap<String, Object>(1) {{
                put("user_id", userId);
                put("app_tool_id",s);
                put("status",CommonConstants.STATUS_NORMAL);
            }});
        }
    }

}
