package com.cloud.portal.market.apptool.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.apptool.mapper.AppToolUseMapper;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.AppToolUse;
import com.cloud.portal.market.apptool.service.AppToolUseService;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/24 9:13
 * @description:
 * @modified By:maojia
 */
@Service
public class AppToolUseServiceImpl extends ServiceImpl<AppToolUseMapper, AppToolUse> implements AppToolUseService {


    @Override
    public boolean mergeAppToolUse(String appToolId, String type) {
        if (StringUtils.isNotBlank(appToolId) && StringUtils.isNotBlank(type)) {
            AppToolUse appToolUse = new AppToolUse();
            appToolUse.setUserId(SecurityUtils.getUser().getId());
            appToolUse.setAppToolId(appToolId);
            appToolUse.setType(type);
            return SqlHelper.delBool(this.baseMapper.mergeAppToolUse(appToolUse));
        }
        return false;
    }

    @Override
    public List<AppTool> getUseList(AppToolUse appToolUse) {
        MicroUser user = SecurityUtils.getUser();
        appToolUse.setUserId(user.getId());
        return baseMapper.getUseList(appToolUse);
    }
}
