package com.cloud.portal.market.work.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchLink;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:49
 * @description:个人工作台关联信息
 * @modified By:liuwei
 */
public interface BenchLinkService extends IService<BenchLink> {
    /**
     * 查询该工作台组件关联信息
     * @param bench
     * @return
     */
    List<BenchLink> findBenchLink(Bench bench);

    /**
     * 查询该工作台左边组件关联信息
     * @param bench
     * @return
     */
    List<BenchLink> findLeftBenchLink(Bench bench);

    /**
     * 查询该工作台左边组件关联信息
     * @param bench
     * @return
     */
    List<BenchLink> findRightBenchLink(Bench bench);

    /**
     * 删除
     * @param workBenchId
     * @return
     */
    boolean deleteByBenchId(String workBenchId);

    /**
     * 查询该工作台所有组件信息
     * @param bench
     * @return
     */
    List<BenchLink> findLinkById(Bench bench);
}
