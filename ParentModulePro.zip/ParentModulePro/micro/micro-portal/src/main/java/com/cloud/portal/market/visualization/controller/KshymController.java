package com.cloud.portal.market.visualization.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.visualization.entity.Kshym;
import com.cloud.portal.market.visualization.service.KshymService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * @author maojia
 * @date Created in 2020/4/13 11:15
 * @description:
 * @modified By:maojia
 */
@RestController
@RequestMapping("/market/visualization")
public class KshymController {
    @Autowired
    KshymService kshymService;

    @GetMapping("/page")
    @SysLog("查询列表（分页）")
    public R findListPage(Page page, Kshym kshym){
        return new R<>( kshymService.findListPage(page,kshym));
    }

    @GetMapping("/{id}")
    @SysLog("根据id查询")
    public R findListById(@PathVariable String id){
        return new R(kshymService.findListById(id));
    }

    @GetMapping("/list")
    @SysLog("查询列表")
    public R findList(){
        return new R<>(kshymService.findList("all_"));
    }

    @SysLog(value = "新增",type = CommonConstants.LOG_ADD)
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.KSHYM_CACHE_NAME, allEntries = true)
    @PostMapping("/save")
    public R save(@RequestBody Kshym kshym,String sort){
        kshym.setMxdz("http://68.26.21.40:9777/api/custom_sso/acs?domain=gdga&user_info=%7B%22username%22:%22321324198608201070%22%7D&token=1f31e1a52cf850662903a81027fe9e73&RelayState=embed/dashboard.html?dashId="+kshym.getMxdz());
        kshym.setCreatedate(LocalDateTime.now());
        kshym.setUpdatetime(LocalDateTime.now());
        return new R<>(kshymService.save(kshym));

    }

    @SysLog(value = "修改",type = CommonConstants.LOG_EDIT)
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.KSHYM_CACHE_NAME, allEntries = true)
    @PutMapping("/update")
    public R updateById(@RequestBody Kshym kshym,String sort){
        kshym.setUpdatetime(LocalDateTime.now());
        return new R<>(kshymService.updateById(kshym));

    }

    @SysLog(value = "根据id删除",type = CommonConstants.LOG_DELELE)
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.KSHYM_CACHE_NAME, allEntries = true)
    @DeleteMapping("/del/{id}")
    public R removeById(@PathVariable String id){
            return new R<>(kshymService.removeById(id));
    }


    /**
     * 根据排序查看
     * @param sort
     * @return
     */
    @GetMapping("findBySort/{sort}")
    @SysLog(value = "查询是否重复",type = CommonConstants.LOG_LOGIN)
    public R findBySort(@PathVariable String sort) {
        Kshym kshym = new Kshym();
        kshym.setSort(sort);
        return new R<>(kshymService.getOne(new QueryWrapper<>(kshym)));
    }

    /**
     * 根据模型名称查看
     * @param mxmc
     * @return
     */
    @GetMapping("findByMxmc/{mxmc}")
    @SysLog(value = "查询是否重复")
    public R findByMxmc(@PathVariable String mxmc) {
        Kshym kshym = new Kshym();
        kshym.setMxmc(mxmc);
        return new R<>(kshymService.getOne(new QueryWrapper<>(kshym)));
    }
}
