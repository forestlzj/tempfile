package com.cloud.portal.market.services.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author chenchunl
 * @date Created in 2020/4/9 11:59
 * @description:
 * @modified By:chenchunl
 */
@Data
@TableName("t_portal_service_file")
@EqualsAndHashCode(callSuper = true)
public class ServiceFile extends Model<ServiceFile> {

    /**
     * 主键ID
     */
    @TableId(type = IdType.UUID)
    private String id;
    /**
     * 公司ID
     */
    private String companyId;
    /**
     * 服务ID
     */
    private String serviceId;
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 文件大小(B)
     */
    private String fileLen;
    /**
     * 文件扩展名
     */
    private String extType;
    /**
     * 下载次数
     */
    private int downloadNum;
    /**
     * 文件
     */
    private String files;
    /**
     * 创建时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * MINIO桶名
     */
    private String bucketName;
}
