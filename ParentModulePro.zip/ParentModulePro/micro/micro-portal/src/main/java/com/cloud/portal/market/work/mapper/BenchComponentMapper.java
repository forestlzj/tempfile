package com.cloud.portal.market.work.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchComponent;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/8 14:58
 * @description:个人工作台组件信息
 * @modified By:liuwei
 */
public interface BenchComponentMapper extends BaseMapper<BenchComponent> {
    /**
     * 获取组件信息
     *
     * @param page
     * @param benchComponent
     * @return
     */
    IPage<BenchComponent> findListPage(IPage<BenchComponent> page, @Param("benchComponent") BenchComponent benchComponent);

    /**
     * 获取组件信息
     *
     * @param page
     * @param benchComponent
     * @return
     */
    IPage<BenchComponent> findQueryPage(IPage<BenchComponent> page, @Param("benchComponent") BenchComponent benchComponent);

    /**
     * 更新删除标识
     * @param list
     * @return
     */
    boolean updateDel(List<String> list);

    /**
     * 查询工作台可以添加的组件信息
     * @param bench
     * @return
     */
    List<BenchComponent> findByBenchId(@Param("bench")Bench bench);

    /**
     * 查询该工作台的组件信息
     * @param bench
     * @return
     */
    List<BenchComponent> findBenchComponent(@Param("bench")Bench bench);

    /**
     * 查询工作台所有组件信息
     * @return
     */
    List<BenchComponent> findAll();

    /**
     * 根据value查询组件信息
     * @param benchComponent
     * @return
     */
    BenchComponent findByValue(@Param("benchComponent")BenchComponent benchComponent);


}
