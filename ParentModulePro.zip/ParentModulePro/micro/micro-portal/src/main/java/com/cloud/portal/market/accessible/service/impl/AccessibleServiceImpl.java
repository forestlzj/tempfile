package com.cloud.portal.market.accessible.service.impl;

import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.accessible.entity.ServiceFlowInfo;
import com.cloud.portal.market.accessible.mapper.AccessibleMapper;
import com.cloud.portal.market.accessible.service.AccessibleService;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.apptool.service.OptManualService;
import com.google.common.base.Strings;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

/**
 * @author chenchunl
 * @date Created in 2020/3/23 14:56
 * @description:
 * @modified By:chenchunl
 */

@Service
public class AccessibleServiceImpl extends ServiceImpl<AccessibleMapper, ServiceFlowInfo> implements AccessibleService {

    @Autowired
    private OptManualService optManualService;

    @Override
    public IPage page(Page page, ServiceFlowInfo serviceFlowInfo) {
    /*    if(!"0".equals(serviceFlowInfo.getIsMyself()) && !"null".equals(serviceFlowInfo.getIsMyself())){
            serviceFlowInfo.setApplicant(SecurityUtils.getUser().getId());
        }
        String userId = SecurityUtils.getUser().getId();
        serviceFlowInfo.setApplicant(userId);*/
        //判断是否是管理员  不是管理员只能查自己的申请记录
        if(!SecurityUtils.getUser().isAdmin()){
            serviceFlowInfo.setApplicant(SecurityUtils.getUser().getId());
        }
        return this.baseMapper.findPage(page, serviceFlowInfo);
    }

    @Override
    public IPage auditPage(Page page, ServiceFlowInfo serviceFlowInfo) {
        return this.baseMapper.findauditPage(page, serviceFlowInfo);
    }

    @Override
    public R removeApply(String id) {

        Date date = new Date();
        ServiceFlowInfo serviceFlowInfo = new ServiceFlowInfo();
        serviceFlowInfo.setId(id);
        serviceFlowInfo.setUpdateTime(date);
        serviceFlowInfo.setUpdateBy(SecurityUtils.getUser().getId());
        serviceFlowInfo.setDelFlag(CommonConstants.STATUS_DEL);
        return new R<>( super.updateById(serviceFlowInfo)) ;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public R applyInfoSave(ServiceFlowInfo serviceFlowInfo) {
        Date date = Calendar.getInstance().getTime();
        serviceFlowInfo.setId(IdUtil.randomUUID());
        serviceFlowInfo.setApplicant(SecurityUtils.getUser().getId());
        if(!"0".equals(serviceFlowInfo.getStatus())){
            serviceFlowInfo.setApplyTime(new Date());
        }
        serviceFlowInfo.setDelFlag(CommonConstants.STATUS_NORMAL);
        serviceFlowInfo.setCreateTime(date);
        serviceFlowInfo.setUpdateTime(date);

        List<OptManual> optManualList = serviceFlowInfo.getOptManualList();
        //添加附件信息
        addFile(serviceFlowInfo.getId(),optManualList);

        return new R<>(this.save(serviceFlowInfo));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public R updateApplyInfo(ServiceFlowInfo serviceFlowInfo) {
        Date now = Calendar.getInstance().getTime();
        String userId = SecurityUtils.getUser().getId();

        //添加附件信息
        addFile(serviceFlowInfo.getId(), serviceFlowInfo.getOptManualList());

        serviceFlowInfo.setUpdateTime(now);
        serviceFlowInfo.setUpdateBy(userId);
        //状态为驳回时  再次提交
        if("1".equals(serviceFlowInfo.getStatus())){
            serviceFlowInfo.setStatus("2");
            serviceFlowInfo.setApprover("");
            serviceFlowInfo.setApprovalTime(null);
            serviceFlowInfo.setOpinion("");
        }

        return new R<>( this.updateById(serviceFlowInfo));
    }

    @Override
    public R submitApplyInfo(String id) {

        ServiceFlowInfo serviceFlowInfo = new ServiceFlowInfo();
        serviceFlowInfo.setId(id);
        Date date = new Date();
        String userId = SecurityUtils.getUser().getId();
        serviceFlowInfo.setStatus("2");
        serviceFlowInfo.setUpdateBy(userId);
        serviceFlowInfo.setCreateBy(userId);
        serviceFlowInfo.setApplyTime(date);
        serviceFlowInfo.setUpdateTime(date);

        return new R<>( this.updateById(serviceFlowInfo));
    }

    @Override
    public R auditApplyInfo(ServiceFlowInfo serviceFlowInfo) {
        Date now = new Date();
        String userId = SecurityUtils.getUser().getId();
        serviceFlowInfo.setApprover(userId);
        serviceFlowInfo.setApprovalTime(now);
        serviceFlowInfo.setUpdateTime(now);
        serviceFlowInfo.setUpdateBy(userId);

        return new R<>( this.updateById(serviceFlowInfo));
    }

    @Override
    public R getServiceInterfaceById(String id) {

        return R.ok(this.baseMapper.findServiceInterface(id));
    }

    @Override
    public R again(ServiceFlowInfo serviceFlowInfo) {

        Date date = new Date();
        String userId = SecurityUtils.getUser().getId();
        if(StringUtils.isNotBlank(serviceFlowInfo.getId())){
            //添加附件信息
            addFile(serviceFlowInfo.getId(),serviceFlowInfo.getOptManualList());

            serviceFlowInfo.setUpdateTime(date);
            serviceFlowInfo.setStatus("2");
            serviceFlowInfo.setUpdateBy(userId);
            serviceFlowInfo.setApplyTime(date);
            serviceFlowInfo.setUpdateTime(date);
            return new R<>( this.updateById(serviceFlowInfo));
        }else {
            serviceFlowInfo.setId(IdUtil.randomUUID());
            serviceFlowInfo.setApplicant(userId);
            serviceFlowInfo.setStatus("0");
            serviceFlowInfo.setDelFlag(CommonConstants.STATUS_NORMAL);
            serviceFlowInfo.setCreateTime(date);
            serviceFlowInfo.setUpdateTime(date);
            //添加附件信息
            addFile(serviceFlowInfo.getId(),serviceFlowInfo.getOptManualList());

            return new R<>(this.save(serviceFlowInfo));
        }
    }

    @Override
    public List<ServiceFlowInfo> findListByService(ServiceFlowInfo serviceFlowInfo) {

        String[] split = serviceFlowInfo.getServiceIds().split(",");
        ArrayList<String> list = new ArrayList<String>(Arrays.asList(split)) ;
        serviceFlowInfo.setServiceIdsList(list);
        serviceFlowInfo.setApplicant(SecurityUtils.getUser().getId());
        return  this.baseMapper.findListByService(serviceFlowInfo);
    }

    /**
     * 添加附件
     * @param id
     * @param optManualList
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean addFile(String id, List<OptManual> optManualList ){
        Date date = new Date();
        String userId = SecurityUtils.getUser().getId();

        if(StringUtils.isNotBlank(id)){
            //删除文件信息
            this.baseMapper.optManualByAppToolId(id);
        }

        //插入文件信息
        if (optManualList != null && optManualList.size() > 0){
            optManualList.stream().forEach(m ->{
                String fileName = m.getFileName();
                m.setId(IdUtil.randomUUID());
                m.setAppToolId(id);
                m.setCreateTime(date);
                m.setUpdateTime(date);
                m.setUpdateBy(userId);
                m.setCreateBy(userId);
                m.setBucketName(PortalConstants.MINIO_MARKET_BUCKET);
                m.setExtType(fileName.substring(fileName.lastIndexOf(".") + 1,fileName.length()));
            });
        }

        return optManualService.saveBatch(optManualList);
    }

}

