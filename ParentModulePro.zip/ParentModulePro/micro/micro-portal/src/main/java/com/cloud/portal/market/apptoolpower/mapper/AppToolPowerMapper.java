package com.cloud.portal.market.apptoolpower.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.apptoolpower.model.AppToolPowerVo;
import org.apache.ibatis.annotations.Param;
import com.cloud.portal.market.apptoolpower.model.AppToolPower;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/3/31 10:05
 * @description:应用工具权限分配
 * @modified By:liuwei
 */
public interface AppToolPowerMapper  extends BaseMapper<AppToolPower> {
    /**
     * 获取用户权限
     * @param appToolPower
     * @return
     */
   List<AppToolPower> findList(@Param("appToolPower")AppToolPower appToolPower);

    /**
     * 删除用户权限
     * @param userId
     * @return
     */
    int deleteByUserId(@Param("userId")String userId);

    /**
     * 获取每个用户的工具应用数
     * @param page
     * @param appToolPowerVo
     * @return
     */
    IPage<List<AppToolPowerVo>> getToolAppNum(IPage<AppToolPowerVo> page, @Param("appToolPowerVo") AppToolPowerVo appToolPowerVo);

    /**
     * 校验应用工具集合当前用户是否有授权
     * @param ids
     * @param userId
     * @param status
     * @return
     */
    List<String> exists(@Param("ids")List<String> ids,@Param("userId")String userId,@Param("status") String status);

    /**
     * 通过申请流程批量保存权限记录
     * @param appToolPowerList
     * @return
     */
    int saveByFlow(@Param("appToolPowerList")List<AppToolPower> appToolPowerList);

    /**
     * 通过申请流程批量保存权限记录
     * @param appToolPower
     * @return
     */
    int updateUserAppToolById(AppToolPower appToolPower);

}
