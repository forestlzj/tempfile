

package com.cloud.portal.common.constant;

/**
 * @author ygnet
 * @date 2017/10/29
 */
public interface PortalConstants {


    /**
     * 所有行政区划缓存key值
     */
    String TYJG_CACHE_KEY = "all_tyjg";

    /**
     * 研判模型菜单类型-标题
     */
    String MODEL_MENU_TYPE_TITLE = "1";

    /**
     * 研判模型菜单类型-目录
     */
    String MODEL_MENU_TYPE_DIR = "2";
    /**
     * 所有研判模型菜单缓存key值
     */
    String ALL_MODEL_MENU_CACHE_KEY = "all_modelMenu";

    /**
     * 研判模型菜单类型-模型
     */
    String MODEL_MENU_TYPE_MODEL = "3";

    /**
     * 研判模型 图片缓存值
     */
    String MODEL_MENU_ICON = "model_icon";

    /**
     * 综合查询请求方式
     * 业务表方式
     */
    String SEARCH_TYPE_TABLE = "0";
    /**
     * 综合查询rest请求方式
     * 接口请求方式
     */
    String SEARCH_TYPE_REST_API = "1";
    /**
     * 综合查询-查询方案缓存key值
     */
    String SEARCH_SCHEME_CACHE_KEY = "searchScheme_details";

    /**
     * minio 超市桶名称
     */
    String MINIO_MARKET_BUCKET="market";

    /**
     * minio 开发公司图标名称
     */
    String MINIO_COMPANY_ICON="company";

    /**
     * minio 服务接口图标名称
     */
    String MINIO_SERVICE_BUCKET="service";

    /**
     * minio 服务接口通知桶名称
     */
    String MINIO_NOTIFY_BUCKET="notify";
    /**
     * minio 开发公司图标名称
     */
    String MINIO_EMPLOYEE_AVATAR="employee";
    /**
     * minio 留言板图片名称
     */
    String MINIO_MESSAGE_BOARD="messageboard";
}
