package com.cloud.portal.market.common.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.portal.market.common.model.OperateLog;
import com.cloud.portal.market.common.model.UseMonitor;
import org.apache.ibatis.annotations.Param;

/**
 * @author wengshij
 * @date Created in 2020/4/21 11:26
 * @description:
 * @modified By:ryt
 * @modifieDescription: 数据、服务操作监控统计
 */
public interface OperateLogMapper extends BaseMapper<OperateLog> {

    /**
     * 获取操作日志分页信息
     *
     * @param page
     * @param operateLog
     * @return
     */
    IPage<OperateLog> getListPage(IPage<OperateLog> page, @Param("query") OperateLog operateLog);

    /**
     * 数据、服务操作监控统计
     *
     * @param page
     * @param useMonitor
     * @return
     */
    IPage<UseMonitor> getUseMonitorList(IPage<UseMonitor> page, @Param("query") UseMonitor useMonitor);


    /**
     * 数据、服务操作监控统计--获取操作失败、异常日志信息
     *
     * @param page
     * @param operateLog
     * @return
     */
    IPage<OperateLog> getFailLogList(IPage<OperateLog> page, @Param("query") OperateLog operateLog);

}
