package com.cloud.portal.inforelease.message.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.inforelease.message.model.MessageBoard;
import com.cloud.portal.inforelease.message.model.MessageBoardPraise;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

/**
 * @author rush
 * @Date Created in 2020/3/12 15:27
 * Description:
 * Modified By:
 */
public interface MessageBoardService extends IService<MessageBoard> {
    /**
     * 添加留言信息
     *
     * @param messageBoard
     * @return
     */
    boolean saveMessageBoard(MessageBoard messageBoard);

    /**
     * 获取留言列表信息（管理员权限） 
     *
     * @param page
     * @param messageBoard
     * @return
     */
    IPage<MessageBoard> getListPage(IPage<MessageBoard> page, MessageBoard messageBoard);

    /**
     * 删除主贴并删除回复和个人回复
     *
     * @param id
     * @return
     */
    boolean removeById(String id);

    /**
     * 根据ID查询留言并关联用户信息
     *
     * @param id
     * @return MessageBoard
     */
    MessageBoard getMessageBoardById(String id);

    /**
     * 上传图片信息
     *
     * @param file
     * @return
     * @throws Exception
     */
    R uploadPic(MultipartFile file) throws Exception;

    /**
     * 下载图片
     *
     * @param base64Id
     * @return
     */
    InputStream downLoadPic(String base64Id);

    /**
     * 留言板点赞
     * @param  messageBoardPraise
     * @return
     */
    boolean savePraise(MessageBoardPraise messageBoardPraise);

    /**
     * 取消留言板点赞
     * @param boardId 留言板id
     * @return
     */
    boolean deletePraise(String boardId);

}
