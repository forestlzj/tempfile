package com.cloud.portal.market.catalog.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.catalog.model.Catalog;

import java.util.List;

/**
 * @author huangyingx
 * @date Created in 2020/3/10 16:54
 * @description: 目录编排service接口
 * @modified By: huangyingx
 */
public interface CatalogService extends IService<Catalog> {

    /**
     * 根据类型获取列表
     * @param type
     * @return
     */
    List<Catalog> findListByType(String type);

    /**
     * 根据id删除记录，delFlag = '1'
     * @param id
     * @return
     */
    int deleteById(String id);

    /**
     * 更新目录信息
     * @param catalog
     * @return
     */
    int updateCatalog(Catalog catalog);

    /**
     * 插入目录信息
     * @param entity
     * @return
     */
    int saveCatalog(Catalog entity);

    /**
     * 根据id获取记录
     * @param id
     * @return
     */
    Catalog findById(String id);

    /**
     * 同级目录是否已存在
     * @param catalog
     * @return
     */
    boolean hasExistCatalog(Catalog catalog);

    /**
     * 保存子级排序
     * @param list
     * @return
     */
    int saveSort(List<Catalog> list);

}
