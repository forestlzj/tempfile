package com.cloud.portal.market.company.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.util.IdUtil;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.data.datascope.DataScope;
import com.cloud.common.data.util.DataScopeUtil;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.judged.instruction.model.Instruction;
import com.cloud.portal.market.apptool.model.AppTool;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.common.constant.MarketConstants;
import com.cloud.portal.market.company.mapper.CompanyEmployeeMapper;
import com.cloud.portal.market.company.mapper.CompanyMapper;
import com.cloud.portal.market.company.model.Company;
import com.cloud.portal.market.company.service.CompanyEmployeeService;
import com.cloud.portal.market.company.service.CompanyService;
import lombok.AllArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;


/**
 * @author liuwei
 * @date Created in 2020/3/12 9:11
 * @description: 开发公司接口实现层
 * @modified By:liuwei
 */
@Service
@AllArgsConstructor
public class CompanyServiceImpl extends ServiceImpl<CompanyMapper, Company> implements CompanyService {

    /**
     * minio 接口服务信息
     */
    @Autowired
    private MinioTemplate minioTemplate;
    @Autowired
    private CompanyEmployeeService companyEmployeeService;

    /**
     * 查询列表（分页）
     * @param page
     * @param company
     * @return
     */
   @Override
    public IPage<List<Company>> page(IPage<Company> page, Company company) {
        return this.baseMapper.findListPage(page,company);
    }

    @Override
    public R deleteIcon(String base64Id) {
        try {
            minioTemplate.removeObject(PortalConstants.MINIO_COMPANY_ICON, Base64.decodeStr(base64Id));
        } catch (Exception e) {
            e.printStackTrace();
            return R.failed();
        }
        return R.ok();
    }

    @Override

    public R uploadIcon(MultipartFile file) throws Exception {
        StringBuffer nameBuffer = new StringBuffer();
        Map<String, String> result = new HashMap<>(2);
        minioTemplate.createBucket(PortalConstants.MINIO_COMPANY_ICON);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String fileName = file.getOriginalFilename();
        result.put("name", fileName);
        String newFileName = IdUtil.randomUUID() + fileName.substring(fileName.lastIndexOf("."));
        nameBuffer.append("icon").append("/")
                .append(SecurityUtils.getUser().getId()).append("/")
                .append(sdf.format(System.currentTimeMillis())).append("/")
                .append(newFileName);
        minioTemplate.putObject(PortalConstants.MINIO_COMPANY_ICON, nameBuffer.toString(), file.getInputStream());
        String baseId = Base64.encode(nameBuffer.toString());
        result.put("baseId", baseId);
        result.put("url", "portal/comp/company/getIcon/" + baseId);
        return R.ok(result);
    }

    @Override
    public InputStream downLoadIcon(String base64Id) {
        String fileName = Base64.decodeStr(base64Id);
        InputStream inputStream = minioTemplate.getObject(PortalConstants.MINIO_COMPANY_ICON, fileName);
        return inputStream;
    }



    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.COMPANY_CACHE_NAME, allEntries = true)
    public boolean saveCompany(Company company) {
        company = paramsInit(company);
        return SqlHelper.delBool(this.baseMapper.insert(company));
    }

    private Company paramsInit(Company company) {
        MicroUser user = SecurityUtils.getUser();
        company.setId(IdUtil.randomUUID());
        company.setCreateBy(user.getId());
        company.setUpdateBy(user.getId());
        company.setDelFlag(CommonConstants.STATUS_NORMAL);
        company.setCreateTime(new Date(System.currentTimeMillis()));
        company.setUpdateTime(company.getCreateTime());
        return company;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.COMPANY_CACHE_NAME, allEntries = true)
    public boolean updateCompany(Company company) {
        company = initCompany(company);
        return SqlHelper.delBool(this.baseMapper.updateById(company));
    }

    private Company initCompany(Company company) {
        //获得更新前数据
        Company beforeCompany = this.getById(company.getId());
        //判断两个图标是否相同
        if(beforeCompany.getIcon()!=null) {
            if (!beforeCompany.getIcon().equals(company.getIcon())) {
                this.deleteIcon(beforeCompany.getIcon());
            }
        }

        MicroUser microUser = SecurityUtils.getUser();
        company.setUpdateTime(new Date(System.currentTimeMillis()));
        company.setUpdateBy(microUser.getId());
        company.setDelFlag(CommonConstants.STATUS_NORMAL);
        return company;

    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    @CacheEvict(value = MarketConstants.COMPANY_CACHE_NAME, allEntries = true)
    public boolean updateDel(List<String> list){
        try{
            this.companyEmployeeService.updateDelById(list);
            this.baseMapper.updateDel(list);
        }catch (Exception e){
            e.printStackTrace();
            return false;
        }
         return true;
    }
    @Override
    @Cacheable(value = MarketConstants.COMPANY_CACHE_NAME,key = "#all")
    public  List<Company> findList(String all){
        return this.baseMapper.selectList(Wrappers.query());
    }

    @Override
    public Company getAllById(String id) {
        return this.baseMapper.getAllById(id);
    }


}