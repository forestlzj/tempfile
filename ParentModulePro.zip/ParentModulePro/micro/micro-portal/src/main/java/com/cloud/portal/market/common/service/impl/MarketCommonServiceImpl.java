package com.cloud.portal.market.common.service.impl;

import com.cloud.admin.api.vo.TreeUtil;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.catalog.service.CatalogService;
import com.cloud.portal.market.common.model.TagCatalogTree;
import com.cloud.portal.market.common.service.MarketCommonService;
import com.cloud.portal.market.tag.service.TagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author wengshij
 * @date Created in 2020/4/1 13:40
 * @description:
 * @modified By:wengshij
 */
@Service
public class MarketCommonServiceImpl implements MarketCommonService {

    @Autowired
    private TagService tagService;

    @Autowired
    private CatalogService catalogService;


    private TagCatalogTree getTag(String tagType) {
        TagCatalogTree firstTag = new TagCatalogTree();
        firstTag.setKey("tag");
        firstTag.setType("tag");
        firstTag.setName("标签");
        firstTag.setId("tag");
        firstTag.setMultiple(Boolean.TRUE);
        tagService.findListByType(tagType).stream().forEach(tag -> {
            TagCatalogTree secondTag = new TagCatalogTree();
            secondTag.setId(tag.getId());
            secondTag.setKey("tag");
            secondTag.setType("tag");
            secondTag.setName(tag.getLabel());
            secondTag.setMultiple(Boolean.TRUE);
            secondTag.setParentId(firstTag.getId());
            firstTag.add(secondTag);
        });
        return firstTag;
    }

    private List<TagCatalogTree> getCatalog(String catalogType) {
        List<TagCatalogTree> catalogTree = TreeUtil.bulid(catalogService.findListByType(catalogType).stream().map(catalog -> {
            TagCatalogTree tagCatalogTree = new TagCatalogTree();
            tagCatalogTree.setParentId(catalog.getParentId());
            tagCatalogTree.setId(catalog.getId());
            tagCatalogTree.setName(catalog.getName());
            tagCatalogTree.setType("catalog");
            tagCatalogTree.setKey("catalog");
            return tagCatalogTree;
        }).collect(Collectors.toList()), "0");
        return catalogTree;
    }

    @Override
    public R getTagCatalog(String tagType, String catalogType, String choose) {
        List<TagCatalogTree> tagCatalogTreeList = new ArrayList<>();
        switch (choose) {
            case "tag":
                tagCatalogTreeList.add(getTag(tagType));
                break;
            case "catalog":
                tagCatalogTreeList.addAll(getCatalog(catalogType));
                break;
            case "both":
                tagCatalogTreeList.addAll(getCatalog(catalogType));
                tagCatalogTreeList.add(getTag(tagType));
                break;
            default:
        }
        return R.ok(tagCatalogTreeList);
    }
}
