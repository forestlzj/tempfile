package com.cloud.portal.judged.instruction.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.judged.instruction.model.Instruction;

import java.util.List;
import java.util.Map;


/**
 * @author Molly
 * @date Created in 2019/6/24
 * @description: 智能预警-指令service接口
 * @modified By: Molly
 * */
public interface InstructionService extends IService<Instruction> {

    /**
     * 查询列表（分页）
     * @param page
     * @param instruction
     * @return
     */
    IPage<List<Instruction>> page(IPage<Instruction> page, Instruction instruction);

    /**
     * 查询超时反馈指令（分页）
     * @param page
     * @param instruction
     * @return
     */
    IPage<List<Instruction>> findOvertimeListPage(IPage<Instruction> page,Instruction instruction);

    /**
     * 查询当前用户发布的指令列表（分页）
     * @param page
     * @param instruction
     * @return
     */
    IPage<List<Instruction>> findCurrentUserSendListPage(IPage<Instruction> page,Instruction instruction);

    /**
     * 根据id更新指令状态
     * @param instruction
     * @return
     */
    boolean updateStatus(Instruction instruction);

    /**
     * 统计当天预警数
     * @param instruction
     * @return
     */
    List<Map<String,Object>> totalByToday(Instruction instruction);

    /**
     * 保存自动指令
     * @param instruction
     * @return
     */
    boolean saveAutoInstruction(Instruction instruction);

    /**
     * 更新社区警务返回的id
     * @param id
     * @param sqjwId
     * @return
     */
    boolean updateSqjwId(String id,String sqjwId);


}
