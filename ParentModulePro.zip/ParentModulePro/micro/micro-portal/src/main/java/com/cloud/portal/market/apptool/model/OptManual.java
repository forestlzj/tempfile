package com.cloud.portal.market.apptool.model;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;

/**
 * @author wengshij
 * @date Created in 2020/3/13 10:03
 * @description: 应用工具操作手册信息
 * @modified By:wengshij
 */
@Data
@TableName("T_PORTAL_APP_OPERATION_MANUAL")
@EqualsAndHashCode(callSuper = true)
public class OptManual extends Model<OptManual> {
    /**
     * 主键ID
     */
    @TableId(type = IdType.UUID)
    private String id;
    /**
     * 公司ID
     */
    private String companyId;
    /**
     * 应用工具ID
     */
    private String appToolId;
    /**
     * 文件名称
     */
    private String fileName;
    /**
     * 文件大小(B)
     */
    private String fileLen;
    /**
     * 文件扩展名
     */
    private String extType;
    /**
     * 下载次数
     */
    private int downloadNum;
    /**
     * 文件
     */
    private String files;
    /**
     * 创建时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date createTime;
    /**
     * 更新时间
     */
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone = "GMT+8")
    private Date updateTime;
    /**
     * 创建者
     */
    private String createBy;
    /**
     * 更新者
     */
    private String updateBy;
    /**
     * MINIO桶名
     */
    private String bucketName;

}
