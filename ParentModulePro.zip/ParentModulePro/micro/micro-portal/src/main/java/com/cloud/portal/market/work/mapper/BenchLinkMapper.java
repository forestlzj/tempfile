package com.cloud.portal.market.work.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchComponent;
import com.cloud.portal.market.work.model.BenchLink;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/9 16:46
 * @description:个人工作台关联信息
 * @modified By:liuwei
 */
public interface BenchLinkMapper extends BaseMapper<BenchLink> {
    /**
     * 查询该工作台组件关联信息
     * @param bench
     * @return
     */
    List<BenchLink> findBenchLink(@Param("bench")Bench bench);

    /**
     * 查询该工作台组件关联信息
     * @param bench
     * @return
     */
    List<BenchLink> findLeftBenchLink(@Param("bench")Bench bench);

    /**
     * 查询该工作台组件关联信息
     * @param bench
     * @return
     */
    List<BenchLink> findRightBenchLink(@Param("bench")Bench bench);

    /**
     * 删除
     * @param workBenchId
     * @return
     */
    boolean deleteByBenchId(@Param("workBenchId")String workBenchId);

    /**
     * 查询该工作台所有组件信息
     * @param bench
     * @return
     */
    List<BenchLink> findLinkById(@Param("bench")Bench bench);
}
