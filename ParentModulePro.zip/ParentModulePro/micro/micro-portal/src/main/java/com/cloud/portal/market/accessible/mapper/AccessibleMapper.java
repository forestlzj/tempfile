package com.cloud.portal.market.accessible.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.portal.market.accessible.entity.ServiceFlowInfo;
import com.cloud.portal.market.accessible.entity.ServiceFlowInfoVO;
import com.cloud.portal.market.services.entity.ServiceInterface;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * @author chenchunl
 * @date Created in 2020/3/23 15:25
 * @description:
 * @modified By:chenchunl
 */
public interface AccessibleMapper extends BaseMapper<ServiceFlowInfo> {

    IPage<ServiceFlowInfoVO> findPage(Page<ServiceFlowInfo> page, @Param("queryCondition")ServiceFlowInfo serviceFlowInfo);

    IPage<ServiceFlowInfoVO> findauditPage(Page<ServiceFlowInfo> page, @Param("queryCondition")ServiceFlowInfo serviceFlowInfo);

    /**
     * 通过工具id删除文件信息
     * @param id
     * @return
     */
    boolean optManualByAppToolId(String id);

    List<ServiceInterface> findServiceInterface(@Param("id") String id);

    List<ServiceFlowInfo> findListByService(@Param("queryCondition") ServiceFlowInfo serviceFlowInfo);
}
