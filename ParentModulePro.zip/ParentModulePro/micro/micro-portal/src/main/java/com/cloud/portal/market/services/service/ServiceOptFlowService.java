package com.cloud.portal.market.services.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.common.core.util.R;
import com.cloud.portal.market.services.entity.ServiceOptFlow;

/**
 * @author chenchunl
 * @date Created in 2020/4/13 9:41
 * @description:
 * @modified By:chenchunl
 */
public interface ServiceOptFlowService extends IService<ServiceOptFlow> {

    /**
     * 分页查询服务接口上下架操作申请记录
     * @param page
     * @param serviceOptFlow
     * @return
     */
    IPage findPage(Page page, ServiceOptFlow serviceOptFlow);

    /**
     * 保存服务接口申请
     * @param serviceOptFlow
     * @return
     */
    boolean saveServiceOptFlow(ServiceOptFlow serviceOptFlow);

    /**
     * 修改服务接口申请
     * @param serviceOptFlow
     * @return
     */
    boolean updateServiceOptFlow(ServiceOptFlow serviceOptFlow);

    /**
     * 提交服务接口申请
     * @param serviceOptFlow
     * @return
     */
    boolean submitServiceOptFlow(ServiceOptFlow serviceOptFlow);

    /**
     * 删除服务申请
     * @param id
     * @return
     */
    R removeById(String id);

    /**
     * 审批服务申请
     * @param serviceOptFlow
     * @return
     */
    boolean auditServiceOptFlow(ServiceOptFlow serviceOptFlow);



}
