package com.cloud.portal.market.work.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.portal.market.work.model.Bench;
import com.cloud.portal.market.work.model.BenchComponent;

import java.util.List;

/**
 * @author liuwei
 * @date Created in 2020/4/8 15:10
 * @description:个人工作台组件信息
 * @modified By:liuwei
 */
public interface BenchComponentService extends IService<BenchComponent> {
    /**
     * 查询列表（分页）
     * @param page
     * @param benchComponent
     * @return
     */
    IPage<BenchComponent> page(IPage<BenchComponent> page, BenchComponent benchComponent);

    /**
     * 查询列表（分页）
     * @param page
     * @param benchComponent
     * @return
     */
    IPage<BenchComponent> findQueryPage(IPage<BenchComponent> page, BenchComponent benchComponent);
    /**
     * 更新删除标识
     * @param list
     * @return
     */
    boolean updateDel(List<String> list);


    /**
     * 添加组件信息
     *
     * @param benchComponent
     * @return
     */
    boolean saveComponent(BenchComponent benchComponent);

    /**
     * 更新组件信息
     * @param benchComponent
     * @return
     */
    boolean updateComponent(BenchComponent benchComponent);

    /**
     * 查询工作台可以添加的组件信息
     * @param bench
     * @return
     */
    List<BenchComponent> findByBenchId(Bench bench);

    /**
     * 根据value查询组件信息
     * @param benchComponent
     * @return
     */
    BenchComponent findByValue(BenchComponent benchComponent);
}
