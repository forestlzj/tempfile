package com.cloud.portal.market.apptool.model;

import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import com.cloud.admin.api.annotation.LogField;
import com.cloud.admin.api.entity.SysUser;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import java.util.Date;

/**
 * @author maojia
 * @date Created in 2020/3/23 13:54
 * @description:
 * @modified By:maojia
 */
@Data
@TableName("T_PORTAL_APP_TOOL_USE")
public class AppToolUse extends Model<AppToolUse> {

    @LogField(title = "主键")
    private String id;
    @LogField(title = "用户id")
    private String userId;
    @LogField(title = "应用工具ID")
    private String appToolId;
    @LogField(title = "使用次数")
    private String useNum;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date lastTime;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="yyyy-MM-dd HH:mm:ss",timezone="GMT+8")
    private Date firstTime;
    @LogField(title = "用户")
    private SysUser sysUser;
    /**
     * 类型 （APP 或者 tool）
     */
    @LogField(title = "类型")
    private String type;
}
