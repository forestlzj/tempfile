package com.cloud.portal.notify.controller;

import cn.hutool.core.io.IoUtil;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.log.annotation.SysLog;
import com.cloud.portal.notify.model.Notify;
import com.cloud.portal.notify.model.NotifyFile;
import com.cloud.portal.notify.service.NotifyFileService;
import com.cloud.portal.notify.service.NotifyService;
import com.netflix.discovery.converters.Auto;
import io.swagger.annotations.ApiOperation;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;
import java.util.List;

/**
 * @author yuhaob
 * @date Created in 2020/3/17 9:08
 * @description: 信息发布-通知公告
 * @modified By:yuhaob
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/notify")
public class NotifyController {

    @Auto
    private NotifyService notifyService;

    private final NotifyFileService notifyFileService;

    @GetMapping("/page")
    @SysLog(value = "查询通知列表",type = CommonConstants.LOG_QUERY)
    @ApiOperation(httpMethod = "GET", value = "查询通知列表")
    public R page(Notify notify, Page page){
        R result = new R<>(notifyService.findNotifyPage(page,notify));
        return result;
    }

    @GetMapping("/pageHome")
    @SysLog(value = "查询我的通知列表",type = CommonConstants.LOG_QUERY)
    @ApiOperation(httpMethod = "GET", value = "查询我的通知列表")
    public R pageHome(Notify notify, Page page){
        R result = new R<>(notifyService.findNotifyPageHome(page,notify));
        return result;
    }

    @RequestMapping(value = "/selectUserByDept/{deptId}")
    @SysLog(value = "查询接收单位下有多少存在用户")
    @ResponseBody
    public int selectUserByDept(@PathVariable("deptId") String deptId){
        int result = notifyService.selectUserByDept(deptId);
        return result;
    }

    @GetMapping("/findView")
    @SysLog(value = "查询通知详情",type = CommonConstants.LOG_QUERY)
    @ApiOperation("查询通知详情")
    public R findView(Notify notify){
        R result = new R<>(notifyService.findView(notify));
        return result;
    }

    @PostMapping("/add")
    @SysLog(value = "添加通知公告",type = CommonConstants.LOG_ADD)
    @ApiOperation("添加通知")
    public R add(@RequestBody Notify notify){
        R result = new R<>(notifyService.saveNotify(notify));
        return result;
    }

    @PostMapping("/update")
    @SysLog(value = "修改通知公告",type = CommonConstants.LOG_EDIT)
    @ApiOperation("修改通知")
    public R update(@RequestBody Notify notify){
        R result = new R<>(notifyService.updateNotify(notify));
        return result;
    }

    @GetMapping("/delete/{id}")
    @SysLog(value = "删除通知",type = CommonConstants.LOG_DELELE)
    @ApiOperation(httpMethod = "GET", value = "删除通知")
    public R delete(@PathVariable("id") String id){
        R result = new R<>(notifyService.delete(id));
        return result;
    }

    @RequestMapping(value = "/uploadNotify")
    @ResponseBody
    public R uploadNotify(@RequestParam("files") MultipartFile files) throws Exception {
        return notifyService.uploadNotify(files);
    }

    @GetMapping("/notifyList/{id}")
    public R notifyList(@PathVariable("id") String id) {
        List<NotifyFile> notifyFileList = this.notifyFileService.findListById(id);
        return R.ok(notifyFileList);
    }

    @RequestMapping(value = "/downloadNotify/{id}")
    @ResponseBody
    public void downloadNotify(@PathVariable("id") String id, HttpServletResponse response) {
        try {
            NotifyFile notifyFile = this.notifyFileService.getById(id);
            response.addHeader("Content-Length", "" + notifyFile.getFileLen());
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(notifyFile.getFileName(), "UTF-8"));
            IoUtil.copy(notifyFileService.downLoadManual(notifyFile), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

}
