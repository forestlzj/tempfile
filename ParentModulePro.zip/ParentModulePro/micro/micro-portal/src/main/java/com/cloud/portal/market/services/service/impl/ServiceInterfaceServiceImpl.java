package com.cloud.portal.market.services.service.impl;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.util.IdUtil;
import cn.hutool.db.sql.Wrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.common.core.constant.CommonConstants;
import com.cloud.common.core.util.R;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.common.constant.PortalConstants;
import com.cloud.portal.market.apptool.model.OptManual;
import com.cloud.portal.market.catalog.model.CatalogLink;
import com.cloud.portal.market.catalog.service.CatalogLinkService;
import com.cloud.portal.market.services.entity.ServiceFile;
import com.cloud.portal.market.services.entity.ServiceInterface;
import com.cloud.portal.market.services.mapper.ServiceFileMapper;
import com.cloud.portal.market.services.service.ServiceInterfaceService;
import com.cloud.portal.market.services.mapper.ServiceInterfaceMapper;
import com.cloud.portal.market.tag.service.TagLinkService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author wuxx
 * @date 2020/3/10 17:30
 * @description: TODO
 * @modified By:
 **/
@Slf4j
@Service
public class ServiceInterfaceServiceImpl extends ServiceImpl<ServiceInterfaceMapper, ServiceInterface> implements
        ServiceInterfaceService {
    /**interface
     * minio 接口服务信息
     */
    @Autowired
    private MinioTemplate minioTemplate;

    /**
     * 接口相关附件
     */
    @Autowired
    private ServiceFileMapper serviceFileMapper;

    /**
     * 类目关联信息
     */
    @Autowired
    private CatalogLinkService catalogLinkService;

    /**
     * 标签信息
     */
    @Autowired
    private TagLinkService tagLinkService;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Boolean saveServiceInterface(ServiceInterface serviceInterface) {
        Date now = new Date();
        String currentUid = SecurityUtils.getUser().getId();
        serviceInterface.setUpdateTime(now);
        serviceInterface.setUpdateBy(currentUid);
        boolean flag = false;

        String servcieId = serviceInterface.getId();


        List<String> labelId = serviceInterface.getLabelId();
        if(StringUtils.isNotBlank(servcieId)){
            // 更新操作
            catalogLinkService.deleteByOtherId(servcieId);
            //添加附件相关信息
            addFile(servcieId,serviceInterface.getServiceFiles());
            flag = this.baseMapper.update(serviceInterface);

            tagLinkService.deleteByAppToolId(servcieId);

            //添加关联标签信息
            if(labelId.size() > 0){
                this.baseMapper.addBatchByAppToolId(labelId, servcieId);
            }

        }else{
            // 新增操作
            servcieId =  IdUtil.randomUUID();
            serviceInterface.setId(servcieId);
            serviceInterface.setCreateTime(now);
            serviceInterface.setCreateBy(currentUid);
            serviceInterface.setDelFlag(CommonConstants.STATUS_NORMAL);
            flag = this.save(serviceInterface);

            //添加附件相关信息
            addFile(servcieId,serviceInterface.getServiceFiles());


            //添加关联标签信息
            if(labelId.size() > 0){
                boolean b = baseMapper.addBatchByAppToolId(labelId, servcieId);
                System.out.println(servcieId);
            }

        }

        //构造新的类别
        List<CatalogLink> catalogLinks = Arrays.stream(serviceInterface.getCatalogId().trim().split(","))
                                               .map(id -> {
                                                   CatalogLink catalogLink = new CatalogLink();
                                                   catalogLink.setCatalogId(id);
                                                   catalogLink.setOtherId(serviceInterface.getId());
                                                   return catalogLink;
                                               }).collect(Collectors.toList());

        catalogLinkService.saveBatch(catalogLinks);

        return flag;
    }

    @Override
    public IPage findPage(Page page, ServiceInterface serviceInterface){

        if(SecurityUtils.getUser().isAdmin()){
            return this.baseMapper.findAdminPage(page, serviceInterface);
        }else{
            return this.baseMapper.findPage(page, serviceInterface, SecurityUtils.getUser().getId());
        }
    }

    @Override
    public IPage findMyServicePage(Page page, ServiceInterface serviceInterface) {
        String userId = SecurityUtils.getUser().getId();
        serviceInterface.setCreateBy(userId);
        return this.baseMapper.findMyServicePage(page,serviceInterface);
    }

    @Override
    public IPage findApplyService(Page page, ServiceInterface serviceInterface) {
        String userId = SecurityUtils.getUser().getId();
        return this.baseMapper.findApplyServicePage(page, serviceInterface, userId);
    }

    @Override
    public List<ServiceInterface> findApplyServiceList(ServiceInterface serviceInterface) {
        String userId = SecurityUtils.getUser().getId();
        return this.baseMapper.findApplyServiceList(serviceInterface, userId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean removeById(Serializable id) {
        this.catalogLinkService.deleteByOtherId((String) id);
        return super.removeById(id);
    }

    @Override
    public R uploadIcon(MultipartFile file) throws Exception {
        StringBuffer nameBuffer = new StringBuffer();
        Map<String, String> result = new HashMap<>(2);
        minioTemplate.createBucket(PortalConstants.MINIO_SERVICE_BUCKET);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String fileName = file.getOriginalFilename();
        result.put("name", fileName);
        String newFileName = IdUtil.randomUUID() + fileName.substring(fileName.lastIndexOf("."));
        nameBuffer.append("icon").append("/")
                  .append(SecurityUtils.getUser().getId()).append("/")
                  .append(sdf.format(System.currentTimeMillis())).append("/")
                  .append(newFileName);
        minioTemplate.putObject(PortalConstants.MINIO_SERVICE_BUCKET, nameBuffer.toString(), file.getInputStream());
        String baseId = Base64.encode(nameBuffer.toString());
        result.put("baseId", baseId);
        result.put("url", "portal/service/interface/getIcon/" + baseId);
        return R.ok(result);
    }

    @Override
    public InputStream downLoadIcon(String base64Id) {
        String fileName = Base64.decodeStr(base64Id);
        InputStream inputStream = minioTemplate.getObject(PortalConstants.MINIO_SERVICE_BUCKET, fileName);
        return inputStream;
    }

    @Override
    public R deleteIcon(String base64Id) {
        try {
            minioTemplate.removeObject(PortalConstants.MINIO_SERVICE_BUCKET, Base64.decodeStr(base64Id));
        } catch (Exception e) {
            e.printStackTrace();
            return R.failed();
        }
        return R.ok();
    }

    @Override
    public boolean updateStatus(ServiceInterface serviceInterface) {
        return this.baseMapper.updateStatus(serviceInterface) == 1;
    }

    @Override
    public List<ServiceInterface> findList(ServiceInterface serviceInterface) {
        return baseMapper.findList(serviceInterface);
    }

    @Override
    public List<ServiceInterface> findHotService(ServiceInterface serviceInterface) {

        return this.baseMapper.findHotService(serviceInterface);
    }

    /**
     * 添加附件信息
     * @param id
     * @param serviceFileList
     * @return
     */
    @Transactional(rollbackFor = Exception.class)
    public boolean addFile(String id, List<ServiceFile> serviceFileList ){
        boolean falg = true;

        Date now = Calendar.getInstance().getTime();
        serviceFileMapper.delFileByServiceId(id);
        String currentUid = SecurityUtils.getUser().getId();
        //插入相关附件
        if (serviceFileList != null && serviceFileList.size() > 0){
            serviceFileList.stream().forEach(m ->{
                String fileName = m.getFileName();
                m.setId(IdUtil.randomUUID());
                m.setServiceId(id);
                m.setCreateTime(now);
                m.setUpdateTime(now);
                m.setCreateBy(currentUid);
                m.setUpdateBy(currentUid);
                m.setDownloadNum(0);
                m.setBucketName(PortalConstants.MINIO_MARKET_BUCKET);
                m.setExtType(fileName.substring(fileName.lastIndexOf(".") + 1,fileName.length()));
            });
            falg= serviceFileMapper.addFiles(serviceFileList);
        }
        return falg;
    }


}
