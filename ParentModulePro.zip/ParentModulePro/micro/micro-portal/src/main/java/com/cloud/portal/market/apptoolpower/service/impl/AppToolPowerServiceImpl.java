package com.cloud.portal.market.apptoolpower.service.impl;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.baomidou.mybatisplus.extension.toolkit.SqlHelper;
import com.cloud.admin.api.entity.SysUser;
import com.cloud.common.core.util.R;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import com.cloud.portal.market.apptoolpower.mapper.AppToolPowerMapper;
import com.cloud.portal.market.apptoolpower.model.AppToolPowerVo;
import com.cloud.portal.market.apptoolpower.service.AppToolPowerService;
import lombok.AllArgsConstructor;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import com.cloud.portal.market.apptoolpower.model.AppToolPower;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

/**
 * @author liuwei
 * @date Created in 2020/3/31 10:09
 * @description:应用工具权限分配
 * @modified By:liuwei
 */
@Service
@AllArgsConstructor
public class AppToolPowerServiceImpl  extends ServiceImpl<AppToolPowerMapper, AppToolPower> implements AppToolPowerService {
    @Resource
    private RedisTemplate redisTemplate;

    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean saveAppToolPower(AppToolPower appToolPower) {
        appToolPower.setSort("0");
        appToolPower.setCollector("1");
        appToolPower.setShowHide("0");
        appToolPower.setStatus("1");
        return SqlHelper.delBool(this.baseMapper.insert(appToolPower));
    }
    @Override
    public List<AppToolPower> getList(AppToolPower appToolPower) {
        return this.baseMapper.findList(appToolPower);
    }
    @Override
    @Transactional(rollbackFor = Exception.class)
    public boolean updateAppToolPower(AppToolPower appToolPower) {
        try{
            this.baseMapper.deleteByUserId(appToolPower.getUserId());
        List<AppToolPower> appToolPowerList=  initAppToolPower(appToolPower);
        if(appToolPowerList!=null&&appToolPowerList.size()>0){
            for (int i=0;i<appToolPowerList.size();i++){
                this.baseMapper.insert(appToolPowerList.get(i));
            }
        }
            String prefix = "app_tool_cache-::personAppTool_"+appToolPower.getUserId()+"_";
            Set<String> keys=redisTemplate.keys(prefix+"*");
            redisTemplate.delete(keys);
        }catch (Exception e){
            return false;
        }
        return true;
    }
    public List<AppToolPower> initAppToolPower(AppToolPower appToolPower){
        List<AppToolPower> appToolPowerList=new ArrayList<>();
        String parentId="0";
        if (appToolPower.getAppToolTreeList().size()>0){
            for(int i=0;i<appToolPower.getAppToolTreeList().size();i++){
                if(!parentId.equals(appToolPower.getAppToolTreeList().get(i).getParentId())){
                    AppToolPower appToolPower1=new AppToolPower();
                    appToolPower1.setType(appToolPower.getAppToolTreeList().get(i).getType());
                    appToolPower1.setAppToolId(appToolPower.getAppToolTreeList().get(i).getId());
                    appToolPower1.setSort("0");
                    appToolPower1.setCollector("1");
                    appToolPower1.setShowHide("0");
                    appToolPower1.setStatus("1");
                    appToolPower1.setUserId(appToolPower.getUserId());
                    appToolPowerList.add(appToolPower1);
                }
            }
        }
        return appToolPowerList;
    }

    @Override
    public IPage<List<AppToolPowerVo>> toolAppNum(IPage<AppToolPowerVo> page, AppToolPowerVo appToolPowerVo){
        return this.baseMapper.getToolAppNum(page, appToolPowerVo);
    }

    @Override
    public List<String> exists(String ids,String status) {
        MicroUser user = SecurityUtils.getUser();
        SysUser sysUser = user.getSysUser();
        String[] array = ids.split(",");
        return this.baseMapper.exists(Arrays.asList(array),sysUser.getUserId(),status);
    }

    @Override
    public boolean saveByFlow(List<AppToolPower> appToolPowerList) {
        String prefix = "app_tool_cache-::personAppTool_";
        Set<String> keys=redisTemplate.keys(prefix+"*");
        redisTemplate.delete(keys);
        return  SqlHelper.delBool(this.baseMapper.saveByFlow(appToolPowerList));
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public R updateUserAppToolById(AppToolPower appToolPower) {
        if(null!=appToolPower.getAppToolPowerList() && appToolPower.getAppToolPowerList().size()>0){
            for (int i=0;i<appToolPower.getAppToolPowerList().size();i++){
                baseMapper.updateUserAppToolById(appToolPower.getAppToolPowerList().get(i));
            }
        }else{
            baseMapper.updateUserAppToolById(appToolPower);
        }
        String prefix = "app_tool_cache-::personAppTool_"+appToolPower.getUserId()+"_"+appToolPower.getType()+"_";
        Set<String> keys=redisTemplate.keys(prefix+"*");
        redisTemplate.delete(keys);
        return R.ok();
    }

}
