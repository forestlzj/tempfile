package com.cloud.portal.market.tag.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.market.tag.entity.TagLink;
import feign.Param;

import java.util.List;

/**
 * @author maojia
 * @date Created in 2020/3/19 14:43
 * @description:
 * @modified By:maojia
 */
public interface TagLinkMapper extends BaseMapper<TagLink> {

    /**
     * 根据appToolId获取列表信息
     * @param appToolId
     * @return
     */
    List<TagLink> findListByAppToolId(@Param("appToolId")String appToolId);

    /**
     * 根据labelId获取列表信息
     * @param labelId
     * @return
     */
    List<TagLink> findListByLabelId(@Param("labelId") String labelId);

    /**
     * 批量插入数据
     * @param tagList
     * @param appToolId
     * @return
     */
    boolean insertBatchByAppToolId(@Param("tagList") List<String> tagList,@Param("appToolId") String appToolId);

    /**
     * 根据appToolId删除关联记录
     * @param appToolId
     * @return
     */
    boolean deleteByAppToolId(@Param("appToolId")String appToolId);

}
