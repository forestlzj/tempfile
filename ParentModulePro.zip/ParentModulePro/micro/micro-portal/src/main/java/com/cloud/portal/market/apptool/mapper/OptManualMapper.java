package com.cloud.portal.market.apptool.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.portal.market.apptool.model.OptManual;

/**
 * @author wengshij
 * @date Created in 2020/3/13 10:06
 * @description:应用操作手册附件信息
 * @modified By:wengshij
 */
public interface OptManualMapper extends BaseMapper<OptManual> {
}
