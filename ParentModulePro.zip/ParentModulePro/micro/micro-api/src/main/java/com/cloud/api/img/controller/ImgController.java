package com.cloud.api.img.controller;

import cn.hutool.core.io.IoUtil;
import com.cloud.api.img.service.ImgService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author wengshij
 * @date Created in 2019/10/23 9:18
 * @description:
 * @modified By:wengshij
 */
@RestController
@AllArgsConstructor
@RequestMapping("/img/human/")
@Slf4j
public class ImgController {

    private final ImgService imgService;

    /**
     * 获取照片信息
     *
     * @param idCard
     * @return
     * @throws IOException
     */
    @RequestMapping(value = "/get/{idCard}")
    @ResponseBody
    public void getImg(@PathVariable("idCard") String idCard, HttpServletResponse response) {
        try {
            response.setContentType("image/jpeg");
            IoUtil.copy(imgService.getImgByIdCard(idCard, null), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    @RequestMapping(value = "/find/{card}/{budgetName}")
    @ResponseBody
    public void getPic(@PathVariable("card") String card, @PathVariable("budgetName") String budgetName, HttpServletResponse response) {
        try {
            response.setContentType("image/jpeg");
            IoUtil.copy(imgService.getImgByIdCard(card, budgetName), response.getOutputStream());
        } catch (Exception e) {
            log.error(e.getMessage());
        }

    }

}
