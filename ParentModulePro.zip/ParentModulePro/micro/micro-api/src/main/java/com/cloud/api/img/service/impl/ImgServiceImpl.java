package com.cloud.api.img.service.impl;

import cn.hutool.core.codec.Base64Decoder;
import com.cloud.api.img.service.ImgService;
import com.cloud.common.minio.service.MinioTemplate;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

/**
 * @author wengshij
 * @date Created in 2019/10/23 9:19
 * @description:照片处理类型
 * @modified By:wengshij
 */
@Service
@Slf4j
public class ImgServiceImpl implements ImgService {

    @Value("${minio-budget.img-name}")
    private String budgetName;

    @Autowired
    private MinioTemplate minIoTemplate;

    @Override
    public InputStream getImgByIdCard(String idCard, String btName) {
        InputStream inputStream = null;
        try {
            int idNo = 15;

            if (StringUtils.isNotBlank(idCard)) {
                StringBuffer fileName = new StringBuffer();
                if (idCard.length() < idNo) {
                    fileName.append("other").append("/").append(idCard);
                } else {
                    fileName.append(idCard, 0, 2).append("/").
                            append(idCard, 0, 4).append("/").
                            append(idCard, 0, 6).append("/").
                            append(idCard, 6, 14).append("/").
                            append(idCard);
                }


                if (StringUtils.isBlank(btName)) {
                    btName = budgetName;
                }
                inputStream = minIoTemplate.getObject(btName, fileName.toString());
            }
        } catch (Exception e) {
            log.error(e.getMessage());
        }
        //如果获取照片异常、返回默认照片
        if (null == inputStream) {
            String defaultImg = "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAFW0lEQVR4Xu2aTXLaShDH/63CzvIJX+DZVYFtkhPEPkHwCR5ZBqXK+AQhJ7BdFcjSvBOYnMDOCeJsIVWQC4C8NKbUr0ZCeCQQSKiHl8RoCaPR9G/6Y7qnCU/8oScuP7YAthrwxAlszATsZvclgNdEVAF4n0D7OnsGDwAaMHMHwFfXKd9uYm+MA7A/9w6J8YGAwywCMXDDhI/uu9JNlveyjjUKYK/ZvQRRNWlRDP6u/iPQi8SFM7eHTvltVsHSjjcCwD7r2/RscqXvOjN+EqjjWdxJ2lWlLZaHQwaqRPg7FMLXhvvCsXt64KYVLO04IwDiO+8Bp26tdJ52UWqc3erVLeBs9g7TxdB5Xs8yR5qx4gD8XWRchx/3QMdu7blybJkfu/WjYoGvZnMRjqR9gjiAYqt3PVN9xsehU2pkllx7Ya/Za4DwQf2kTGFUKx3lmS/+rigAFeosom/+Yhk/R04pEurWXXix2RuEPsFjfiUZImUB6HYraLN7zR/nID5RANfxJ8vAiwIotno3BLz2FyporxHNAr6OaqVMZ4oNAuj2wxPesFYShbvX6nFgWnw7csqv1jUnoz4gXKT6iCkA0nOb2SVhNVVC6+YlCXcLQMqW1DyPdgp35JSKknMXW2b8ixENkLZTHa703KIAis3uNyJSeb8xJ/jLRoG5HEDwxGZ/7u9bPOmbyAnENKDY7HWI8MZfpEAOEPcfek4A8L/DWjmxzpDF9wgCeFR/775QlM7dVY3BejYZSR+G5AC0urdhZUcyTuu7OYsygucMQQB6HlA4cN8dDLKo4qqxuh/gXxGAnrEZ9wGCmaaYBugZW1i8kKjqLqoqeySnYWIA/MOKlrdLRYOo91cRRrY2KAogOLF12wD9M9WC3Lm7ngSZMC1xANPMzSXgL78wkiMkRkOfXIlNd7hGAOhakKeEFVF/YdUPIRgBoB+L1Z3fqFY+WBXm4v/7lyu7kz4RbF+TBI/WxjUgXsBYx3Zj5fDcviRpA4xogPpYnuQoHlIlC6xxEMYA+FqgJUgqjeXxztGqHCFQ/YfrMK2WDnsbBTC149vwUmMVhPilqrpc4XHh5SpoWf3LRnxA+BGlzkSk7guCsLjkviDqPHHHzIeSt0CLQBk1gfCDkQuTJd7c5AXIxp2g/sFiszcKw9mqVNlkYXWjGmB/6r2xiCsMqoTCq46QUa3s1wyTnqJWV2CGS+COx9Rx35e+5LH1jWjANGc/YfY7PPwDjP6k6RWI9wSE7/swCG2PCheStQYRHzBNWU8IqCwirXaeYTXSNkooCASvkdQ7xECHCRcSzRK5ACzrAGPGFwZ3MN7prBvGVFjE7kOFAjMKCq7a4/cOMZ/miRRrAfCztN2Hs3gHGAN3xDj3rEJbUk2VzL55eZMqE+phSJ2xYG57453TdUBnBmA3uycEaug2PhN8XDhfZxFZnFsAf1KPg1A+gsEN1ylfZJkvNQC1A8STy0jrW7jjGxA8LlQiiIwtdakA+Lbu4Sqy68rGrUJdWtWz7F5oGuRNznUf4WuDheM0TnIlALvZrVpEl7NwBNwxqJrWo2cVaN3xQeTgtu4fPOa3rlNuL5tzKYB54fk7007l/971JIECM33o6OFzFYREAHHhJe/j1t3ltO/pJTn1zjIICwH4GRzo+tHm5S4j0wqRd1ykOh1EiKNF54WFAPRuT3WgGTmlhSe8vIs0/X6kIJPQZToHYC4nvy/sm47tpkBMCyyDZbWIOQAR+zFwz29K2KR5V/UVzAHQm5FUCQtE4j36G4XAbIf1xUUl+gUaEHRk/qlPvCCzBfCn7nRauVYehdNO9LuO2wL4XXdOat1PXgP+AxZQFG6iKuiaAAAAAElFTkSuQmCC";
            inputStream = new ByteArrayInputStream(Base64Decoder.decode(defaultImg));
        }

        return inputStream;
    }
}
