package com.cloud.api.img.service;

import java.io.InputStream;

/**
 * @author wengshij
 * @date Created in 2019/10/23 9:18
 * @description:
 * @modified By:wengshij
 */
public interface ImgService {
    /**
     *根据身份证获取照片信息
     * @param idCard
     * @return
     */
    InputStream getImgByIdCard(String idCard,String btName);
}
