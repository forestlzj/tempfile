package com.cloud.chat.module.message.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.chat.common.entity.Message;
import com.cloud.chat.module.message.entity.ChatMessage;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 服务类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

public interface ChatMessageService extends IService<ChatMessage> {

    /**
     * 保存消息
     *
     * @param imMessage 消息
     */
    void saveMessage(ChatMessage imMessage);

    /**
     * 获取未读消息根据接收人的ID
     *
     * @param toId 接收人的Id
     */
    List<ChatMessage> getUnReadMessage(String toId);

    /**
     * 获取聊天记录信息
     * @param page
     * @param query
     * @return
     */
    IPage<Message> findMsgPage(Page<Message> page, ChatMessage  query);

}
