package com.cloud.chat.module.user.service;

import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;

/**
 * @author wengshij
 * @date Created in 2020/3/9 11:03
 * @description:
 * @modified By:wengshij
 */
public interface FileHandleService {

    /**
     * 文件上传功能
     * @param file
     * @return
     */
    String uploadFile(MultipartFile file);

    /**
     * 下载文件、
     * @param base64Id base64 封装的文件ID 用户ID/年月日/文件名称
     * @return
     */
    InputStream downLoadFile(String base64Id);


}
