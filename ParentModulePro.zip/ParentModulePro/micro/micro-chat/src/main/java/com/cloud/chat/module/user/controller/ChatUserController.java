package com.cloud.chat.module.user.controller;


import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.chat.common.entity.Message;
import com.cloud.chat.common.entity.SendInfo;
import com.cloud.chat.common.utils.ChatUtils;
import com.cloud.chat.module.message.entity.ChatMessage;
import com.cloud.chat.module.message.service.ChatMessageService;
import com.cloud.chat.module.user.entity.ChatUser;
import com.cloud.chat.module.user.service.ChatUserFriendService;
import com.cloud.chat.module.user.service.ChatUserService;
import com.cloud.chat.tio.StartTioRunner;
import com.cloud.chat.tio.TioServerConfig;
import com.cloud.chat.tio.WsOnlineContext;
import com.cloud.common.core.util.R;
import com.cloud.common.security.service.MicroUser;
import com.cloud.common.security.util.SecurityUtils;
import lombok.AllArgsConstructor;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.tio.core.ChannelContext;
import org.tio.core.Tio;
import org.tio.server.ServerGroupContext;
import org.tio.websocket.common.WsResponse;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 前端控制器
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

@RestController
@RequestMapping("/api/user")
@AllArgsConstructor
public class ChatUserController {


    private final StartTioRunner startTioRunner;


    private final ChatUserService chatUserService;


    private final ChatUserFriendService chatUserFriendService;


    private final ChatMessageService chatMessageService;

    /**
     * 用户信息初始化
     *
     * @param request request
     * @return json
     */
    @RequestMapping("init")
    public Map<String, Object> list(HttpServletRequest request) {
        Map<String, Object> objectMap = new HashMap<>(2);
        //获取好友信息
        MicroUser microUser = SecurityUtils.getUser();
        objectMap.put("users",chatUserService.findInitUser(microUser.getId()));
        objectMap.put("friends", chatUserFriendService.getUserFriends(microUser.getId()));
        //用户的群组信息
        objectMap.put("groups", chatUserService.getChatGroups(microUser.getId()));
        return objectMap;
    }


    /**
     * 获取群组的用户
     *
     * @param chatId 群组id
     * @return 用户List
     */
    @RequestMapping("chatUserList")
    public List<ChatUser> chatUserList(String chatId) {
        return chatUserService.getChatUserList(chatId);
    }

    /**
     * 发送信息给用户
     * 注意：目前仅支持发送给在线用户
     * @param userId  接收方id
     * @param  msg 消息内容
     */
    @PostMapping("sendMsg")
    public void sendMsg(String userId, String msg, HttpServletRequest request) throws Exception {
        StringBuffer url = request.getRequestURL();
        String tempContextUrl = url.delete(url.length() - request.getRequestURI().length(), url.length()).toString();
        ServerGroupContext serverGroupContext = startTioRunner.getAppStarter().getWsServerStarter().getServerGroupContext();
        ChannelContext cc = WsOnlineContext.getChannelContextByUser(userId);
        SendInfo sendInfo = new SendInfo();
        sendInfo.setCode(ChatUtils.MSG_MESSAGE);
        Message message = new Message();
        message.setId("system");
        message.setFromid("system");
        message.setContent(msg);
        message.setMine(false);
        message.setTimestamp(System.currentTimeMillis());
        message.setType(ChatUtils.FRIEND);
        message.setAvatar(tempContextUrl + "/img/icon.png");
        message.setUsername("系统消息");
        sendInfo.setMessage(message);
        if(cc!=null && !cc.isClosed){
            WsResponse wsResponse = WsResponse.fromText(new ObjectMapper().writeValueAsString(sendInfo), TioServerConfig.CHARSET);
            Tio.sendToUser(serverGroupContext, userId, wsResponse);
        }else {
            saveMessage(message, ChatUtils.UNREAD,userId);
        }
    }

    private void saveMessage(Message message, String readStatus,String userId) {
        ChatMessage imMessage = new ChatMessage();
        imMessage.setToId(userId);
        imMessage.setFromId(message.getFromid());
        imMessage.setSendTime(System.currentTimeMillis());
        imMessage.setMsg(message.getContent());
        imMessage.setReadStatus(readStatus);
        imMessage.setType(message.getType());
        chatMessageService.saveMessage(imMessage);
    }



}
