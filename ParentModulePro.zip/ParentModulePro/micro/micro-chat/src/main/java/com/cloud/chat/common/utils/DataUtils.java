package com.cloud.chat.common.utils;

import java.util.Calendar;
import java.util.Date;

/**
 * @author lzf
 * @date Created in 2020/4/27 17:12
 * @description:
 * @modified By:lzf
 */
public class DataUtils {
    /**
     * 获取过去第几天的日期
     * @param past
     * @return
     */
    public static Long getPastDate(int past) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - past);
        Date today = calendar.getTime();
        System.out.println(today.getTime());
        return today.getTime();
    }
}
