package com.cloud.chat.tio;

import com.cloud.chat.common.config.ChatConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/**
 * 开启类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

@Component
public class StartTioRunner implements CommandLineRunner {

    @Autowired
    private TioWsMsgHandler tioWsMsgHandler;
    @Autowired
    private ChatConfig chatConfig;

    private TioWebsocketStarter appStarter;

    @Override
    public void run(String... args) throws Exception {
        appStarter = new TioWebsocketStarter(chatConfig.getServerPort(), tioWsMsgHandler);
        appStarter.getWsServerStarter().start();
    }

    public TioWebsocketStarter getAppStarter() {
        return appStarter;
    }
}
