package com.cloud.chat.module.message.controller;


import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.chat.common.entity.Message;
import com.cloud.chat.common.utils.DataUtils;
import com.cloud.chat.module.message.entity.ChatMessage;
import com.cloud.chat.module.message.service.ChatMessageService;
import com.cloud.chat.module.user.entity.ChatUser;
import com.cloud.chat.module.user.service.ChatUserService;
import com.cloud.common.security.util.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 前端控制器
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

@RestController
@RequestMapping("/api/message")
public class ChatMessageController {

    public static final int PAGE_SIZE = 20;

    /**
     *如果是0表示单聊
     * 如果是1表示群聊
     */
    public static final String FRIEND = "0";

    @Autowired
    private ChatMessageService chatMessageService;




    /**
     * 获取聊天记录
     *
     * @param chatId 如果是单聊，是用户的ID，如果是多聊，是chat id
     * @return json
     */
    @ResponseBody
    @RequestMapping("list")
    public Map<String, Object> list(String chatId, String fromId,String chatType, Long pageNo) {
        String userId = SecurityUtils.getUser().getId();
        if (StringUtils.isEmpty(chatId) || StringUtils.isEmpty(fromId)) {
            return new HashMap<>();
        }
        Page page = new Page<>();
        page.setSize(PAGE_SIZE);
        if (pageNo == null) {
            pageNo = 0L;
        }
        page.setCurrent(pageNo);
        ChatMessage chatMessage=new ChatMessage();
        chatMessage.setToId(chatId);
        chatMessage.setFromId(fromId);
        chatMessage.setType(chatType);
        IPage<Message> pageMessage=chatMessageService.findMsgPage(page,chatMessage);
        Map<String, Object> map = new HashMap<>(4);
        map.put("messageList", pageMessage.getRecords());
        map.put("pageNo", pageNo);
        map.put("count", pageMessage.getTotal());
        map.put("pageSize", pageMessage.getSize());
        return map;
    }
    /**
     * 获取聊天记录指定内容
     *
     * @param chatId 如果是单聊，是用户的ID，如果是多聊，是chat id
     * @return json
     */
    @ResponseBody
    @RequestMapping("listByInput")
    public Map<String, Object> listByInput(String chatId, String fromId,String chatType, Long pageNo,String value) {
        System.out.println(value);
        if (StringUtils.isEmpty(chatId) || StringUtils.isEmpty(fromId)) {
            return new HashMap<>();
        }
        Page page = new Page<>();
        page.setSize(PAGE_SIZE);
        if (pageNo == null) {
            pageNo = 0L;
        }
        page.setCurrent(pageNo);
        ChatMessage chatMessage=new ChatMessage();
        chatMessage.setToId(chatId);
        chatMessage.setFromId(fromId);
        chatMessage.setType(chatType);

        chatMessage.setMsg(value);
        IPage<Message> pageMessage=chatMessageService.findMsgPage(page,chatMessage);
        Map<String, Object> map = new HashMap<>(4);
        map.put("messageList", pageMessage.getRecords());
        map.put("pageNo", pageNo);
        map.put("count", pageMessage.getTotal());
        map.put("pageSize", pageMessage.getSize());
        return map;
    }
    /**
     * 获取聊天记录指定时间
     *
     * @param chatId 如果是单聊，是用户的ID，如果是多聊，是chat id
     * @return json
     */
    @ResponseBody
    @RequestMapping("listByTime")
    public Map<String, Object> listByTime(String chatId, String fromId,String chatType, Long pageNo,int value) {
        System.out.println("时间value"+value);
        if (StringUtils.isEmpty(chatId) || StringUtils.isEmpty(fromId)) {
            return new HashMap<>();
        }
        Page page = new Page<>();
        page.setSize(PAGE_SIZE);
        if (pageNo == null) {
            pageNo = 0L;
        }
        page.setCurrent(pageNo);
        ChatMessage chatMessage=new ChatMessage();
        if(value==1){
            chatMessage.setSendTime(DataUtils.getPastDate(7));
        }else if(value==2){
            chatMessage.setSendTime(DataUtils.getPastDate(30));
        }else if(value==3){
            chatMessage.setSendTime(DataUtils.getPastDate(90));
        }
        chatMessage.setToId(chatId);
        chatMessage.setFromId(fromId);
        chatMessage.setType(chatType);
        //chatMessage.setMsg(value);
        IPage<Message> pageMessage=chatMessageService.findMsgPage(page,chatMessage);
        System.out.println(pageMessage.toString());
        Map<String, Object> map = new HashMap<>(4);
        map.put("messageList", pageMessage.getRecords());
        map.put("pageNo", pageNo);
        map.put("count", pageMessage.getTotal());
        map.put("pageSize", pageMessage.getSize());
        return map;
    }
    /**
     * 获取聊天记录指定时间
     *
     * @param chatId 如果是单聊，是用户的ID，如果是多聊，是chat id
     * @return json
     */
    @ResponseBody
    @RequestMapping("listByDate")
    public Map<String, Object> listByDate(String chatId, String fromId,String chatType, Long pageNo,long beginTime,long endTime) {
        System.out.println("时间beginTime"+beginTime);
        System.out.println("时间beginTime"+endTime);
        if (StringUtils.isEmpty(chatId) || StringUtils.isEmpty(fromId)) {
            return new HashMap<>();
        }
        Page page = new Page<>();
        page.setSize(PAGE_SIZE);
        if (pageNo == null) {
            pageNo = 0L;
        }
        page.setCurrent(pageNo);
        ChatMessage chatMessage=new ChatMessage();
        if(!"".equals(beginTime) ){
            //sendTime = beginTime;
            chatMessage.setSendTime(beginTime);
        }
        if(!"".equals(endTime) ){
            //sendTimeEnd = endTime;
            chatMessage.setSendTimeEnd(endTime);
        }

        chatMessage.setToId(chatId);
        chatMessage.setFromId(fromId);
        chatMessage.setType(chatType);



        //chatMessage.setMsg(value);
        IPage<Message> pageMessage=chatMessageService.findMsgPage(page,chatMessage);
        System.out.println(pageMessage.toString());
        Map<String, Object> map = new HashMap<>(4);
        map.put("messageList", pageMessage.getRecords());
        map.put("pageNo", pageNo);
        map.put("count", pageMessage.getTotal());
        map.put("pageSize", pageMessage.getSize());
        return map;
    }


    @ResponseBody
    @RequestMapping("/closeWindow")
    public void closeWindow(@RequestBody ChatUser user) {
        ChatMessage message = chatMessageService.getById(user.getHistroyId());
        if(user.getId()==message.getToId()){
            message.setToShow(0);
        }else{
            message.setFromShow(0);
        }
        chatMessageService.saveOrUpdate(message);
    }

}
