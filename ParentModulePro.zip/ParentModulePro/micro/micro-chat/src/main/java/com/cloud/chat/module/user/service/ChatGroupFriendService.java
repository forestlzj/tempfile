package com.cloud.chat.module.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.chat.module.user.entity.ChatGroupFriend;

/**
 * 服务类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
public interface ChatGroupFriendService extends IService<ChatGroupFriend> {

}
