package com.cloud.chat.module.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.chat.module.user.entity.ChatGroupFriend;
import com.cloud.chat.module.user.entity.ChatUserFriend;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 接口
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Mapper
public interface ChatUserFriendMapper extends BaseMapper<ChatUserFriend> {

    /**
     * 根据用户的ID 获取 用户好友(双向用户关系)
     * @param userId 用户ID
     * @return 好友分组的列表
     */
    List<ChatGroupFriend> getUserFriends(String userId);

}
