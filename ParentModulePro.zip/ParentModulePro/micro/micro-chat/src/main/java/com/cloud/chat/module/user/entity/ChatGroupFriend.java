package com.cloud.chat.module.user.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.cloud.chat.common.entity.BaseEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.util.List;

/**
 * 用户好友群组
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

@Data
@EqualsAndHashCode(callSuper = false)
@TableName(value = "T_PORTAL_CHAT_FRIEND_GROUP")
public class ChatGroupFriend extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId
    private String id;

    private String userId;

    private String name;

    @TableField(exist = false)
    private List<ChatUser> userList;

    @TableField(exist = false)
    private boolean expansion = false;
}
