package com.cloud.chat.module.user.service;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.chat.module.user.entity.ChatGroup;
import com.cloud.chat.module.user.entity.ChatGroupFriend;
import com.cloud.chat.module.user.entity.ChatUser;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 服务类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
public interface ChatUserService extends IService<ChatUser> {

    /**
     * 根据登录名称获取用户
     * @param loginName 登录名
     * @return 用户
     */
    ChatUser getByLoginName(String loginName);

    /**
     * 获取用户分组信息
     * @param userId 用户id
     * @return ImGroup
     */
    List<ChatGroupFriend> getGroupUsers(String userId);

    /**
     * 根据用户id 获取用户所有的群
     * @param userId 用户
     * @return 群List
     */
    List<ChatGroup> getChatGroups(String userId);

    /**
     * 获取群组的用户
     * @param chatId 群组id
     * @return 用户List
     */
    List<ChatUser> getChatUserList(String chatId);


    /**
     * 注册用户
     * @param imUser 用户对象
     */
    void registerUser(ChatUser imUser);

    /**
     * 根据用户id查询聊天历史对象
     * @param id
     * @return
     */
    List<ChatUser> findInitUser(String id);



}
