
package com.cloud.chat.tio;

import org.tio.utils.time.Time;

/**
 * TIO配置文件
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

public abstract class TioServerConfig {


    public static final String CHARSET = "utf-8";


    /**
     * ip数据监控统计，时间段
     *
     * @author tanyaowu
     */
    public  interface IpStatDuration {
        Long DURATION_1 = Time.MINUTE_1 * 5;
         Long[] IPSTAT_DURATIONS = new Long[]{DURATION_1};
    }

}
