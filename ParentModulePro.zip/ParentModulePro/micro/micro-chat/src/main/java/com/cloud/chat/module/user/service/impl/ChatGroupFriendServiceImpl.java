package com.cloud.chat.module.user.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.chat.module.user.entity.ChatGroupFriend;
import com.cloud.chat.module.user.mapper.ChatGroupFriendMapper;
import com.cloud.chat.module.user.service.ChatGroupFriendService;
import org.springframework.stereotype.Service;

/**
 * 服务类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Service
public class ChatGroupFriendServiceImpl extends ServiceImpl<ChatGroupFriendMapper, ChatGroupFriend> implements ChatGroupFriendService {

}
