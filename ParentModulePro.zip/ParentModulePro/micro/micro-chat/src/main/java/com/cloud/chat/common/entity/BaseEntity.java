package com.cloud.chat.common.entity;

import lombok.Data;

import java.util.Date;


/**
 * 基础类别
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Data
public class BaseEntity {

    /**
     * 说明
     */
    private String remarks;

    private Date createDate;

    private String createBy;

    private Date updateDate;

    private String updateBy;

    private String delFlag;

    public void preInsert() {
        this.createDate = new Date();
        this.updateDate = new Date();
        this.delFlag = "0";
    }
}
