package com.cloud.chat.module.user.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.chat.module.user.entity.*;
import com.cloud.chat.module.user.mapper.ChatUserMapper;
import com.cloud.chat.module.user.service.ChatGroupFriendService;
import com.cloud.chat.module.user.service.ChatGroupUserService;
import com.cloud.chat.module.user.service.ChatUserFriendService;
import com.cloud.chat.module.user.service.ChatUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

/**
 * 服务类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Service
public class ChatUserServiceImpl extends ServiceImpl<ChatUserMapper, ChatUser> implements ChatUserService {

    //@Value("${v.im.admin.id}")
    private String adminId;

   // @Value("${v.im.default.chat.id}")
    private String defaultChatId;

    @Autowired
    private ChatGroupFriendService iImGroupService;


    @Autowired
    private ChatUserFriendService imUserFriendService;

    @Autowired
    private ChatGroupUserService imChatGroupUserService;

    @Override
    public ChatUser getByLoginName(String loginName) {
        QueryWrapper<ChatUser> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("USERNAME", loginName);
        return baseMapper.selectOne(queryWrapper);
    }

    @Override
    public List<ChatGroupFriend> getGroupUsers(String userId){
        return baseMapper.getGroupUsers(userId);
    }

    @Override
    public List<ChatGroup> getChatGroups(String userId) {
        return baseMapper.getUserGroups(userId);
    }

    @Override
    public List<ChatUser> getChatUserList(String chatId) {
        return baseMapper.getChatUserList(chatId);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void registerUser(ChatUser imUser) {
        try {
            save(imUser);
            //添加默认用户分组 我的好友
            ChatGroupFriend imGroup = new ChatGroupFriend();
            imGroup.preInsert();
            imGroup.setName("我的好友");
            imGroup.setUserId(imUser.getId());
            iImGroupService.save(imGroup);

            //更新默认的用户组
            imUser.setDefaultGroupId(imGroup.getId());
            updateById(imUser);

            //保存用户好友，默认管理员
            ChatUserFriend imUserFriend = new ChatUserFriend();
            imUserFriend.preInsert();
            imUserFriend.setUserId(imUser.getId());
            imUserFriend.setFriendId(adminId);
            imUserFriend.setUserGroupId(imGroup.getId());
            //默认好友的分组
            ChatUser friend = getById(adminId);
            imUserFriend.setFriendGroupId(friend.getDefaultGroupId());
            imUserFriendService.save(imUserFriend);

            //添加默认群
            ChatGroupUser imChatGroupUser = new ChatGroupUser();
            imChatGroupUser.setUserId(imUser.getId());
            imChatGroupUser.setChatGroupId(defaultChatId);
            imChatGroupUser.setCreateDate(new Date());
            imChatGroupUserService.save(imChatGroupUser);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }

    }

    @Override
    public List<ChatUser> findInitUser(String id) {
        return baseMapper.findInitUser(id);
    }


}
