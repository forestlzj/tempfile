package com.cloud.chat.module.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloud.chat.module.user.entity.ChatGroupFriend;
import org.apache.ibatis.annotations.Mapper;

/**
 * 接口
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Mapper
public interface ChatGroupFriendMapper extends BaseMapper<ChatGroupFriend> {

}
