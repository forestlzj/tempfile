package com.cloud.chat.module.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.chat.module.user.entity.ChatGroupFriend;
import com.cloud.chat.module.user.entity.ChatUserFriend;

import java.util.List;

/**
 * 服务类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
public interface ChatUserFriendService extends IService<ChatUserFriend> {

    /**
     * 根据用户的ID 获取 用户好友(双向用户关系)
     *
     * @param userId 用户ID
     * @return 好友分组的列表
     */
    List<ChatGroupFriend> getUserFriends(String userId);
}
