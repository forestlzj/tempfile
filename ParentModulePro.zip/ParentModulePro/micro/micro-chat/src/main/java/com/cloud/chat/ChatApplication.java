

package com.cloud.chat;

import com.cloud.common.security.annotation.EnableMicroResourceServer;
import com.cloud.common.security.annotation.EnableMicroFeignClients;
import com.cloud.common.swagger.annotation.EnableMicroSwagger2;
import org.springframework.boot.SpringApplication;
import org.springframework.cloud.client.SpringCloudApplication;

/**
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@EnableMicroSwagger2
@SpringCloudApplication
@EnableMicroFeignClients
@EnableMicroResourceServer(details = true)
public class ChatApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChatApplication.class, args);
	}
}
