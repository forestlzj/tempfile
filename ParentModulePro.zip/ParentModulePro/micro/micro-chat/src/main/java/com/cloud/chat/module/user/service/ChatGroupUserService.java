package com.cloud.chat.module.user.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cloud.chat.module.user.entity.ChatGroupUser;

/**
 * 服务类
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
public interface ChatGroupUserService extends IService<ChatGroupUser> {

}
