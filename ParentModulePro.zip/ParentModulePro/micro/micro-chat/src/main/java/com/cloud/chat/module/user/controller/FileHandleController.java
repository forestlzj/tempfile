package com.cloud.chat.module.user.controller;

import cn.hutool.core.codec.Base64;
import cn.hutool.core.io.IoUtil;
import com.alibaba.fastjson.JSONObject;
import com.cloud.chat.common.utils.ChatUtils;
import com.cloud.chat.module.user.service.FileHandleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.net.URLEncoder;


/**
 * @author wengshij
 * @date Created in 2020/3/9 11:01
 * @description:文件处理接口
 * @modified By:wengshij
 */
@Controller
@RequestMapping("api")
@Slf4j
public class FileHandleController {


    /**
     * 文件处理接口信息
     */
    @Autowired
    private FileHandleService fileHandleService;


    @RequestMapping(value = "/get/{base64Id}")
    @ResponseBody
    public void getImg(@PathVariable("base64Id") String base64Id, HttpServletResponse response) {
        try {
            base64Id=base64Id.replaceAll(ChatUtils.SLANTING_BAR_REPLACE_STR, ChatUtils.SLANTING_BAR_STR);
            String fileName = Base64.decodeStr(base64Id);
            fileName = fileName.substring(fileName.lastIndexOf("/") + 1);
            response.addHeader("Content-Disposition", "attachment;filename=" + URLEncoder.encode(fileName, "UTF-8"));
            IoUtil.copy(fileHandleService.downLoadFile(base64Id), response.getOutputStream());

        } catch (Exception e) {
            log.error(e.getMessage());
        }
    }

    /**
     * 上传接口
     *
     * @param file 文件
     * @return json
     */
    @RequestMapping(value = "upload")
    @ResponseBody
    public String upload(@RequestParam("file") MultipartFile file) {

        return fileHandleService.uploadFile(file);

    }
}
