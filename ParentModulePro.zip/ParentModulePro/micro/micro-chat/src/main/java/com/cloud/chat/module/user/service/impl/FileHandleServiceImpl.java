package com.cloud.chat.module.user.service.impl;

import cn.hutool.core.codec.Base64;
import com.alibaba.fastjson.JSONObject;
import com.cloud.chat.common.config.ChatConfig;
import com.cloud.chat.common.utils.ChatUtils;
import com.cloud.chat.module.user.service.FileHandleService;
import com.cloud.common.minio.service.MinioTemplate;
import com.cloud.common.security.util.SecurityUtils;
import org.apache.commons.codec.digest.Md5Crypt;
import org.bouncycastle.jcajce.provider.symmetric.SM4;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.text.SimpleDateFormat;

/**
 * @author wengshij
 * @date Created in 2020/3/9 11:03
 * @description:
 * @modified By:wengshij
 */
@Service
public class FileHandleServiceImpl implements FileHandleService {

    @Autowired
    private MinioTemplate minioTemplate;

    @Autowired
    private ChatConfig chatConfig;

    private String REQUEST_DOWNLOAD_FILE_PATH = "/chat/api/get/";


    @Override
    public String uploadFile(MultipartFile file) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        JSONObject json = new JSONObject();
        json.put("msg", "success");
        String fileName;
        try {
            fileName = SecurityUtils.getUser().getId() + "/" + sdf.format(System.currentTimeMillis()) + "/" + file.getOriginalFilename();
            minioTemplate.createBucket(chatConfig.getChatFileBucket());
            minioTemplate.putObject(chatConfig.getChatFileBucket(), fileName, file.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            json.put("msg", "error");
            return json.toJSONString();
        }
        //给前端返回一个临时查看文件的URL
        String temporaryUrl = minioTemplate.getObjectURL(chatConfig.getChatFileBucket(),fileName,1);
        json.put("temporaryUrl",temporaryUrl);
        String base64Name = Base64.encode(fileName).replaceAll(ChatUtils.SLANTING_BAR_STR, ChatUtils.SLANTING_BAR_REPLACE_STR);
        json.put("filePath", REQUEST_DOWNLOAD_FILE_PATH + base64Name);
        return json.toJSONString();
    }

    @Override
    public InputStream downLoadFile(String base64Id) {
        String fileName = Base64.decodeStr(base64Id);
        InputStream inputStream = minioTemplate.getObject(chatConfig.getChatFileBucket(), fileName);
        return inputStream;
    }
}
