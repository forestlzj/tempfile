package com.cloud.chat.module.user.entity;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * 用户信息
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Data
@EqualsAndHashCode(callSuper = false)
@TableName(value = "SYS_USER")
public class ChatUser implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "user_id")
    private String id;

    private String avatar;

    private String name;
    @TableField(value = "POLICE_NUMBER")
    private String sign;
    @TableField(value = "phone")
    private String mobile;
    @TableField(value = "idcard")
    private String email;

    private String password;

    @TableField("USERNAME")
    private String loginName;

    @TableField("default_group_id")
    private String defaultGroupId;

    @TableField("type")
    private String type;

    @TableField(exist = false)
    private String histroyId;


}
