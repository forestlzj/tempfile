package com.cloud.chat.module.message.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.cloud.chat.common.entity.Message;
import com.cloud.chat.module.message.entity.ChatMessage;
import org.apache.ibatis.annotations.Param;


/**
 * 聊天信息接口
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

public interface ChatMessageMapper extends BaseMapper<ChatMessage> {

    /**
     * 获取聊天记录信息
     * @param page
     * @param query
     * @return
     */
    IPage<Message> findMsgPage(Page<Message> page, @Param("query")ChatMessage  query);

}
