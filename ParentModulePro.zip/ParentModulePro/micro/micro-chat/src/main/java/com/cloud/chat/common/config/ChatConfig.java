package com.cloud.chat.common.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

/**
 * @author wengshij
 * @date Created in 2020/3/6 15:30
 * @description:
 * @modified By:wengshij
 */
@Component
@RefreshScope
@Data
@ConfigurationProperties(prefix = "chat-conf")
public class ChatConfig {
    /**
     * 协议名称
     */
    private String protocolName;
    /**
     * 监听端口号
     */
    private int  serverPort;
    /**
     * 心跳频率
     */
    private  int heartRate;
    /**
     * 即时聊天 工具 存储文件信息的桶名称
     */
    private String chatFileBucket;


}
