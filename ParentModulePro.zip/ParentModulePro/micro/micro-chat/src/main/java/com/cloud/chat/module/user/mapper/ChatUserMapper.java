package com.cloud.chat.module.user.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.cloud.chat.module.user.entity.ChatGroup;
import com.cloud.chat.module.user.entity.ChatGroupFriend;
import com.cloud.chat.module.user.entity.ChatUser;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 接口
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Mapper
public interface ChatUserMapper extends BaseMapper<ChatUser> {

    /**
     * 根据用户id 获取好友的分组
     * @param userId id
     * @return List<ImGroup>
     */
    List<ChatGroupFriend> getGroupUsers(String userId);

    /**
     * 根据用户id 获取群组
     * @param userId id
     * @return List<ImGroup>
     */
    List<ChatGroup> getUserGroups(String userId);


    /**
     * 获取群组的用户
     * @param chatId 群组id
     * @return 用户List
     */
    List<ChatUser> getChatUserList(String chatId);

    List<ChatUser> findInitUser(String id);


}
