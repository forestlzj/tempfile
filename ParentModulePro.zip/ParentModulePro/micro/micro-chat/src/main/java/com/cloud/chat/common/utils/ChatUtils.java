package com.cloud.chat.common.utils;
/**
 * 封装的信息类型 UTILS
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
public class ChatUtils {

    /**
     * 单聊
     */
    public static final String FRIEND = "0";
    /**
     * 已读
     */
    public static final String READED = "0";

    /**
     * 未读
     */
    public static final String UNREAD = "1";

    /**
     * 心跳
     */
    public static final String MSG_PING = "0";

    /**
     * 链接就绪
     */
    public static final String MSG_READY = "1";

    /**
     * 消息
     */
    public static final String MSG_MESSAGE = "2";

    public static  final String SLANTING_BAR_STR="/";
    public static  final String SLANTING_BAR_REPLACE_STR="_xg_";
}
