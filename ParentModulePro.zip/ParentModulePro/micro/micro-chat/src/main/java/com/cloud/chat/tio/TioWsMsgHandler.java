package com.cloud.chat.tio;


import com.cloud.chat.common.entity.Message;
import com.cloud.chat.common.entity.SendInfo;
import com.cloud.chat.common.utils.ChatUtils;
import com.cloud.chat.module.message.entity.ChatMessage;
import com.cloud.chat.module.message.service.ChatMessageService;
import com.cloud.chat.module.user.entity.ChatGroup;
import com.cloud.chat.module.user.entity.ChatUser;
import com.cloud.chat.module.user.service.ChatUserService;
import com.cloud.common.security.service.MicroUser;
import lombok.AllArgsConstructor;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.RemoteTokenServices;
import org.springframework.stereotype.Component;
import org.tio.core.ChannelContext;
import org.tio.core.Tio;
import org.tio.http.common.HttpRequest;
import org.tio.http.common.HttpResponse;
import org.tio.http.common.HttpResponseStatus;
import org.tio.utils.lock.SetWithLock;
import org.tio.websocket.common.WsRequest;
import org.tio.websocket.common.WsResponse;
import org.tio.websocket.server.handler.IWsMsgHandler;

import java.io.IOException;
import java.util.List;

/**
 * websocket处理函数
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */
@Component
@AllArgsConstructor
public class TioWsMsgHandler implements IWsMsgHandler {


    private final ChatUserService chatUserService ;


    private final RemoteTokenServices tokenService;

    private final ChatMessageService chatMessageService ;





    /**
     * 握手时走这个方法，业务可以在这里获取cookie，request参数等
     *
     * @param request        request
     * @param httpResponse   httpResponse
     * @param channelContext channelContext
     * @return HttpResponse
     */
    @Override
    public HttpResponse handshake(HttpRequest request, HttpResponse httpResponse, ChannelContext channelContext) {
        String token = request.getParam("token");
        try {
            OAuth2Authentication auth2Authentication = tokenService.loadAuthentication(token);
            SecurityContextHolder.getContext().setAuthentication(auth2Authentication);
            MicroUser microUser= (MicroUser) auth2Authentication.getPrincipal();
            //绑定用户
            Tio.bindUser(channelContext, microUser.getId());
            // 在线用户绑定到上下文 用于发送在线消息
            WsOnlineContext.bindUser(microUser.getId(), channelContext);
            //绑定群组
            List<ChatGroup> groups = chatUserService.getChatGroups(microUser.getId());
            for (ChatGroup group : groups) {
                Tio.bindGroup(channelContext, group.getId());
            }
        } catch (AuthenticationException | InvalidTokenException e) {
            e.printStackTrace();
            httpResponse.setStatus(HttpResponseStatus.getHttpStatus(401));
        }
        return httpResponse;
    }

    /**
     * @param httpRequest    httpRequest
     * @param httpResponse   httpResponse
     * @param channelContext channelContext
     * @throws Exception Exception
     * @author tanyaowu tanyaowu
     */
    @Override
    public void onAfterHandshaked(HttpRequest httpRequest, HttpResponse httpResponse, ChannelContext channelContext) throws Exception {

    }

    /**
     * 字节消息（binaryType = arraybuffer）过来后会走这个方法
     */
    @Override
    public Object onBytes(WsRequest wsRequest, byte[] bytes, ChannelContext channelContext) throws Exception {
        return null;
    }

    /**
     * 当客户端发close flag时，会走这个方法
     */
    @Override
    public Object onClose(WsRequest wsRequest, byte[] bytes, ChannelContext channelContext) throws Exception {
        Tio.remove(channelContext, "receive close flag");
        return null;
    }

    /**
     * 字符消息（binaryType = blob）过来后会走这个方法
     *
     * @param wsRequest      wsRequest
     * @param text           text
     * @param channelContext channelContext
     * @return obj
     */
    @Override
    public Object onText(WsRequest wsRequest, String text, ChannelContext channelContext) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            SendInfo sendInfo = objectMapper.readValue(text, SendInfo.class);
            System.out.println(text);
            //心跳检测包
            if (ChatUtils.MSG_PING.equals(sendInfo.getCode())) {
                WsResponse wsResponse = WsResponse.fromText(text, TioServerConfig.CHARSET);
                Tio.send(channelContext, wsResponse);
            }
            //真正的消息
            else if (ChatUtils.MSG_MESSAGE.equals(sendInfo.getCode())) {
                Message message = sendInfo.getMessage();
                message.setMine(false);
                WsResponse wsResponse = WsResponse.fromText(objectMapper.writeValueAsString(sendInfo), TioServerConfig.CHARSET);
                //单聊
                if (ChatUtils.FRIEND.equals(message.getType())) {
                    SetWithLock<ChannelContext> channelContextSetWithLock = Tio.getChannelContextsByUserid(channelContext.groupContext, message.getId());
                    //用户没有登录，存储到离线文件
                    if (channelContextSetWithLock == null || channelContextSetWithLock.size() == 0) {
                        saveMessage(message, ChatUtils.UNREAD);
                    } else {
                        Tio.sendToUser(channelContext.groupContext, message.getId(), wsResponse);
                        //入库操作
                        saveMessage(message, ChatUtils.READED);
                    }
                } else {
                    Tio.sendToGroup(channelContext.groupContext, message.getId(), wsResponse);
                    //入库操作
                    saveMessage(message, ChatUtils.READED);
                }
            }
            //准备就绪，需要发送离线消息
            else if (ChatUtils.MSG_READY.equals(sendInfo.getCode())) {
                //未读消息
                sendOffLineMessage(channelContext, objectMapper);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        //返回值是要发送给客户端的内容，一般都是返回null
        return null;
    }

    /**
     * 未读消息
     *
     * @param channelContext channelContext
     * @param objectMapper   objectMapper
     * @throws IOException 抛出异常
     */
    private void sendOffLineMessage(ChannelContext channelContext, ObjectMapper objectMapper) throws IOException {
        List<ChatMessage> imMessageList = chatMessageService.getUnReadMessage(channelContext.userid);
        for (ChatMessage imMessage : imMessageList) {
            Message message = new Message();
            message.setId(imMessage.getToId());
            message.setMine(false);
            message.setType(imMessage.getType());
            ChatUser imUser = chatUserService.getById(imMessage.getFromId());
            message.setUsername(imUser.getName());
            message.setCid(String.valueOf(imMessage.getId()));
            message.setContent(imMessage.getMsg());
            message.setTimestamp(System.currentTimeMillis());
            message.setFromid(imMessage.getFromId());
            message.setAvatar(imUser.getAvatar());
            SendInfo sendInfo1 = new SendInfo();
            sendInfo1.setCode(ChatUtils.MSG_MESSAGE);
            sendInfo1.setMessage(message);
            WsResponse wsResponse = WsResponse.fromText(objectMapper.writeValueAsString(sendInfo1), TioServerConfig.CHARSET);
            Tio.sendToUser(channelContext.groupContext, message.getId(), wsResponse);
        }
    }

    /**
     * 保存信息
     *
     * @param message    信息
     * @param readStatus 是否已读
     */
    private void saveMessage(Message message, String readStatus) {
        ChatMessage imMessage = new ChatMessage();
        imMessage.setToId(message.getId());
        imMessage.setFromId(message.getFromid());
        imMessage.setSendTime(System.currentTimeMillis());
        imMessage.setMsg(message.getContent());
        imMessage.setReadStatus(readStatus);
        imMessage.setType(message.getType());
        chatMessageService.saveMessage(imMessage);
    }

}
