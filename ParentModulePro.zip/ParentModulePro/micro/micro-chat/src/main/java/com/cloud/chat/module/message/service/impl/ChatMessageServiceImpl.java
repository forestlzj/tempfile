package com.cloud.chat.module.message.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cloud.chat.common.entity.Message;
import com.cloud.chat.common.utils.ChatUtils;
import com.cloud.chat.module.message.entity.ChatMessage;
import com.cloud.chat.module.message.mapper.ChatMessageMapper;
import com.cloud.chat.module.message.service.ChatMessageService;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * 服务实现类
 *
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

@Service
public class ChatMessageServiceImpl extends ServiceImpl<ChatMessageMapper, ChatMessage> implements ChatMessageService {

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void saveMessage(ChatMessage imMessage) {
        new ChatMessageServiceImpl.SaveChatMessageThread(imMessage).run();
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<ChatMessage> getUnReadMessage(String toId) {
        QueryWrapper<ChatMessage> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("to_id", toId);
        queryWrapper.eq("read_status", "1");
        List<ChatMessage> messageList = baseMapper.selectList(queryWrapper);
        for (ChatMessage message : messageList) {
            message.setReadStatus(ChatUtils.READED);
            this.updateById(message);
        }
        return messageList;
    }

    @Override
    public IPage<Message> findMsgPage(Page<Message> page, ChatMessage query) {
        return baseMapper.findMsgPage(page, query);
    }

    /**
     * 内部类
     */
    class SaveChatMessageThread implements Runnable {

        private ChatMessage imMessage;

        public SaveChatMessageThread(ChatMessage imMessage) {
            this.imMessage = imMessage;
        }

        @Override
        public void run() {
            save(imMessage);
        }
    }
}
