package com.cloud.chat.module.message.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * 聊天信息
 * @author wengshij
 * @date Created in 2012/03/03
 * @description:聊天室
 * @modified By:wengshij
 */

@Data
@EqualsAndHashCode(callSuper = false)
@Accessors(chain = true)
@TableName(value = "T_PORTAL_CHAT_MESSAGE")
public class ChatMessage implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "id", type = IdType.UUID)
    private String id;

    /**
     * 接收人
     */
    private String toId;

    /**
     * 发送人id
     */
    private String fromId;

    private Long sendTime;

    private String msg;

    /**
     * 类型 0单聊 1 群聊
     */
    private String type;

    /**
     * 1 已读 0 未读
     */
    private String readStatus;

    /**
     * 发送人是否显示接收人（1 显示 0 不显示）用于初始化
     */
    private Integer fromShow;

    /**
     * 接收人是否显示发送人（1 显示 0 不显示）用于初始化
     */
    private Integer toShow;

    @TableField(exist = false)
    private Long sendTimeEnd;
}
