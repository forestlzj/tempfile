-- micro 核心表
create database `micro_upms` default character set utf8mb4 collate utf8mb4_general_ci;

-- micro 工作流相关库
create database `micro_ac` default character set utf8mb4 collate utf8mb4_general_ci;