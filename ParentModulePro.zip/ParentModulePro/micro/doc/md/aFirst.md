写在最前面、PC机添加域名（window 下 C:\Windows\System32\drivers\etc）
    127.0.0.1        micro-auth
	127.0.0.1     	 micro-config
	127.0.0.1     	 micro-eureka
	127.0.0.1     	 micro-gateway
	127.0.0.1     	 upms-biz	
	127.0.0.1     	 micro-activiti
	127.0.0.1     	 micro-codegen
	127.0.0.1     	 micro-monitor
	127.0.0.1  	     micro-redis
	127.0.0.1        micro-portal
	192.168.2.228   micro-mysql
	127.0.0.1      micro-quartz
	127.0.0.1      micro-api
	127.0.0.1      micro-cas
	127.0.0.1      micro-chat
