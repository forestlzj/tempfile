

package com.cloud.common.security.service;

import com.cloud.admin.api.entity.SysDept;
import com.cloud.admin.api.entity.SysRole;
import com.cloud.admin.api.entity.SysUser;
import com.cloud.common.core.constant.CommonConstants;
import lombok.Getter;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

/**
 * @author ygnet
 * @date 2018/8/20
 * 扩展用户信息
 */
public class MicroUser extends User {
    /**
     * 用户ID
     */
    @Getter
    private String id;
    @Getter
    private SysDept sysDept;
    /**
     * 用户详细信息
     */
    @Getter
    private SysUser sysUser;

    @Getter
    private SysRole sysRole;

    /**
     * 判断是否为超级管理员
     *
     * @return
     */
    public boolean isAdmin() {
        return this.id != null && CommonConstants.ADMIN_FLAG.equals(this.id);
    }


    /**
     * Construct the <code>User</code> with the details required by
     * {@link DaoAuthenticationProvider}.
     *
     * @param id                    用户ID
     * @param username              the username presented to the
     * @param sysDept               部门详细信息
     *                              <code>DaoAuthenticationProvider</code>
     * @param password              the password that should be presented to the
     *                              <code>DaoAuthenticationProvider</code>
     * @param enabled               set to <code>true</code> if the user is enabled
     * @param accountNonExpired     set to <code>true</code> if the account has not expired
     * @param credentialsNonExpired set to <code>true</code> if the credentials have not
     *                              expired
     * @param accountNonLocked      set to <code>true</code> if the account is not locked
     * @param authorities           the authorities that should be granted to the caller if they
     *                              presented the correct username and password and the user is enabled. Not null.
     * @throws IllegalArgumentException if a <code>null</code> value was passed either as
     *                                  a parameter or as an element in the <code>GrantedAuthority</code> collection
     */
    public MicroUser(String id, String username, SysUser sysUser, SysDept sysDept, SysRole sysRole, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, Collection<? extends GrantedAuthority> authorities) {
        super(username, password, enabled, accountNonExpired, credentialsNonExpired, accountNonLocked, authorities);
        this.id = id;
        this.sysDept = sysDept;
        this.sysRole = sysRole;
        this.sysUser = sysUser;

    }
}
