

package com.cloud.common.log.annotation;

import java.lang.annotation.*;

/**
 * @author ygnet
 * @date 2018/6/28
 * 操作日志注解
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface SysLog {

	/**
	 * 描述
	 *
	 * @return {String}
	 */
	String value();

	/**
	 * 日志操作类型
	 0：登录；1：查询；2：新增；3：修改；4：删除
	 * @return
	 */
	String type() default "1";
}
