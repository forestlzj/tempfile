package com.spring.cloud.config.server;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Jason on 2/24/16.
 * exclude = {DataSourceAutoConfiguration.class}:排除数据库的自动启动
 */
@Configuration
@EnableConfigServer
@ComponentScan
@RefreshScope
@RestController
@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class ConfigServerApplication {

	private String getRequestStr(HttpServletRequest request){
		String servletPath = request.getServletPath();
		String requestURL = request.getRequestURL().toString();
		return requestURL.substring(0, requestURL.indexOf(servletPath));
	}
	
	@RequestMapping(value = "/admin/config/refresh")
	public String refresh(HttpServletRequest request) {
		HttpClient client = HttpClients.createDefault();
		HttpPost post = new HttpPost(getRequestStr(request) + "/admin/refresh");
		try {
			client.execute(post);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "refresh";
	}
	
	@RequestMapping(value = "/admin/config/restart")
	public String restart(HttpServletRequest request) {
		HttpClient client = HttpClients.createDefault();
		HttpPost post = new HttpPost(getRequestStr(request) + "/admin/restart");
		try {
			client.execute(post);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "restart";
	}
	
	public static void main(String[] args) {
		SpringApplication.run(ConfigServerApplication.class, args);
	}

}
