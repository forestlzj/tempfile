package com.example.svnadmin.entity;

import io.geekidea.springbootplus.framework.common.entity.BaseEntity;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.Version;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableField;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.Accessors;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import io.geekidea.springbootplus.framework.core.validator.groups.Update;

/**
 * 
 *
 * @author forestlin
 * @since 2020-10-14
 */
@Data
@Accessors(chain = true)
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "Usr对象")
public class Usr extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @NotBlank(message = "不能为空")
    @TableId(value = "usr", type = IdType.AUTO)
    private String usr;

    @NotBlank(message = "不能为空")
    private String psw;

    private String role;

    @TableField("NAME")
    private String name;

}
