package com.example.svnadmin.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  查询结果对象
 * </pre>
 *
 * @author forestlin
 * @date 2020-10-14
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "PjQueryVo对象")
public class PjQueryVo implements Serializable {
    private static final long serialVersionUID = 1L;

    private String pj;

    private String path;

    private String url;

    private String type;

    private String des;
}