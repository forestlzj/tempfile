package com.example.svnadmin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.svnadmin.entity.Pj;
import com.example.svnadmin.param.PjPageParam;
import com.example.svnadmin.vo.PjQueryVo;

import org.springframework.stereotype.Repository;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;
import java.io.Serializable;

/**
 *  Mapper 接口
 *
 * @author forestlin
 * @since 2020-10-14
 */
@Repository
public interface PjMapper extends BaseMapper<Pj> {

    /**
     * 根据ID获取查询对象
     *
     * @param id
     * @return
     */
    PjQueryVo getPjById(Serializable id);

    /**
     * 获取分页对象
     *
     * @param page
     * @param pjQueryParam
     * @return
     */
    IPage<PjQueryVo> getPjPageList(@Param("page") Page page, @Param("param") PjPageParam pjPageParam);

}
