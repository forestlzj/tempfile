package com.example.svnadmin.service.impl;

import com.example.svnadmin.entity.Pj;
import com.example.svnadmin.mapper.PjMapper;
import com.example.svnadmin.service.PjService;
import com.example.svnadmin.param.PjPageParam;
import com.example.svnadmin.vo.PjQueryVo;
import io.geekidea.springbootplus.framework.common.service.impl.BaseServiceImpl;
import io.geekidea.springbootplus.framework.core.pagination.Paging;
import io.geekidea.springbootplus.framework.core.pagination.PageInfo;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *  服务实现类
 *
 * @author forestlin
 * @since 2020-10-14
 */
@Slf4j
@Service
public class PjServiceImpl extends BaseServiceImpl<PjMapper, Pj> implements PjService {

    @Autowired
    private PjMapper pjMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean savePj(Pj pj) throws Exception {
        return super.save(pj);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updatePj(Pj pj) throws Exception {
        return super.updateById(pj);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean deletePj(Long id) throws Exception {
        return super.removeById(id);
    }

    @Override
    public PjQueryVo getPjById(Serializable id) throws Exception {
    return pjMapper.getPjById(id);
    }

    @Override
    public Paging<PjQueryVo> getPjPageList(PjPageParam pjPageParam) throws Exception {
        Page<PjQueryVo> page = new PageInfo<>(pjPageParam, OrderItem.desc(getLambdaColumn(Pj::getCreateTime)));
        IPage<PjQueryVo> iPage = pjMapper.getPjPageList(page, pjPageParam);
        return new Paging<PjQueryVo>(iPage);
    }

}
