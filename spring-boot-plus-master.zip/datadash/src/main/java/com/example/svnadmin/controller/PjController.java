package com.example.svnadmin.controller;

import com.example.svnadmin.entity.Pj;
import com.example.svnadmin.service.PjService;
import lombok.extern.slf4j.Slf4j;
import com.example.svnadmin.param.PjPageParam;
import io.geekidea.springbootplus.framework.common.controller.BaseController;
import com.example.svnadmin.vo.PjQueryVo;
import io.geekidea.springbootplus.framework.common.api.ApiResult;
import io.geekidea.springbootplus.framework.core.pagination.Paging;
import io.geekidea.springbootplus.framework.common.param.IdParam;
import io.geekidea.springbootplus.framework.log.annotation.Module;
import io.geekidea.springbootplus.framework.log.annotation.OperationLog;
import io.geekidea.springbootplus.framework.log.enums.OperationLogType;
import io.geekidea.springbootplus.framework.core.validator.groups.Add;
import io.geekidea.springbootplus.framework.core.validator.groups.Update;
import org.springframework.validation.annotation.Validated;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 *  控制器
 *
 * @author forestlin
 * @since 2020-10-14
 */
@Slf4j
@RestController
@RequestMapping("/pj")
@Module("svnadmin")
@Api(value = "API", tags = {""})
public class PjController extends BaseController {

    @Autowired
    private PjService pjService;

    /**
     * 添加
     */
    @PostMapping("/add")
    @OperationLog(name = "添加", type = OperationLogType.ADD)
    @ApiOperation(value = "添加", response = ApiResult.class)
    public ApiResult<Boolean> addPj(@Validated(Add.class) @RequestBody Pj pj) throws Exception {
        boolean flag = pjService.savePj(pj);
        return ApiResult.result(flag);
    }

    /**
     * 修改
     */
    @PostMapping("/update")
    @OperationLog(name = "修改", type = OperationLogType.UPDATE)
    @ApiOperation(value = "修改", response = ApiResult.class)
    public ApiResult<Boolean> updatePj(@Validated(Update.class) @RequestBody Pj pj) throws Exception {
        boolean flag = pjService.updatePj(pj);
        return ApiResult.result(flag);
    }

    /**
     * 删除
     */
    @PostMapping("/delete/{id}")
    @OperationLog(name = "删除", type = OperationLogType.DELETE)
    @ApiOperation(value = "删除", response = ApiResult.class)
    public ApiResult<Boolean> deletePj(@PathVariable("id") Long id) throws Exception {
        boolean flag = pjService.deletePj(id);
        return ApiResult.result(flag);
    }

    /**
     * 获取详情
     */
    @GetMapping("/info/{id}")
    @OperationLog(name = "详情", type = OperationLogType.INFO)
    @ApiOperation(value = "详情", response = PjQueryVo.class)
    public ApiResult<PjQueryVo> getPj(@PathVariable("id") Long id) throws Exception {
        PjQueryVo pjQueryVo = pjService.getPjById(id);
        return ApiResult.ok(pjQueryVo);
    }

    /**
     * 分页列表
     */
    @PostMapping("/getPageList")
    @OperationLog(name = "分页列表", type = OperationLogType.PAGE)
    @ApiOperation(value = "分页列表", response = PjQueryVo.class)
    public ApiResult<Paging<PjQueryVo>> getPjPageList(@Validated @RequestBody PjPageParam pjPageParam) throws Exception {
        Paging<PjQueryVo> paging = pjService.getPjPageList(pjPageParam);
        return ApiResult.ok(paging);
    }

}

