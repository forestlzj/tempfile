package com.example.svnadmin.service;

import com.example.svnadmin.entity.Usr;
import com.example.svnadmin.param.UsrPageParam;
import io.geekidea.springbootplus.framework.common.service.BaseService;
import com.example.svnadmin.vo.UsrQueryVo;
import io.geekidea.springbootplus.framework.core.pagination.Paging;

/**
 *  服务类
 *
 * @author forestlin
 * @since 2020-10-14
 */
public interface UsrService extends BaseService<Usr> {

    /**
     * 保存
     *
     * @param usr
     * @return
     * @throws Exception
     */
    boolean saveUsr(Usr usr) throws Exception;

    /**
     * 修改
     *
     * @param usr
     * @return
     * @throws Exception
     */
    boolean updateUsr(Usr usr) throws Exception;

    /**
     * 删除
     *
     * @param id
     * @return
     * @throws Exception
     */
    boolean deleteUsr(Long id) throws Exception;

    /**
     * 根据ID获取查询对象
     *
     * @param id
     * @return
     * @throws Exception
     */
    UsrQueryVo getUsrById(Serializable id) throws Exception;

    /**
     * 获取分页对象
     *
     * @param usrQueryParam
     * @return
     * @throws Exception
     */
    Paging<UsrQueryVo> getUsrPageList(UsrPageParam usrPageParam) throws Exception;

}
