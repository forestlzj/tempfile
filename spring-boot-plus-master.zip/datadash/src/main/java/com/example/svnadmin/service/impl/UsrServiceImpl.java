package com.example.svnadmin.service.impl;

import com.example.svnadmin.entity.Usr;
import com.example.svnadmin.mapper.UsrMapper;
import com.example.svnadmin.service.UsrService;
import com.example.svnadmin.param.UsrPageParam;
import com.example.svnadmin.vo.UsrQueryVo;
import io.geekidea.springbootplus.framework.common.service.impl.BaseServiceImpl;
import io.geekidea.springbootplus.framework.core.pagination.Paging;
import io.geekidea.springbootplus.framework.core.pagination.PageInfo;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *  服务实现类
 *
 * @author forestlin
 * @since 2020-10-14
 */
@Slf4j
@Service
public class UsrServiceImpl extends BaseServiceImpl<UsrMapper, Usr> implements UsrService {

    @Autowired
    private UsrMapper usrMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean saveUsr(Usr usr) throws Exception {
        return super.save(usr);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateUsr(Usr usr) throws Exception {
        return super.updateById(usr);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean deleteUsr(Long id) throws Exception {
        return super.removeById(id);
    }

    @Override
    public UsrQueryVo getUsrById(Serializable id) throws Exception {
    return usrMapper.getUsrById(id);
    }

    @Override
    public Paging<UsrQueryVo> getUsrPageList(UsrPageParam usrPageParam) throws Exception {
        Page<UsrQueryVo> page = new PageInfo<>(usrPageParam, OrderItem.desc(getLambdaColumn(Usr::getCreateTime)));
        IPage<UsrQueryVo> iPage = usrMapper.getUsrPageList(page, usrPageParam);
        return new Paging<UsrQueryVo>(iPage);
    }

}
