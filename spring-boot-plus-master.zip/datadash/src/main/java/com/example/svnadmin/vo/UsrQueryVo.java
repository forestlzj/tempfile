package com.example.svnadmin.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.experimental.Accessors;
import java.io.Serializable;
import java.util.Date;

/**
 * <pre>
 *  查询结果对象
 * </pre>
 *
 * @author forestlin
 * @date 2020-10-14
 */
@Data
@Accessors(chain = true)
@ApiModel(value = "UsrQueryVo对象")
public class UsrQueryVo implements Serializable {
    private static final long serialVersionUID = 1L;

    private String usr;

    private String psw;

    private String role;

    private String name;
}