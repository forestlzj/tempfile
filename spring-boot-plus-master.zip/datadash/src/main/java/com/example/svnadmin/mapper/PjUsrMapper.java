package com.example.svnadmin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.example.svnadmin.entity.PjUsr;
import com.example.svnadmin.param.PjUsrPageParam;
import com.example.svnadmin.vo.PjUsrQueryVo;

import org.springframework.stereotype.Repository;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.apache.ibatis.annotations.Param;
import java.io.Serializable;

/**
 *  Mapper 接口
 *
 * @author forestlin
 * @since 2020-10-14
 */
@Repository
public interface PjUsrMapper extends BaseMapper<PjUsr> {

    /**
     * 根据ID获取查询对象
     *
     * @param id
     * @return
     */
    PjUsrQueryVo getPjUsrById(Serializable id);

    /**
     * 获取分页对象
     *
     * @param page
     * @param pjUsrQueryParam
     * @return
     */
    IPage<PjUsrQueryVo> getPjUsrPageList(@Param("page") Page page, @Param("param") PjUsrPageParam pjUsrPageParam);

}
