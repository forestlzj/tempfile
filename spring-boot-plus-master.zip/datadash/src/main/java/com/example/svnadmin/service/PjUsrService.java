package com.example.svnadmin.service;

import com.example.svnadmin.entity.PjUsr;
import com.example.svnadmin.param.PjUsrPageParam;
import io.geekidea.springbootplus.framework.common.service.BaseService;
import com.example.svnadmin.vo.PjUsrQueryVo;
import io.geekidea.springbootplus.framework.core.pagination.Paging;

/**
 *  服务类
 *
 * @author forestlin
 * @since 2020-10-14
 */
public interface PjUsrService extends BaseService<PjUsr> {

    /**
     * 保存
     *
     * @param pjUsr
     * @return
     * @throws Exception
     */
    boolean savePjUsr(PjUsr pjUsr) throws Exception;

    /**
     * 修改
     *
     * @param pjUsr
     * @return
     * @throws Exception
     */
    boolean updatePjUsr(PjUsr pjUsr) throws Exception;

    /**
     * 删除
     *
     * @param id
     * @return
     * @throws Exception
     */
    boolean deletePjUsr(Long id) throws Exception;

    /**
     * 根据ID获取查询对象
     *
     * @param id
     * @return
     * @throws Exception
     */
    PjUsrQueryVo getPjUsrById(Serializable id) throws Exception;

    /**
     * 获取分页对象
     *
     * @param pjUsrQueryParam
     * @return
     * @throws Exception
     */
    Paging<PjUsrQueryVo> getPjUsrPageList(PjUsrPageParam pjUsrPageParam) throws Exception;

}
