package com.example.svnadmin.service.impl;

import com.example.svnadmin.entity.PjUsr;
import com.example.svnadmin.mapper.PjUsrMapper;
import com.example.svnadmin.service.PjUsrService;
import com.example.svnadmin.param.PjUsrPageParam;
import com.example.svnadmin.vo.PjUsrQueryVo;
import io.geekidea.springbootplus.framework.common.service.impl.BaseServiceImpl;
import io.geekidea.springbootplus.framework.core.pagination.Paging;
import io.geekidea.springbootplus.framework.core.pagination.PageInfo;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import org.springframework.transaction.annotation.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *  服务实现类
 *
 * @author forestlin
 * @since 2020-10-14
 */
@Slf4j
@Service
public class PjUsrServiceImpl extends BaseServiceImpl<PjUsrMapper, PjUsr> implements PjUsrService {

    @Autowired
    private PjUsrMapper pjUsrMapper;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean savePjUsr(PjUsr pjUsr) throws Exception {
        return super.save(pjUsr);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updatePjUsr(PjUsr pjUsr) throws Exception {
        return super.updateById(pjUsr);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean deletePjUsr(Long id) throws Exception {
        return super.removeById(id);
    }

    @Override
    public PjUsrQueryVo getPjUsrById(Serializable id) throws Exception {
    return pjUsrMapper.getPjUsrById(id);
    }

    @Override
    public Paging<PjUsrQueryVo> getPjUsrPageList(PjUsrPageParam pjUsrPageParam) throws Exception {
        Page<PjUsrQueryVo> page = new PageInfo<>(pjUsrPageParam, OrderItem.desc(getLambdaColumn(PjUsr::getCreateTime)));
        IPage<PjUsrQueryVo> iPage = pjUsrMapper.getPjUsrPageList(page, pjUsrPageParam);
        return new Paging<PjUsrQueryVo>(iPage);
    }

}
