package com.example.svnadmin.service;

import com.example.svnadmin.entity.Pj;
import com.example.svnadmin.param.PjPageParam;
import io.geekidea.springbootplus.framework.common.service.BaseService;
import com.example.svnadmin.vo.PjQueryVo;
import io.geekidea.springbootplus.framework.core.pagination.Paging;

/**
 *  服务类
 *
 * @author forestlin
 * @since 2020-10-14
 */
public interface PjService extends BaseService<Pj> {

    /**
     * 保存
     *
     * @param pj
     * @return
     * @throws Exception
     */
    boolean savePj(Pj pj) throws Exception;

    /**
     * 修改
     *
     * @param pj
     * @return
     * @throws Exception
     */
    boolean updatePj(Pj pj) throws Exception;

    /**
     * 删除
     *
     * @param id
     * @return
     * @throws Exception
     */
    boolean deletePj(Long id) throws Exception;

    /**
     * 根据ID获取查询对象
     *
     * @param id
     * @return
     * @throws Exception
     */
    PjQueryVo getPjById(Serializable id) throws Exception;

    /**
     * 获取分页对象
     *
     * @param pjQueryParam
     * @return
     * @throws Exception
     */
    Paging<PjQueryVo> getPjPageList(PjPageParam pjPageParam) throws Exception;

}
